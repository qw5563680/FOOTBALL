"""Local Windows validation adapter: close SQLite connections before atomic replacement.
Python's sqlite connection context manager commits but does not close. Linux can
replace an open file; Windows cannot. This adapter changes only handle lifetime
inside restore_rows. SQL, hashes, row checks, and business sources are unchanged.
This is not a production code fix or proof of an unmodified Windows deployment.
"""
import os, sqlite3
from unittest.mock import patch

def install():
 import zucai.stats_rows as rows
 if os.name!='nt': return rows.restore_rows
 original=rows.restore_rows
 connect=sqlite3.connect
 class ClosingConnection(sqlite3.Connection):
  def __exit__(self,*args):
   try:return super().__exit__(*args)
   finally:self.close()
 def closed_connect(*args,**kwargs):
  if 'factory' in kwargs:raise RuntimeError('Unexpected custom SQLite factory')
  return connect(*args,**kwargs,factory=ClosingConnection)
 def restore(*args,**kwargs):
  with patch.object(sqlite3,'connect',closed_connect):return original(*args,**kwargs)
 rows.restore_rows=restore
 return restore
