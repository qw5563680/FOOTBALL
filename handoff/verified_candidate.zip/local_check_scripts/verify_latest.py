"""Recheck the current production snapshot locally. All network connections are denied."""
import json, shutil, socket, sys
from pathlib import Path
from unittest.mock import patch
sys.dont_write_bytecode=True
ROOT=Path(r'C:\Users\liang\AppData\Local\Temp\football-t48-handoff-check-3e80e58f845d4b01bd8f898021ce9d1f\FOOTBALL_T48_handoff_20261108')
WORK=Path(r'C:\Users\liang\AppData\Local\Temp\football-t48-network-diagnosis\latest-replay-v2')
sys.path[:0]=[str(ROOT/'code/src'),str(ROOT/'code/examples')]
import t48_verify_replay as verify
from zucai.cloud_feeds import restore_feeds
from offline_restore_compat import install
restore_rows=install()
assert json.loads((WORK/'download-verification.json').read_text())['pinned_head']=='3783d4e74feef82a02728e4e7b5c70d99d575e83'
class LocalRelease:
 def download(self,tag,name,dest):
  from zucai.stats_release import validate_tag,validate_name
  validate_tag(tag);validate_name(name)
  source=WORK/'inputs/assets'/name
  Path(dest).parent.mkdir(parents=True,exist_ok=True)
  shutil.copyfile(source,dest)
  return dest
with patch.object(socket.socket,'connect',verify.deny_network),patch.object(socket,'create_connection',verify.deny_network):
 database=WORK/'inputs/restored/input.db'
 assert not database.exists(),'Never overwrite an existing restored database'
 print('Restoring pinned current data into local-only database',flush=True)
 restore_feeds(WORK/'inputs/input',database)
 counts=restore_rows(database,WORK/'inputs/input',release=LocalRelease())
 print('Restore complete: '+json.dumps(counts),flush=True)
 sys.argv=[str(ROOT/'code/examples/t48_verify_replay.py'),'--inputs',str(WORK/'inputs'),'--handover-evidence',str(ROOT/'background'),'--code',str(ROOT/'code'),'--output',str(WORK/'validation'),'--evidence',str(WORK/'validation/evidence')]
 raise SystemExit(verify.main())
