"""Fail-closed import guard for an unused Linux API quota dependency.
This is NOT a locking implementation. Every attempted fcntl operation fails.
It allows purely offline row replay to import its modules on Windows; never use
this launcher for API acquisition, publication, or concurrent production jobs.
"""
import os, runpy, sys, types
if os.name=='nt':
 guard=types.ModuleType('fcntl')
 guard.__file__=__file__
 def unavailable(name):
  raise RuntimeError('Linux locking functionality is unavailable; offline-only guard forbids fcntl.'+name)
 guard.__getattr__=unavailable
 sys.modules['fcntl']=guard
sys.path.insert(0,r'C:\Users\liang\AppData\Local\Temp\football-t48-check-deps')
runpy.run_path(sys.argv[1],run_name='__main__')
