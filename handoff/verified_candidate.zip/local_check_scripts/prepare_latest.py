"""Prepare a new, local-only publication candidate from the verified latest snapshot."""
import json, os, shutil, socket, sys
from datetime import date
from pathlib import Path
from unittest.mock import patch
sys.dont_write_bytecode=True
ROOT=Path(r'C:\Users\liang\AppData\Local\Temp\football-t48-handoff-check-3e80e58f845d4b01bd8f898021ce9d1f\FOOTBALL_T48_handoff_20261108')
WORK=Path(r'C:\Users\liang\AppData\Local\Temp\football-t48-network-diagnosis\latest-replay-v2')
sys.path[:0]=[str(ROOT/'code/src'),str(ROOT/'code/examples')]
import t48_verify_replay as v
from zucai.cloud_feeds import export_feeds,restore_feeds
from zucai.stats_archive import write_rows_manifest
from zucai.stats_release import upload_checksums
from offline_restore_compat import install
restore_rows=install()
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
summary=load(WORK/'validation/evidence/acceptance-summary.json')
assert summary['status']=='passed'
assert summary['provenance_210']['verified_histories']==210 and summary['complete_targets']==16
assert all(summary['idempotent'].values())
CAND=WORK/'candidate-v2'; assert not CAND.exists()
source=WORK/'inputs/input'; feed=CAND/'feed';shutil.copytree(source,feed)
shutil.copytree(WORK/'validation/repair',CAND/'database');database=CAND/'database/input.db'
run_id='t48-production-20261108-3783d4e'
old=load(source/'feed_manifest.json')
release=v.LocalRelease(WORK/'validation/local-release',WORK/'inputs/assets')
with patch.object(socket.socket,'connect',v.deny_network),patch.object(socket,'create_connection',v.deny_network):
 block=load(WORK/'validation/evidence/published-technical-manifest.json')
 (CAND/'checksums').mkdir()
 block['checksum_asset']=upload_checksums(release,'stats-raw-202611',CAND/'checksums',run_id,block['row_shards']+block['injury_receipts'])
 write_rows_manifest(database,block)
 os.environ['ZUCAI_OPERATION']='replay-fd-history'
 new=export_feeds(database,feed,through=date.fromisoformat(old['through_beijing']),run_id=run_id,collection=old['collection'])
 for key in ['counts','sources','collection','through_beijing']:assert new[key]==old[key],key
 preserved=[]
 for name,h in old['files'].items():
  if name.startswith('state/sfc/') and name.endswith('.json'):
   assert load(feed/name)==load(source/name),name
   if v.digest(feed/name)!=h:
    shutil.copyfile(source/name,feed/name);new['files'][name]=h;preserved.append(name)
 v.write_json(feed/'feed_manifest.json',new)
 def hashes(root):return {p.relative_to(root).as_posix():v.digest(p) for p in root.rglob('*') if p.is_file()}
 a,b=hashes(source),hashes(feed);changed=sorted(k for k in a.keys()|b.keys() if a.get(k)!=b.get(k))
 assert set(changed)=={'feed_manifest.json','state/stats_rows_manifest.json','state/fd_stats_links.jsonl','state/audit/stats_ingest_audit.csv'},changed
 restored=CAND/'readback/input.db';restore_feeds(feed,restored);restore_rows(restored,feed,release=release)
 assert v.canonical_tables(database)==v.canonical_tables(restored),'Candidate database readback mismatch'
 experiment=load(ROOT/'frozen_batch'/v.EXPERIMENT)
 targets=[r for r in experiment['predictions'] if r['model_name']=='dc-sot-v1' and r['features'] is not None]
 assert v.build_features(restored,targets)==load(WORK/'validation/evidence/features-after.json')
 old_names={x['name'] for x in old['technical_data']['row_shards']+old['technical_data']['injury_receipts']}
 assets=[x for x in block['row_shards']+block['injury_receipts']+[block['checksum_asset']] if x['name'] not in old_names]
 for x in assets:
  p=release.root/x['tag']/x['name']; assert v.digest(p)==x['sha256'] and p.stat().st_size==x['size']
  dest=CAND/'release_upload'/x['tag']/x['name'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
 for name in changed:
  dest=CAND/'feed_updates'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(feed/name,dest)
 result={'status':'latest_candidate_verified_not_published','expected_production_head':'3783d4e74feef82a02728e4e7b5c70d99d575e83','code_commit':'a664318450675946a578c041cb1f24219981e771','run_id':run_id,'changed_files':changed,'all_other_data_files_preserved':True,'current_counts_preserved':new['counts'],'collection_metadata_preserved':True,'sfc_original_serialization_preserved':preserved,'candidate_readback_all_tables_exact':True,'candidate_readback_features_exact':True,'candidate_manifest_sha256':v.digest(feed/'feed_manifest.json'),'new_release_assets':assets,'published':False}
 v.write_json(CAND/'publication-plan.json',result)
 print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
