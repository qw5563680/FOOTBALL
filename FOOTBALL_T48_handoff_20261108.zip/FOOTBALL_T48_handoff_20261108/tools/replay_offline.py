"""Reproduce the old baseline acceptance in a NEW local directory. Never publish."""
import argparse
import json
import shutil
import socket
import sys
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True
sys.path[:0] = [str(ROOT / 'code/src'), str(ROOT / 'code/examples')]

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--work', type=Path, required=True)
    parser.add_argument('--prepare-only', action='store_true', help='Restore and verify inputs only; skip replay')
    args=parser.parse_args()
    work=args.work.resolve()
    if work.exists() or work.is_relative_to(ROOT):
        parser.error('--work must be a new directory outside the package')
    import t48_verify_replay as verify
    from zucai.cloud_feeds import restore_feeds
    from zucai.stats_rows import restore_rows
    class LocalRelease:
        def download(self,tag,name,dest):
            src=ROOT/'baseline/release_assets'/name
            Path(dest).parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(src,dest)
            return dest
    inputs=work/'inputs';inputs.mkdir(parents=True)
    for name,src in {'input':ROOT/'baseline/feed','observed':ROOT/'frozen_batch',
                     'assets':ROOT/'baseline/release_assets','raw':ROOT/'originals',
                     'archives':ROOT/'originals','code':ROOT/'code'}.items():
        try: (inputs/name).symlink_to(src,target_is_directory=True)
        except OSError: shutil.copytree(src,inputs/name)
    plan=json.loads((ROOT/'replay-plan.json').read_text())
    for x in plan['files']:
        x['path']=str(ROOT/x['path']);x['sidecar_path']=x['path']+'.meta.json'
    plan['archive']=str(ROOT/plan['archive']);plan['selection_source']=str(ROOT/plan['selection_source'])
    (inputs/'selected-raw-manifest.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
    with patch.object(socket.socket,'connect',verify.deny_network), patch.object(socket,'create_connection',verify.deny_network):
        database=inputs/'restored/input.db'
        print('Restoring packaged baseline and all 168 original assets',flush=True)
        restore_feeds(inputs/'input',database)
        restore_rows(database,inputs/'input',release=LocalRelease())
        sys.argv=[str(ROOT/'code/examples/t48_verify_replay.py'),
                  '--inputs',str(inputs),'--handover-evidence',str(ROOT/'background'),
                  '--code',str(ROOT/'code'),'--output',str(work/'validation'),
                  '--evidence',str(work/'validation/evidence')]
        if args.prepare_only: sys.argv.append('--prepare-only')
        return verify.main()

if __name__ == '__main__':
    raise SystemExit(main())
