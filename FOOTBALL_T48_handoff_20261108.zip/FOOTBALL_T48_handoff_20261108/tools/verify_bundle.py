"""Verify extracted handoff files using only Python's standard library. No network."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def safe(path):
    target = (ROOT / path).resolve()
    if not target.is_relative_to(ROOT):
        raise ValueError('Path outside package: ' + path)
    return target

def main():
    manifest = json.loads((ROOT / 'MANIFEST.json').read_text())
    for entry in manifest['files']:
        p = safe(entry['path'])
        assert p.is_file() and not (ROOT / entry['path']).is_symlink(), entry['path']
        assert p.stat().st_size == entry['size'], entry['path']
        assert sha(p) == entry['sha256'], entry['path']
    expected = {x['path'] for x in manifest['files']} | {'MANIFEST.json','SHA256SUMS'}
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()}
    assert actual == expected, ('Unexpected/missing files', sorted(actual ^ expected))
    for line in (ROOT / 'SHA256SUMS').read_text().splitlines():
        want, name = line.split('  ', 1)
        assert sha(safe(name)) == want, name
    source = json.loads((ROOT / 'replay-plan.json').read_text())
    assert len(source['files']) == 9
    for x in source['files']:
        assert sha(safe(x['path'])) == x['sha256']
        side = safe(x['path'] + '.meta.json')
        assert sha(side) == x['sidecar_sha256']
        meta = json.loads(side.read_text())
        assert meta['sha256'] == x['sha256']
        assert meta['fetched_at_utc'] == x['captured_utc']
    assert sha(safe(source['archive'])) == source['archive_sha256']
    plan = json.loads((ROOT / 'evidence/publication/publication-plan.json').read_text())
    assert len(plan['new_release_assets']) == 10
    for x in plan['new_release_assets']:
        p = ROOT / 'payload/release_upload' / x['tag'] / x['name']
        assert p.stat().st_size == x['size'] and sha(p) == x['sha256']
    assert len(plan['changed_files']) == 4
    candidate = ROOT / 'payload/feed_updates'
    assert sha(candidate / 'feed_manifest.json') == plan['candidate_manifest_sha256']
    baseline = ROOT / 'baseline/feed'
    feed = json.loads((baseline / 'feed_manifest.json').read_text())
    newfeed = json.loads((candidate / 'feed_manifest.json').read_text())
    for name, want in feed['files'].items():
        assert sha(baseline / name) == want, name
    for name, want in newfeed['files'].items():
        file = candidate / name if (candidate / name).exists() else baseline / name
        assert sha(file) == want, name
    assets = feed['technical_data']['row_shards'] + feed['technical_data']['injury_receipts']
    assert len(assets) == 168
    for x in assets:
        p = ROOT / 'baseline/release_assets' / x['name']
        assert p.stat().st_size == x['size'] and sha(p) == x['sha256']
    for x in plan['all_release_assets']:
        p = ROOT / 'payload/release_upload' / x['tag'] / x['name']
        if not p.exists(): p = ROOT / 'baseline/release_assets' / x['name']
        assert p.stat().st_size == x['size'] and sha(p) == x['sha256']
    result = json.loads((ROOT / 'evidence/production_validation/acceptance-summary.json').read_text())
    assert result['status'] == 'passed'
    assert result['provenance_210']['verified_histories'] == 210
    assert result['complete_targets'] == 16
    assert all(result['idempotent'].values())
    print(json.dumps({'status':'passed','files':len(manifest['files']),
        'release_upload_files':10,'feed_update_files':4,'raw_csv_files':9,
        'baseline_release_assets':168,'production_written':False}, ensure_ascii=False))

if __name__ == '__main__':
    main()
