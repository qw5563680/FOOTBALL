"""Run with T51 code on PYTHONPATH; all inputs are local, no production writes."""
import csv,hashlib,json,shutil
from datetime import datetime,timezone
from pathlib import Path
from zucai.history_supplement import build_supplement,read_supplement
root=Path(__file__).resolve().parent
inputs=root/'inputs'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
before={str(p.relative_to(inputs)):sha(p) for p in inputs.rglob('*') if p.is_file()}
out=root/'supplement'
kwargs=dict(plan_path=inputs/'plan.json',source_path=inputs/'results.csv',archive_path=inputs/'archive',registry_path=inputs/'nations.json',output_path=out)
# The first invocation is recorded independently in first-import.log; this rerun must add 0.
second=build_supplement(**kwargs)
assert second=={'added':0,'retained':16,'source_score_differences':1}
(root/'second-import.json').write_text(json.dumps(second,ensure_ascii=False,indent=2)+'\n')
rows=read_supplement(out)
expected=[('uefa:2036206','Portugal','France',0,0,'2024-07-05T19:00:00Z'),('uefa:2036209','Spain','France',2,1,'2024-07-09T19:00:00Z'),('uefa:2036211','Spain','England',2,1,'2024-07-14T19:00:00Z')]
assert [(r['match_id'],r['home'],r['away'],r['home_goals_90'],r['away_goals_90'],r['kickoff_utc']) for r in rows]==expected
assert all(r['historical_available_utc'] is None and r['purpose']=='historical-reference-only' and r['neutral'] for r in rows)
archive=shutil.make_archive(str(root/'supplement-export'),'zip',out)
restored=root/'restored'
if restored.exists():
 assert read_supplement(restored)==rows
else:shutil.unpack_archive(archive,restored)
assert read_supplement(restored)==rows
assert {p.name:sha(p) for p in out.iterdir()}=={p.name:sha(p) for p in restored.iterdir()}
after={str(p.relative_to(inputs)):sha(p) for p in inputs.rglob('*') if p.is_file()}
assert before==after
plan=json.loads((inputs/'plan.json').read_text())
assert all(sha(inputs/'archive'/n)==h for n,h in plan['baseline']['files'].items())
old={}
for p in (inputs/'archive/matches').glob('*.csv'):
 with p.open(encoding='utf-8-sig') as f:old.update({r['match_id']:r for r in csv.DictReader(f)})
for m in plan['matches']:
 if m['project_match_id']:
  r=old[m['project_match_id']]
  assert [int(r['home_goals']),int(r['away_goals'])]==[m['home_goals_90'],m['away_goals_90']]
assert (old['apif:1316546']['home_goals'],old['apif:1316546']['away_goals'])==('2','2')
summary={'checked_at_utc':datetime.now(timezone.utc).isoformat(),'main_base':'fa7f7eccdd99f613cc7bc7ca6edc8ec0d4137ffb','data_base':plan['baseline']['commit'],'source_commit':plan['source']['commit'],'source_fetched_at_utc':plan['source']['fetched_at_utc'],'first_import':json.loads((root/'first-import.log').read_text()),'second_import':second,'input_files_unchanged':before==after,'existing_matches_retained':16,'all_existing_month_rows_protected':len(old),'supplement_rows':len(rows),'export_restore_identical':True,'historical_available_utc':'unknown/null for all supplements','production_writes':False,'prediction_or_ledger_writes':False,'model_training_enabled':False,'input_sha256':before,'bundle_sha256':{p.name:sha(p) for p in out.iterdir()}}
(root/'acceptance-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
with (root/'supplement-3.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['UEFA编号','赛事','主队','客队','90分钟主队进球','90分钟客队进球','开球UTC','中立场','原件链接','开球时间依据'])
 names={'Portugal':'葡萄牙','France':'法国','Spain':'西班牙','England':'英格兰'}
 for r in rows:w.writerow([r['match_id'],r['league'],names[r['home']],names[r['away']],r['home_goals_90'],r['away_goals_90'],r['kickoff_utc'],r['neutral'],r['verification']['score_source_url'],r['verification']['kickoff_evidence']['source_url']])
print(json.dumps({k:v for k,v in summary.items() if not k.endswith('sha256')},ensure_ascii=False,indent=2))
