"""Result-selected parameters and a conservative, explicit P2 evidence gate."""

import hashlib
import json
import logging
import math
import os
from pathlib import Path
from tempfile import NamedTemporaryFile

from zucai.predict.base import utc
from zucai.predict.model_definitions import (
    T63_LEAGUES,
    definition_metadata,
    legacy_definition_compatible,
)
from zucai.predict.pooled import CUPS, POOL, POOL_FITTING_METHOD, configuration
from zucai.predict.seasons import latest_complete_seasons

PARAMS_PATH = Path(__file__).resolve().parents[3] / "data/model/params.json"
logger = logging.getLogger(__name__)
TRAINING_POLICY = {
    "history_scope": "cumulative",
    "strict_availability": False,
    "replay_known_after": None,
}
GATE = {
    "complete_seasons": 2,
    "min_evaluated": 500,
    "min_closing_paired": 500,
    "min_uniform_log_loss_gain": 0.05,
    "max_closing_log_loss_gap": 0.05,
    "fold": "weekly",
    "bet_allowed": False,
    "require_two_nonempty_complete_seasons": True,
    "require_no_skips_or_unavailable_labels": True,
    "artifact_corpus": "matching_sources_and_cumulative_nonreplayed_policy",
    "evidence_recency": "latest_two_complete_seasons_at_prediction",
}
CUPS_GATE = {
    **{key: value for key, value in GATE.items() if "closing" not in key},
    "min_market_paired": 300,
    "max_market_log_loss_gap": 0.05,
    "market_source": "jc_pre_kickoff_had",
}


def _parameter_paths(path=None):
    if path is not None:
        return [Path(path).expanduser().resolve()]
    candidates = []
    if configured := os.environ.get("ZUCAI_PARAMS"):
        candidates.append(Path(configured))
    candidates.extend((Path.cwd() / "data/model/params.json", PARAMS_PATH))
    return list(dict.fromkeys(candidate.expanduser().resolve() for candidate in candidates))


def parameters_path(path=None):
    """Locate a config, keeping the final attempted path available for provenance."""
    candidates = _parameter_paths(path)
    return next((candidate for candidate in candidates if candidate.exists()), candidates[-1])


def _positive_number(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    try:
        return value > 0 and math.isfinite(value)
    except OverflowError:
        return False


def _timestamp(value):
    if not isinstance(value, str):
        return False
    try:
        utc(value)
    except (ValueError, TypeError, OverflowError):
        return False
    return True


def _text(value):
    return isinstance(value, str) and bool(value.strip())


def _text_list(value):
    return (
        isinstance(value, list)
        and bool(value)
        and all(_text(item) for item in value)
        and len(set(value)) == len(value)
    )


def _validate_fields(league, values, validators, *, required=(), prefix=""):
    for field in required:
        if field not in values:
            raise ValueError(f"params.json 联赛 {league} 缺少字段 {prefix}{field}")
    for field, valid in validators.items():
        if field in values and not valid(values[field]):
            raise ValueError(f"params.json 联赛 {league} 字段 {prefix}{field} 类型或值无效")


def _validate_entry(league, entry):
    if not isinstance(entry, dict):
        raise ValueError(f"params.json 联赛 {league} 条目须为对象")
    required = ["half_life_days", "selection_as_of_utc"]
    if entry.get("p2_ready") is True:
        required.extend(
            (
                "generated_utc",
                "database_sha256",
                "training_policy",
                "sources",
                "unknown_team_prior",
                "draw_calibration",
                "p2_evidence",
            )
        )
    _validate_fields(
        league,
        entry,
        {
            "half_life_days": _positive_number,
            "selection_as_of_utc": _timestamp,
            "generated_utc": _timestamp,
            "database_sha256": _text,
            "training_policy": lambda value: isinstance(value, dict),
            "sources": lambda value: _text_list(value) and all("," not in s for s in value),
            "unknown_team_prior": _text,
            "draw_calibration": lambda value: isinstance(value, bool),
            "p2_ready": lambda value: isinstance(value, bool),
            "p2_evidence": lambda value: isinstance(value, dict),
            "evaluation_windows": lambda value: isinstance(value, list),
            "leagues": _text_list,
            "training_leagues": _text_list,
            "pooled": lambda value: isinstance(value, bool),
            "fitting_method": _text,
        },
        required=required,
    )
    if league == POOL:
        configuration(league, entry)
        if entry.get("p2_ready") and not all(
            entry.get(key) for key in ("pooled", "leagues", "training_leagues", "fitting_method")
        ):
            raise ValueError(
                "欧战 P2 条目须绑定 pooled、leagues、training_leagues 与 fitting_method"
            )
    if "training_policy" in entry:
        validators = {
            "history_scope": _text,
            "strict_availability": lambda value: isinstance(value, bool),
            "replay_known_after": lambda value: value is None or _text(value),
        }
        _validate_fields(
            league,
            entry["training_policy"],
            validators,
            required=validators,
            prefix="training_policy.",
        )
    if "p2_evidence" in entry:
        _validate_fields(
            league,
            entry["p2_evidence"],
            {"as_of_utc": _timestamp, "seasons": _text_list},
            required=("as_of_utc", "seasons") if entry.get("p2_ready") else (),
            prefix="p2_evidence.",
        )
    for index, window in enumerate(entry.get("evaluation_windows", [])):
        prefix = f"evaluation_windows[{index}]."
        if not isinstance(window, dict):
            raise ValueError(f"params.json 联赛 {league} 字段 {prefix[:-1]} 须为对象")
        _validate_fields(
            league,
            window,
            {
                "validation_season": _text,
                "selection_season": _text,
                "half_life_days": _positive_number,
                "selection_as_of_utc": _timestamp,
                "draw_calibration": lambda value: isinstance(value, bool),
            },
            required=("validation_season", "half_life_days", "selection_as_of_utc"),
            prefix=prefix,
        )


def read_parameters(path=None):
    candidates = _parameter_paths(path)
    path = parameters_path(path)
    if not path.exists():
        logger.warning(
            "参数文件不存在，回落默认90天；尝试路径：%s", ", ".join(map(str, candidates))
        )
        return {"schema_version": 1, "gate": GATE, "leagues": {}}, None
    raw = path.read_bytes()
    try:
        doc = json.loads(raw)
    except (ValueError, UnicodeError) as exc:
        raise ValueError("params.json 格式无效") from exc
    if (
        not isinstance(doc, dict)
        or isinstance(doc.get("schema_version"), bool)
        or doc.get("schema_version") != 1
        or not isinstance(doc.get("leagues"), dict)
    ):
        raise ValueError("params.json 格式无效")
    for league, entry in doc["leagues"].items():
        _validate_entry(league, entry)
    return doc, hashlib.sha256(raw).hexdigest()


def resolve_parameters(league, *, as_of, params_file=None, half_life_days=None):
    doc, digest = read_parameters(params_file)
    entry = doc["leagues"].get(league, {})
    source, days = "default", 90.0
    usable = bool(entry) and utc(entry["selection_as_of_utc"]) <= utc(as_of)
    if usable:
        days, source = entry["half_life_days"], "params.json"
    if half_life_days is not None:
        days, source = half_life_days, "cli"
    if (
        isinstance(days, bool)
        or not isinstance(days, (float, int))
        or not math.isfinite(days)
        or days <= 0
    ):
        raise ValueError("半衰期必须是正数")
    return dict(
        half_life_days=float(days),
        source=source,
        params_path=str(parameters_path(params_file)),
        params_sha256=digest if usable else None,
        selection_as_of_utc=entry.get("selection_as_of_utc") if usable else None,
        draw_calibration=bool(entry.get("draw_calibration", False)) if usable else False,
    )


def write_parameters(league, entry, path=None):
    path = parameters_path(path)
    doc, _ = read_parameters(path)
    doc["gate"] = GATE
    doc["leagues"][league] = entry
    path.parent.mkdir(parents=True, exist_ok=True)
    with NamedTemporaryFile(dir=path.parent, delete=False) as stream:
        temp = Path(stream.name)
        stream.write(
            (json.dumps(doc, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode()
        )
    try:
        temp.replace(path)
    finally:
        temp.unlink(missing_ok=True)


def p2_gate(report, *, league, as_of):
    if league == POOL:
        return _cups_p2_gate(report, as_of=as_of)
    seasons = latest_complete_seasons(as_of, league)
    rows = [report.get("seasons", {}).get(season) for season in seasons]
    reasons = []
    if report.get("fold") != "weekly":
        reasons.append("requires_weekly_folds")
    if any(not row or not row.get("complete") for row in rows):
        reasons.append("missing_complete_seasons")
    if any(
        row and (row.get("model", {}).get("n", 0) == 0 or row.get("closing", {}).get("n", 0) == 0)
        for row in rows
    ):
        reasons.append("empty_season_evidence")
    if any(row and any(row.get("skipped", {}).values()) for row in rows):
        reasons.append("skipped_evaluation_games")
    if any(row and row.get("unavailable_labels", 0) for row in rows):
        reasons.append("unavailable_evaluation_labels")
    if any(row and row.get("in_period", row["model"]["n"]) != row["model"]["n"] for row in rows):
        reasons.append("unreconciled_evaluation_population")
    totals = {}
    for name in ("model", "uniform", "closing", "closing_paired_model"):
        parts = [(r[name]["n"], r[name]["log_loss"]) for r in rows if r and name in r]
        n = sum(count for count, ll in parts if ll is not None)
        totals[name] = dict(
            n=n,
            log_loss=sum(count * ll for count, ll in parts if ll is not None) / n if n else None,
        )
    if totals["model"]["n"] < GATE["min_evaluated"]:
        reasons.append("evaluation_n_below_500")
    if (
        totals["closing"]["n"] < GATE["min_closing_paired"]
        or totals["closing"]["n"] != totals["closing_paired_model"]["n"]
    ):
        reasons.append("closing_paired_n_below_500_or_mismatch")
    gain = (
        totals["uniform"]["log_loss"] - totals["model"]["log_loss"]
        if all(totals[k]["log_loss"] is not None for k in ("uniform", "model"))
        else None
    )
    gap = (
        totals["closing_paired_model"]["log_loss"] - totals["closing"]["log_loss"]
        if all(totals[k]["log_loss"] is not None for k in ("closing_paired_model", "closing"))
        else None
    )
    if gain is None or not math.isfinite(gain) or gain < GATE["min_uniform_log_loss_gain"] - 1e-12:
        reasons.append("uniform_gain_below_0.05")
    if gap is None or not math.isfinite(gap) or gap > GATE["max_closing_log_loss_gap"] + 1e-12:
        reasons.append("closing_gap_above_0.05")
    return dict(
        p2_ready=not reasons,
        reasons=reasons,
        seasons=seasons,
        metrics=totals,
        uniform_log_loss_gain=gain,
        closing_log_loss_gap=gap,
        as_of_utc=utc(as_of).isoformat(),
        bet_allowed=False,
    )


def _cups_p2_gate(report, *, as_of):
    seasons = latest_complete_seasons(as_of, POOL)
    rows = [report.get("seasons", {}).get(season) for season in seasons]
    reasons = []
    if report.get("fold") != "weekly":
        reasons.append("requires_weekly_folds")
    if not report.get("pooled") or sorted(report.get("target_leagues", [])) != sorted(CUPS):
        reasons.append("requires_three_cups_pooled_evidence")
    if report.get("fitting_method") != POOL_FITTING_METHOD:
        reasons.append("incompatible_pooled_fitting_method")
    if any(not row or not row.get("complete") for row in rows):
        reasons.append("missing_complete_seasons")
    if any(row and not row.get("model", {}).get("n", 0) for row in rows):
        reasons.append("empty_season_evidence")
    if any(row and any(row.get("skipped", {}).values()) for row in rows):
        reasons.append("skipped_evaluation_games")
    if any(row and row.get("unavailable_labels", 0) for row in rows):
        reasons.append("unavailable_evaluation_labels")
    if any(row and row.get("in_period") != row["model"]["n"] for row in rows):
        reasons.append("unreconciled_evaluation_population")
    totals = {}
    for name in ("model", "uniform", "market", "paired_model"):
        parts = [(r[name]["n"], r[name]["log_loss"]) for r in rows if r and name in r]
        n = sum(count for count, ll in parts if ll is not None)
        totals[name] = dict(
            n=n,
            log_loss=sum(count * ll for count, ll in parts if ll is not None) / n if n else None,
        )
    if totals["model"]["n"] < CUPS_GATE["min_evaluated"]:
        reasons.append("evaluation_n_below_500")
    if totals["market"]["n"] < CUPS_GATE["min_market_paired"] or (
        totals["market"]["n"] != totals["paired_model"]["n"]
    ):
        reasons.append("market_paired_n_below_300_or_mismatch")
    gain = (
        totals["uniform"]["log_loss"] - totals["model"]["log_loss"]
        if all(totals[key]["log_loss"] is not None for key in ("uniform", "model"))
        else None
    )
    gap = (
        totals["paired_model"]["log_loss"] - totals["market"]["log_loss"]
        if all(totals[key]["log_loss"] is not None for key in ("paired_model", "market"))
        else None
    )
    if (
        gain is None
        or not math.isfinite(gain)
        or gain < CUPS_GATE["min_uniform_log_loss_gain"] - 1e-12
    ):
        reasons.append("uniform_gain_below_0.05")
    if gap is None or not math.isfinite(gap) or gap > CUPS_GATE["max_market_log_loss_gap"] + 1e-12:
        reasons.append("market_gap_above_0.05_or_missing")
    return dict(
        p2_ready=not reasons,
        reasons=reasons,
        seasons=seasons,
        metrics=totals,
        uniform_log_loss_gain=gain,
        market_log_loss_gap=gap,
        as_of_utc=utc(as_of).isoformat(),
        bet_allowed=False,
        group=POOL,
        fitting_method=report.get("fitting_method"),
        target_leagues=sorted(report.get("target_leagues", [])),
        training_leagues=sorted(report.get("training_leagues", [])),
        gate=CUPS_GATE,
    )


def _legacy_policy_ready(model, entry, definition, as_of):
    """Retain the fixed old methods under current safety checks, without recertifying a gate."""
    from zucai.predict.base import model_sources

    return (
        legacy_definition_compatible(definition)
        and not getattr(model, "pooled", False)
        and entry.get("training_policy") == TRAINING_POLICY
        and getattr(model, "training_policy", None) == TRAINING_POLICY
        and getattr(model, "availability_basis", "unknown") in ("strict", "mixed")
        and getattr(model, "replayed_training_share", 0) == 0
        and bool(entry.get("selection_as_of_utc"))
        and utc(entry["selection_as_of_utc"]) <= utc(model.as_of) <= utc(as_of)
        and (not entry.get("generated_utc") or utc(entry["generated_utc"]) <= utc(as_of))
        and (
            not getattr(model, "latest_available", None)
            or utc(model.latest_available) < utc(model.as_of)
        )
        and model.half_life_days == entry.get("half_life_days")
        and model_sources(model) == sorted(entry.get("sources", []))
        and getattr(model, "unknown_team_prior", False)
        and getattr(model, "prior_parameters", {}).get("method") == entry.get("unknown_team_prior")
        and getattr(model, "draw_calibration", False) == entry.get("draw_calibration", False)
    )


def model_readiness(model, *, as_of, params_file=None):
    """A new config cannot silently retune or certify an incompatible fitted artifact."""
    from zucai.predict.base import model_sources

    doc, digest = read_parameters(params_file)
    entry = doc["leagues"].get(model.league, {})
    evidence = entry.get("p2_evidence", {})
    definition = definition_metadata(model, entry)
    ready = bool(entry.get("p2_ready")) and bool(evidence.get("as_of_utc"))
    if ready:
        ready = (
            utc(evidence["as_of_utc"]) <= utc(as_of)
            and utc(entry["generated_utc"]) <= utc(as_of)
            and utc(entry["selection_as_of_utc"]) <= utc(model.as_of)
            and evidence.get("seasons") == latest_complete_seasons(as_of, model.league)
            and bool(entry.get("database_sha256"))
            and entry.get("training_policy") == TRAINING_POLICY
            and getattr(model, "training_policy", None) == TRAINING_POLICY
            and getattr(model, "availability_basis", "unknown") in ("strict", "mixed")
            and getattr(model, "replayed_training_share", 0) == 0
            and model.half_life_days == entry["half_life_days"]
            and model_sources(model) == sorted(entry.get("sources", []))
            and getattr(model, "unknown_team_prior", False)
            and getattr(model, "prior_parameters", {}).get("method")
            == entry.get("unknown_team_prior")
            and getattr(model, "draw_calibration", False) == entry.get("draw_calibration", False)
        )
    if model.league == POOL or getattr(model, "pooled", False):
        ready = ready and (
            model.league == POOL
            and getattr(model, "pooled", False)
            and entry.get("pooled") is True
            and getattr(model, "fitting_method", None)
            == entry.get("fitting_method")
            == evidence.get("fitting_method")
            == POOL_FITTING_METHOD
            and sorted(getattr(model, "prediction_leagues", [])) == sorted(CUPS)
            and sorted(entry.get("leagues", [])) == sorted(CUPS)
            and sorted(getattr(model, "training_league_scope", []))
            == sorted(entry.get("training_leagues", []))
            and evidence.get("group") == POOL
            and evidence.get("gate") == CUPS_GATE
            and evidence.get("p2_ready") is True
            and not evidence.get("reasons")
            and sorted(evidence.get("target_leagues", [])) == sorted(CUPS)
            and sorted(evidence.get("training_leagues", []))
            == sorted(entry.get("training_leagues", []))
        )
    if model.league in T63_LEAGUES:
        ready = _legacy_policy_ready(model, entry, definition, as_of)
        label = "可用（旧规，考核中）" if ready else "实验"
        paper_eligible = bool(ready)
    else:
        label = "P2 可用" if ready else "P2 实验"
        paper_eligible = True  # Existing non-T63 paper policies also admit experimental P2.
    return dict(
        **definition,
        p2_ready=bool(ready),
        p2_label=label,
        paper_eligible=paper_eligible,
        params_sha256=digest,
        params_path=str(parameters_path(params_file)),
        half_life_days=model.half_life_days,
        parameter_source=getattr(model, "parameter_source", "legacy_or_explicit"),
        training_database_sha256=getattr(model, "training_database_sha256", None)
        or getattr(model, "database_sha256", None),
        evaluation_database_sha256=getattr(model, "evaluation_database_sha256", None)
        or entry.get("database_sha256"),
        training_policy=getattr(model, "training_policy", None),
        p2_evidence=evidence,
        bet_allowed=False,
    )
