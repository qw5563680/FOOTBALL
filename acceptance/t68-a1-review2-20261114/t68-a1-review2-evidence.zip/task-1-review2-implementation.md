# T68 A1 — PR review 5904484794 implementation

Base: branch `codex/T68-new-competition-team-identity`, HEAD `4427f233`, existing worktree `/workspace/work/football-t68`. This round changes only `src/zucai/jc_catalogue_kickoffs.py`, `src/zucai/cloud_feeds.py`, and `tests/test_t68_jc_kickoffs.py`. No Task 2/B implementation, docs, workflow, runner settings, credentials, sports network requests, commits or pushes.

## Result and interfaces

**156 targeted tests passed in 6.32s. Ruff check and format passed; git diff --check passed. Source and tests are frozen for the parent's full suite/internal review.**

Existing interfaces remain unchanged:

```python
plan_kickoffs(archive: Path) -> dict
collect_kickoffs(database: Path, run_id: str, *, max_requests=5, archive=None) -> dict
```

A small `collection_summary(report, root)` helper projects only the bounded manifest summary. Existing plan/collector CLI options and the approved fixed route/window scope remain unchanged.

## Required fix: stop failing continuation batches

The collector now keeps `consecutive_failures`, `failure_limit`, and `stop_reason` in the durable `jc-kickoffs.json` report:

- Before a verified pilot exists, `failure_limit=1`: the first failed request stops the pilot as before, now with `stop_reason=pilot_failed`.
- With a previously verified pilot, `failure_limit=3`: the third consecutive non-success stops the current batch with `stop_reason=consecutive_failures`.
- Every successful request resets the consecutive counter to zero. HTTP failures, network exceptions and parse/identity/other already-handled validation failures use the same counter.
- Successfully attempted rows remain success; all attempted failures remain failed. Only rows for which no request was made are `not_requested`. They are never relabeled as failed or advanced as successful cursors.
- A batch ending because of its explicit request cap, with rows still pending, reports `stop_reason=request_budget`; a completed batch has no stop reason.
- The Actions text summary includes the stop reason and consecutive count. Each attempt still obeys the one-second pause, explicit cap and disabled retries/redirects.

Regression evidence includes: a completed five-request pilot followed by two successes then three HTTP403 failures, with the next seven IDs never requested; a later batch retries both failed and not-requested IDs and completes. A separate sequence `fail, fail, success, fail, fail, success` proves reset behavior. Network and parse failures are counted toward the same threshold; initial pilots still stop on their first failure. All tests use the existing fixtures and intercepted requests.

## Recommendation 1: compact manifest and transient probe status

`cloud_feeds` now publishes `collection['jc-kickoffs']` as a bounded projection: status/run ID, counters, failure limit/stop reason, and `report_path`/`report_sha256`. Per-match rows, evidence lists, selected/pending IDs and raw details stay solely in the owned `state/catalogue/<run>/jc-kickoffs.json` report. The summary size is independent of the number of selected matches; the CLI regression asserts it stays below1000 serialized bytes and verifies the pointed-to report SHA and complete row list.

A JC kickoff probe preserves the previous entries for every other provider, replaces only its own transient key, and adds only this run's summary. During later `apis`/`sync` merges, only the previous `jc-kickoffs` status is removed; every other provider entry follows the existing merge behavior. Historical report files remain archived and hash-checked. This prevents an old partial historical probe from making later healthy daily collection permanently partial.

The offline CLI regression starts with APIF/FDORG entries, runs a partial JC probe, confirms both entries survive and the report remains inspectable, then runs a healthy next-day `apis` collection. The resulting `collection_status` is complete, the transient JC key is gone, and FDORG plus the new APIF state remain present. No unrelated provider is discarded.

## Recommendation 2: fix DB evidence once and bound growth

DB source selection now prefers **all existing archived DB snapshots**. Once any are archived, the planner never admits the current live `feed_manifest.json`, matches file, or teams file as a new DB evidence source for this fixed catalogue. Existing sources retain the same full-byte SHA, schema/count, duplicate, provider/category, exact-ID/team/date/league, aliases, and catalogue checks.

Starting without an archived cache, the first reusable source contributes one core and its one original manifest. Later batches reuse that fixed evidence, even if current matches/teams bytes or the current manifest change. New matches missing from the fixed source must obtain official head evidence; they are not silently added through a new DB snapshot. The cache does not follow the live database for this fixed historical kickoff tool.

Paths remain:

```text
state/catalogue/<coreSHA>/jc-db-matches.jsonl
state/catalogue/<coreSHA>/jc-db-teams.jsonl
state/catalogue/<coreSHA>/jc-db-aliases.json
state/catalogue/<coreSHA>/jc-db-manifests/<manifestSHA>.json
```

No old snapshots are deleted. If an earlier archive already contains multiple cores/manifests, every one remains in the validation/conflict check and is preserved on export/restore; no new current-DB source is admitted. Trusted head/calculator contradictions retain precedence.

Two relevant regressions:

1. After the first cache, add a new valid JC match and another team to the current library and export a changed manifest. The new JC row remains pending in the planner, is fulfilled by an official head request, and export still contains exactly the original single core/single manifest with identical cached matches bytes. A corrupted cache still fails closed despite an available current library.
2. Construct two older valid caches with clocks23:15/23:30 for the same JC ID. The planner holds the conflict; a fresh matching head does not clear it; export retains both cores and both original manifests; clean restore still holds the conflict.

The previous deduplication test's expectation of two per-probe manifests was updated to the now-required fixed single manifest. This is a deliberate bound, not deletion of existing historical evidence.

## Validation and logs

TDD red evidence: `work/t68-a/a1-review2-red.log` — seven expected failures (the old per-probe manifest expectation and six new review scenarios) before implementation. Retained-behavior multi-cache regression was added after the minimal source-priority fix without changing production code further.

Final targeted result: `work/t68-a/a1-review2-green.log` — **156 passed in6.32s**.

Style: `work/t68-a/a1-review2-ruff.log` — **All checks passed;4 files already formatted**. `git diff --check` exits0.

Exact final commands:

```sh
PYTHONPATH=src /workspace/work/t48-venv/bin/python -m pytest -o addopts='' -o tmp_path_retention_policy=failed tests/test_t68_jc_kickoffs.py tests/test_t61_workflow.py tests/test_t61_catalogue_archive.py tests/test_cloud_feeds.py -q
/workspace/work/t48-venv/bin/ruff check src/zucai/jc_catalogue_kickoffs.py src/zucai/cloud_feeds.py tests/test_t68_jc_kickoffs.py tests/test_t61_workflow.py
/workspace/work/t48-venv/bin/ruff format --check src/zucai/jc_catalogue_kickoffs.py src/zucai/cloud_feeds.py tests/test_t68_jc_kickoffs.py tests/test_t61_workflow.py
git diff --check
```

Whole-suite verification, docs and final acceptance remain parent-owned. Live historical endpoint availability is still established only by the authorized reviewer Actions pilot; no online permission or availability claim is made by these offline tests.
