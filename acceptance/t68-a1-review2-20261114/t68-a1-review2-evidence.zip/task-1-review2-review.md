通过

PR140 第二轮修正的内部独立代码复审：未发现未解决的 Critical / Important 问题。此结论**不是 Claude 正式批准**，不授权真实采集或合并；父级负责全量测试及正式交回。

审查基线：`4427f23368324d852a4287d572463006d01cd85b`。范围为未提交的 `src/zucai/cloud_feeds.py`、`src/zucai/jc_catalogue_kickoffs.py`、`tests/test_t68_jc_kickoffs.py`。要求来自父级转述的正式 review `5904484794`；本次没有联网读取或发表 GitHub review。未改源码、未提交、未调用体育接口或正式密钥、未启动子代理；仅写本报告。

## 逐项复核

1. **连续失败停止全量：通过。** `jc_catalogue_kickoffs.py:702` 设置先导失败阈值 1、已验证先导后的续批阈值 3；`:749` 仅在本次响应完整成功后归零；`:751` 将网络、HTTP、解析、验证失败计入同一连续计数。达到阈值后停止请求。`:759` 将未尝试的剩余行显式保存为 `not_requested`，失败行保持 `failed`，不形成成功游标。报告区分 `pilot_failed`、`consecutive_failures` 和 `request_budget`。成功间隔重置计数，非连续失败不会误触发阈值。
2. **manifest 只存摘要及可复核报告指针：通过。** `jc_catalogue_kickoffs.py:790` 只输出状态、计数、停止信息及完整报告路径/SHA256；逐场记录仍保存在原 `jc-kickoffs.json`。`cloud_feeds.py:875` 在提取 collection 名称后转换摘要，步骤摘要仍获得所需字段。测试核对摘要小于 1 KB、不包含 rows/pending/evidence 等逐场载荷，并重算报告 SHA。
3. **旧 probe partial 不污染下一次 daily：通过。** `cloud_feeds.py:941` 的 `sync/apis` 共用路径仅从旧 collection 中移除 `jc-kickoffs`，再合并本次采集；`:947` 在新 kickoff probe 中同样保留其他 provider 的既有记录。测试先保留 APIF/FDORG 状态，运行部分 probe，再运行下一批 `apis`：新 manifest 为 complete，旧 kickoff 运行状态消失，FDORG 状态保持，APIF 更新；历史报告文件仍存在。原有其他 provider partial 不会被此修正强行清除。
4. **首份已归档 DB 证据固定复用：通过。** `jc_catalogue_kickoffs.py:309` 先枚举全部已保存 DB manifest；只有不存在缓存时，`:324` 才读取当前根 manifest。既有缓存存在后不再吸收增长中的 matches/teams 或每次 probe 的新 manifest。源文件、manifest、columns/counts、文件名哈希及身份核验仍照旧执行。测试证明数据库新增球队和同 ID 比赛后，原快照字节、核心文件数量和 manifest 数量不增长，新比赛仍须通过官方 head 获证。
5. **历史多个缓存仍全部参加冲突检查：通过。** 没有选取任意一份旧缓存或删除其余缓存的逻辑。新增 `test_older_multiple_db_caches_still_participate_in_conflicts` 构造同 ID 的 23:15 / 23:30 两个旧快照；二者均参与计划、仍隔离为冲突；再采集、导出、清洁恢复后两个快照及 manifest 均保留，冲突不消失。

## 独立验证

实际执行：

```sh
PYTHONPATH=src /workspace/work/t48-venv/bin/python -m pytest -o addopts='' tests/test_t68_jc_kickoffs.py tests/test_cloud_feeds.py tests/test_t61_workflow.py tests/test_t61_catalogue_archive.py -q
/workspace/work/t48-venv/bin/ruff check src/zucai/jc_catalogue_kickoffs.py src/zucai/cloud_feeds.py tests/test_t68_jc_kickoffs.py
/workspace/work/t48-venv/bin/ruff format --check src/zucai/jc_catalogue_kickoffs.py src/zucai/cloud_feeds.py tests/test_t68_jc_kickoffs.py
```

结果：**156 passed in 6.60s**；**All checks passed**；**3 files already formatted**。包含新补的旧多缓存冲突测试。没有重复父级全量测试。

另以临时目录和 `responses` 做了一次独立组合复现，复用已有离线 catalogue/head fixture：

- 15 个合成目录 ID，先导 5 次成功并导出恢复。
- 续批响应为 `403, 403, 200, 403, 403, 403`，预算 1,200。实际只请求 **6** 次；成功间隔重置计数；累计失败 5、连续失败 3、总成功 6、未请求 4，停止原因 `consecutive_failures`。
- 再导出并在新目录恢复，剩余失败 5 + 未请求 4 共 **9** 个 ID 可续取；全部成功后总成功 15、失败 0、未请求 0、停止原因为空。已成功的 6 个 ID 未重复请求。

这补充验证了“成功重置连续失败”与“停止后清洁恢复可续跑”同时成立，未依赖同一工作目录的临时 raw。

固定真实输入计划仍为 62 条路由、1,262 个官方 ID（1,083 + 179），146 条已核验时间、1,116 待取、0 issues。未改变固定请求集合或证据时间定义。

## 固定四问

1. **是否触碰冻结 predictions / parameters / run_log？** 本 diff 不涉及这些文件或计算路径；本次复审无生产写入。父级负责最终冻结对象总体验证。
2. **是否影响其他比赛匹配、路由或概率？** 不改变球队/比赛匹配、赛事采集范围或模型概率。改变的是本任务续批的停止时机，以及 manifest 中该运行的摘要寿命。APIF/FDORG 等其他 collection 条目在这两个相关路径中保留；不新建别名、关系或赛事路由。
3. **新计算是否仅用开球前可知信息？** 本改动没有预测计算。历史补时刻保留实际捕获/核验时间；冻结 DB 快照不会被之后增长的库悄悄替换，也不把后到证据倒填为历史已知。
4. **测试是否覆盖修改点？** 覆盖先导首失败、续批三连败、成功重置、混合网络/解析/HTTP 失败、保留未请求并重试、紧凑 manifest/报告 SHA、下一批 daily 状态与其他 provider 保留、固定 DB 快照增长控制、历史多缓存冲突与清洁恢复。没有发现本轮需补的阻断性测试缺口。

## 审查快照

审查前后源码哈希稳定：

| 文件 | SHA256 |
| --- | --- |
| `src/zucai/jc_catalogue_kickoffs.py` | `0f156023a8ded710baea0bafa5eba3d04d3102ffb2b66bb6e1130a21218a21e6` |
| `src/zucai/cloud_feeds.py` | `5ea08a9468d35f5b43beeebf1bf5043a6312873cff71e52a5310c0d282cf84e9` |
| `tests/test_t68_jc_kickoffs.py` | `ab8ef40b1b59eb49c4e6e3fdf9c0653fb628791ef955379b00d7f715f47165a1` |

内部复审通过不等于正式审查者已经批准，也不证明真实历史 head 接口可用。真实先导仍由获授权审查者在指定 Actions 运行器执行。
