"""Compare final-source fits before/after core archive restore, without accuracy claims."""
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
before, after = ROOT / 'model-regression-current', ROOT / 'model-regression-restored'
a_summary = json.loads((before / 'summary.json').read_text())
b_summary = json.loads((after / 'summary.json').read_text())
for key in ('source_tree_sha256', 'cutoff_utc', 'model_config_sha256', 'fitted', 'failed'):
    assert a_summary[key] == b_summary[key], key
assert a_summary['fitted'] == 26 and not a_summary['failed']
rows = []
for path in sorted(before.glob('*.json')):
    a = json.loads(path.read_text())
    if not isinstance(a, dict) or a.get('status') != 'fitted':
        continue
    b = json.loads((after / path.name).read_text())
    for key in ('training_ids', 'training_values_sha256', 'training_rows', 'targets', 'numeric', 'exclusions'):
        assert a[key] == b[key], (path.name, key)
    left = np.load(path.with_suffix('.npz'))
    right = np.load((after / path.name).with_suffix('.npz'))
    assert np.array_equal(left['probabilities'], right['probabilities']), path.name
    assert np.array_equal(left['matrices'], right['matrices']), path.name
    rows.append(dict(name=path.stem, training_rows=a['training_rows'], inputs_equal=True,
                     parameters_equal=True, probabilities_equal=True, score_matrices_equal=True))
assert len(rows) == 26
result = dict(status='passed', purpose='Deterministic regression, no predictive validity or accuracy claim',
              before=a_summary, restored=b_summary, models=rows)
(ROOT / 'model-regression-restored-comparison.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print('26 restored fits: identical inputs, parameters, probabilities, score matrices')
