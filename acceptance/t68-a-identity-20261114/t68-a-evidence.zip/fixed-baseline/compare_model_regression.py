"""Compare T68's fixed-input regression; this is not a prediction-quality experiment."""
import hashlib
import json
from pathlib import Path
import numpy as np

root = Path(__file__).resolve().parent
old, new = root/'model-regression-baseline', root/'model-regression-current'
expected_pairs = json.loads((root/'same-ids-crossday-baseline.json').read_text())
expected_removed = {x['paid_id'] for x in expected_pairs}
assert len(expected_removed) == 12
summaries = [json.loads((folder/'summary.json').read_text()) for folder in (old,new)]
for key in ('database_sha256','cutoff_utc','model_config_sha256','fitted','failed'):
    assert summaries[0][key] == summaries[1][key], key
assert summaries[0]['fitted'] == 26 and not summaries[0]['failed']
records = []
for path in sorted(old.glob('*.json')):
    a = json.loads(path.read_text())
    if not isinstance(a,dict) or a.get('status') != 'fitted':
        continue
    b = json.loads((new/path.name).read_text())
    assert a['status'] == b['status'] == 'fitted'
    assert a['targets'] == b['targets'], path.name
    ids_a, ids_b = a['training_ids'], b['training_ids']
    removed, added = sorted(set(ids_a)-set(ids_b)), sorted(set(ids_b)-set(ids_a))
    values_equal = a['training_values_sha256'] == b['training_values_sha256']
    params_equal = a['numeric'] == b['numeric']
    va, vb = np.load(path.with_suffix('.npz')), np.load((new/path.name).with_suffix('.npz'))
    probs_equal = np.array_equal(va['probabilities'],vb['probabilities'])
    matrices_equal = np.array_equal(va['matrices'],vb['matrices'])
    affected = a['league'] == '美职'
    if affected:
        assert set(removed) == expected_removed and not added, (path.name,removed,added)
        assert a['training_rows'] - b['training_rows'] == 12
        old_rows = {r['match_id']:r for r in json.loads((old/(path.stem+'-training.json')).read_text())}
        new_rows = {r['match_id']:r for r in json.loads((new/(path.stem+'-training.json')).read_text())}
        assert all(row==old_rows[mid] for mid,row in new_rows.items()), path.name
    else:
        assert ids_a == ids_b and values_equal and params_equal and probs_equal and matrices_equal, path.name
    records.append(dict(name=path.stem,league=a['league'],variant=a['variant'],affected=affected,
                        before=a['training_rows'],after=b['training_rows'],removed=removed,added=added,
                        training_values_equal=values_equal,parameters_equal=params_equal,
                        probabilities_equal=probs_equal,score_matrices_equal=matrices_equal,
                        max_probability_absolute_difference=float(np.max(np.abs(va['probabilities']-vb['probabilities']))),
                        max_matrix_absolute_difference=float(np.max(np.abs(va['matrices']-vb['matrices'])))))
assert len(records) == 26
old7 = sorted(json.loads((old/'candidate-params.json').read_text())['leagues'])
assert len(old7) == 7
assert sum(r['variant']=='primary' and r['league'] in old7 and not r['affected'] for r in records)==7
out=dict(status='passed',purpose='Fixed-data deterministic regression; no prediction-validity or accuracy claim',
         baseline=summaries[0],current=summaries[1],records=records,
         legacy_seven_unchanged=old7, frozen_git_objects_sha256=hashlib.sha256((root/'frozen-git-objects-before.json').read_bytes()).hexdigest())
(root/'model-regression-comparison.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ('baseline','current','records')},ensure_ascii=False))
print('Models:',len(records),'affected:',[r['name'] for r in records if r['affected']])
