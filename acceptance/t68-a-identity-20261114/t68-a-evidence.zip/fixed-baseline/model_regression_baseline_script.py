"""Same fixed results, cutoff and model configuration: deterministic regression only.

No performance evaluation or deployment decision. Run in separate baseline/current
processes via PYTHONPATH; diagnostic targets are clearly synthetic future inputs.
"""
import argparse
import hashlib
import json
import time
import traceback
from datetime import UTC, datetime, timedelta
from pathlib import Path
from unittest.mock import patch

import numpy as np
import requests
import zucai
from zucai.predict.command import load_corpus
from zucai.predict.dixon_coles import DixonColes
from zucai.predict.parameters import read_parameters, resolve_parameters
from zucai.predict.pooled import POOL, select_training_history
from zucai.source_version_training import candidate_parameters

ROOT = Path(__file__).resolve().parent
DB = ROOT / 'model-fixture/data/zucai.db'
CUTOFF = datetime.fromisoformat('2026-11-14T10:43:21.807840+00:00')
parser = argparse.ArgumentParser()
parser.add_argument('label')
parser.add_argument('--code', type=Path, required=True)
args = parser.parse_args()
code = args.code.resolve()
assert Path(zucai.__file__).resolve().is_relative_to(code)
out = ROOT / ('model-regression-' + args.label)
out.mkdir(exist_ok=True)
params = code / 'data/model/params.json'
config, config_sha = read_parameters(params)
candidate_params = out / 'candidate-params.json'
candidate_params.write_text(json.dumps(candidate_parameters(config), ensure_ascii=False, indent=2)+'\n')
source_hashes = {str(p.relative_to(code)): hashlib.sha256(p.read_bytes()).hexdigest()
                 for p in sorted((code / 'src').rglob('*.py'))}
source_tree = hashlib.sha256(json.dumps(source_hashes, sort_keys=True).encode()).hexdigest()
db_sha = hashlib.sha256(DB.read_bytes()).hexdigest()
outcomes = {}

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str, allow_nan=False)+'\n')

with patch.object(requests.sessions.Session, 'request', side_effect=AssertionError('Offline regression forbids HTTP')):
    for variant, parameter_file in [('primary', params), ('source-expanded', candidate_params)]:
        document, _ = read_parameters(parameter_file)
        for league, entry in document['leagues'].items():
            name = variant + '-' + league
            record_path = out / (name + '.json')
            if record_path.exists():
                record = json.loads(record_path.read_text())
                assert record['source_tree_sha256'] == source_tree
                if record['status'] == 'fitted':
                    outcomes[name] = record
                    continue
            started = time.monotonic()
            print('FIT START', name, flush=True)
            record = dict(source_tree_sha256=source_tree, database_sha256=db_sha,
                          cutoff_utc=CUTOFF.isoformat(), league=league, variant=variant,
                          validation_only=True, accuracy_claim=False)
            try:
                games, _, _, digest = load_corpus(DB, league, ','.join(entry['sources']),
                                                 params_file=parameter_file, as_of=CUTOFF)
                assert digest == db_sha
                selected = select_training_history(games, CUTOFF)
                selected.to_json(out / (name + '-training.json'), orient='records', date_format='iso', force_ascii=False)
                record['training_ids'] = selected.match_id.tolist()
                record['training_values_sha256'] = hashlib.sha256((out / (name + '-training.json')).read_bytes()).hexdigest()
                record['exclusions'] = selected.attrs.get('unverified_fd_identity_overlaps', [])
                policy = resolve_parameters(league, as_of=CUTOFF, params_file=parameter_file)
                model = DixonColes(policy['half_life_days'], unknown_team_prior=league != '欧国联',
                                   draw_calibration=policy['draw_calibration'], pooled=league == POOL).fit(games, as_of=CUTOFF)
                # Use source data, never fitted model state, to make identical paired targets.
                targets = games.sort_values(['kickoff_utc','match_id']).drop_duplicates(['home','away']).tail(25)
                matrices, identities = [], []
                for row in targets.itertuples():
                    target = dict(home=row.home, away=row.away, league=row.league,
                                  kickoff_utc=(CUTOFF + timedelta(days=1)).isoformat())
                    matrices.append(model.predict_score_matrix(target))
                    identities.append(dict(original_match_id=row.match_id, **target,
                                           kind='diagnostic_historical_pair_with_synthetic_future_kickoff'))
                matrices = np.stack(matrices)
                probabilities = np.stack([np.tril(matrices,-1).sum(axis=(1,2)),
                                          np.trace(matrices,axis1=1,axis2=2),
                                          np.triu(matrices,1).sum(axis=(1,2))], axis=1)
                np.savez_compressed(out / (name + '.npz'), matrices=matrices, probabilities=probabilities)
                record.update(status='fitted', training_rows=model.training_rows, targets=identities,
                    numeric=dict(engine_parameters=model.engine.get_params(), prior=model.prior_parameters,
                                 draw_offset=model.draw_offset, half_life_days=model.half_life_days,
                                 calibration_training_rows=model.calibration_training_rows,
                                 calibration_skipped_training_rows=model.calibration_skipped_training_rows,
                                 training_source_counts=model.training_source_counts))
            except Exception as exc:
                traceback.print_exc()
                record.update(status='failed', error=f'{type(exc).__name__}: {exc}')
            record['seconds'] = time.monotonic() - started
            write(record_path, record)
            outcomes[name] = record
            assert hashlib.sha256(DB.read_bytes()).hexdigest() == db_sha
            print('FIT END', name, record['status'], round(record['seconds'],2), flush=True)
write(out / 'source-hashes.json', source_hashes)
summary = dict(label=args.label, code_path=str(code), source_tree_sha256=source_tree,
               observed_utc=datetime.now(UTC).isoformat(), observed_beijing=datetime.now(UTC).astimezone(__import__('zoneinfo').ZoneInfo('Asia/Shanghai')).isoformat(),
               database_sha256=db_sha, cutoff_utc=CUTOFF.isoformat(), model_config_sha256=config_sha,
               fitted=sum(v['status']=='fitted' for v in outcomes.values()),
               failed={k:v['error'] for k,v in outcomes.items() if v['status']!='fitted'},
               http_calls=0, purpose='Regression equality only; no predictive performance claim')
write(out / 'summary.json', summary)
print(json.dumps(summary,ensure_ascii=False),flush=True)
