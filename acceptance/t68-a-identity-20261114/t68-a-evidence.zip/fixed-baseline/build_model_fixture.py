"""Create a results-only regression DB, not a claimed full archive restoration."""
import hashlib
import json
import sqlite3
from pathlib import Path

from zucai.cloud_feeds import TABLES
from zucai.db import get_engine, init_db
from zucai.result_source_identity import restore_result_identities
from zucai.result_source_links import restore_result_links

ROOT = Path(__file__).resolve().parent
archive = ROOT / 'fixed-archive'
database = ROOT / 'model-fixture/data/zucai.db'
assert not database.exists(), 'Never overwrite an existing fixture DB'
database.parent.mkdir(parents=True, exist_ok=True)
meta = json.loads((archive / 'feed_manifest.json').read_text())
engine = get_engine(database)
init_db(engine)
engine.dispose()
counts = {}
with sqlite3.connect(database) as db:
    db.execute('PRAGMA foreign_keys=ON')
    for table in ('teams', 'matches', 'results'):
        cols = meta['columns'][table]
        assert tuple(cols) == TABLES[table]
        raw = (archive / f'state/{table}.jsonl').read_bytes()
        assert hashlib.sha256(raw).hexdigest() == meta['files'][f'state/{table}.jsonl']
        db.executemany(
            f"INSERT INTO {table} ({','.join(cols)}) VALUES ({','.join('?' for _ in cols)})",
            (json.loads(line) for line in raw.splitlines()),
        )
        counts[table] = db.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0]
        assert counts[table] == meta['counts'][table]
    restore_result_links(db, archive, meta)
    restore_result_identities(db, archive, meta)
    for table in ('result_source_links', 'result_source_identities'):
        counts[table] = db.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0]
    assert db.execute('PRAGMA foreign_key_check').fetchall() == []
report = dict(
    purpose='Results/identity regression fixture; odds, statistics, reports and ledgers deliberately absent',
    source_commit='e370db1d5cabe1cb33ddbfff3029c6d802bb8992',
    database_sha256=hashlib.sha256(database.read_bytes()).hexdigest(),
    database=str(database), counts=counts,
)
(ROOT / 'model-fixture-inputs.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(report, ensure_ascii=False))
