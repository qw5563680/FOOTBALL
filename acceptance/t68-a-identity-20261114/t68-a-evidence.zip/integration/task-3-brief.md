# T68 A 段实施计划


**Goal:** 提供严格绑定证据与补时刻工具，修正跨日重复和采集口径，产出可复核离线证据。
**Architecture:** 沿用正式候选队列、reconcile/relink-jc、原来源保存策略；只新增离线校验/审核工具和局部保护。B段仅文档，不实现。
**Tech Stack:** Python 3.12、SQLAlchemy/SQLite、requests、现有pytest/ruff；不新增依赖。
**Spec:** `docs/experiments/T68-identity-binding-protocol.md`；PR140 review5904223500；PR139 task增补，由所有者本轮指示采用。

## Global Constraints

- B段泛称赛事关联不实现；不设新赛事独立留行/时标范围，不修改模型来源/参数。
- 正式API密钥仅Actions，开发不发体育请求；全部测试仅data/fixtures离线样本。
- 只产生待审候选，不自行核准别名，不开启daily，不改生产数据/冻结预测/旧报告/账本。
- 同联赛同向，绑定提案开球准确相等、90分钟完赛比分相等、完整窗口双向唯一；不用模糊名称或比分消歧。
- 既有18联赛原条目不改不删；新T68条目逐赛事范围限制，旧条目语义不变。
- 每批保存实际捕获/核验时间；新证据不倒填，不用后到证明改写既有冻结结果。
- 主干测试基线4023通过；最终全量pytest、ruff check、ruff format --check；reports≤200KB。

## Review Focus

- 目录中的同ID与主客/日期不符：补时刻不补造、不写比赛表。
- 多原件同fixture冲突/缺页或拒收隐藏竞争者：不推断新绑定。
- 同层互相自证、上层锚被否：阻断与撤下全部传递依赖。
- 36h重叠有多个候选/第三方已有关系：隔离不得因“不唯一”或“已有任意链接”而漏掉。
- 当前配置注入过去归档：无实际观察证据的跨日决定不影响更早cutoff。

### Task 3: 36h隔离与最小跨日决定

Files: `source_result_quarantine.py`、`source_results_audit.py`，必要新增 `cross_day_decisions.py`；相关history/training读取仅必要适配；测试 `tests/test_t68_cross_day.py`，fixtures `data/fixtures/t68/cross_day/`。
Interfaces: 保持 `pending_fd_identity_overlaps`/`exclude_pending_fd_overlaps` 调用兼容；新双边同ID分支不按比分选择，返回明确隔离原因与配对ID。
- [ ] 红测试覆盖12真实ID中的裁剪样本、≤36h与>36h、多候选、第三来源关系、比分不同、单边FD未知旧保护、cutoff双方可知。
- [ ] 仅训练读时隔离，完整组件是否已相连，不因某行曾有其他链接免检；旧可靠源不动。
- [ ] `data/identity_reviews/t68-cross-day.json` 最小same/different决定仅限跨日指定对；完整快照/审批/实际应用时间，导出恢复可选证明，不造超3h T63关系或泛称关系视图。无已批准真实决定时维持隔离。
- [ ] 临时身份审计按联赛汇总计数，其他时间/比分/跨日风险仍逐行；保留原始来源行。
- [ ] 实测固定归档12组只计一次；未受影响输入ID/参数/概率对照交整体验收。



Worktree: /workspace/work/football-t68-a-rest; branch codex/T68-A-identity-and-quarantine. Read AGENTS.md and task139-revised-T68.md/task139-review-T68.md (PR139 3dbabc7f). Task1 is delivered separately PR140 at58548359; latestdocfollowup4427f233. Parent owns docs, finalfullsuite, commit/push/PR and packaging. No production/sportsHTTP/formalalias/registry/modelparams/nations changes, no commits/push/subagents. TDDfixturetests and per-task logs.

Fixed read-only inputs (do not copy entire archive): /workspace/work/football-t68/work/t68-a/fixed-archive (partial e370), model-fixture/data/zucai.db (results-only, immutable SHA719f06b8cf800ccccc70f4eb158ecb092aa15d8da3ee8e29f98a4fca43abfb3a); same-ids-crossday-baseline.json exact12 MLS pairs. Source-audit-baseline.json/csv exact6596rows,6577temporary,2unknownFD,17missingcounterpart; baseline source2730083. Need keep REAL other risks per-match even if temporary identity present; temporary-only summarize byleague, preserve recomputablecounts. Do not call entiredata fullproductionbackup.

Maintain pending_fd_identity_overlaps/exclude_pending_fd_overlaps APIs forlegacy; new same-orientedcanonicalID branch<=36h, crosssourcesoldfd/jc vsaddedapif(andpaidfdorg if eligiblepolicy actuallyuses), no scoresearch, <=36inclusive and >36 reject. Anymultiplecandidates held, relationship tothirdsource doesNOTexempt unlesstheseexacttwoalreadylinked in validwholecomponent. Preserveoriginal3h oneunknownFD restrictions. No widerT63 result_source_links. Frame availability/proof filters must run before applying; eligiblebothsamecutoff, decision appliedfuturecannotalterpast. MinimalPRregistry with fullsnapshots/approvedtime/actualapplicationreceipt; noactualapprovals in config. same_match onlydeduptheseexactcrossdaypairs; different_match allowboth and bypass overlaperror in eligiblecontexts without looseningallpairs; future/malformed/stalesnapshots cannotgrantpermission. Optionalreceipt exportrestorebackwardcompatible, oldarchive mustclearstaleauxiliaryfile. NoBcrossnamestrainingreadchanges.

Tests include realcut12clipped withprovenance, unknownFDlegacy, wronghomeaway/source/league, timestampboundary, unrelatedpointer, multi-sourcegraph, decisionfuture/conflict/drift, idempotentreceipt/restore. Own source_result_quarantine.py/source_results_audit.py plus cross_day_decisions.py ifneeded, cloud_feeds whitelist/restoreoptionalreceipt, necessarypredictreadadapter only forA; doNOTchange modelconfig/fitter. Parent runs26-modeloldnewregressionafteralltasks.

Additional review focus: load_result_links returns dated links and read_history stores verified_result_links; a future link must NOT exempt a pair from quarantine at an earlier cutoff. Resolve component availability at selection time (or keep candidates until selection), including sources excluded by source policy. Existing linked_representatives runs BEFORE exclude_pending_fd_overlaps; if old FD is collapsed to its JC representative, do not inadvertently miss holding the unresolved added API because only fd_candidate_id was searched in present IDs. Add test old reliable entity survives under a different linked representative, and unrelated third-party links do not grant exemption. Must preserve legacy oneunknownFD behavior outside new same-ID branch. Explain/check no sourceoftruth score selection.
Audit aggregation must not simply suppress every row whose current first _row_reason is temporary_team_identity: that reason can mask independent invalid kickoff, reversed IDs, broken counterpart pointer, multi-candidate or score/time conflict. Keep non-identity risk details even for temporary names. Recompute actual summary denominator with raw fullcomparison and distinguish old6596/6577baseline from newclassifiedcounts; do not force outputto19. Protocol8.1: both addedpaid sources (APIF/FDORG) without reliableoldJC/FD and not provenlinked => withhold BOTH, no arbitrarywinner. This is explicitlyapprovedA, notBtrainingdedup.

Parent supplementary read-only inventories: /workspace/work/football-t68/work/t68-a/unbound-crossday-candidates.json found5unboundAPIF pairs withoneorientedknownID and3<delta<=36; /workspace/work/football-t68/work/t68-a/unbound-crossday-review-enumeration.json is ONLY retrospective24h+equalscorelocator13pairs9distinctAPIF, not proof (multiplecandidates). Originalreview11hasnoIDlist; doNOTuse scorelocatorasbinding/dedupauthority orforce11. State limitationifnecessary; simulate validatednewbinding transition in fixtures and proveallresultingsameIDpairsheld irrespective scores. Registrydecisions minimalCROSSDAY only, avoidwidening3hglobalguard; followprotocol8.1 exactly.

Parent prepared read-only real12clip /workspace/work/football-t68/work/t68-a/crossday-real12-clipped.json (22KB,24match/resultrows11teams,actualfixeddbSHA+dataref), cancopytocrossdayfixturewithproperprovenanceandtests. Itisriskinventory,not same-matchauthorization.
