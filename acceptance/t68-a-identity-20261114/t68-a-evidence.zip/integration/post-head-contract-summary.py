"""Inspect existing validator inputs; does not relax or replace its rules."""
import collections,json
from bisect import bisect_left,bisect_right
from datetime import datetime,timezone,timedelta
from pathlib import Path
from zucai.identity_binding_archive import load_archive
from zucai.identity_binding import _clock,_pair_reasons
from zucai.sources.apif_aliases import valid_identity_category
from zucai import jc_catalogue_kickoffs as clocks
p=Path('work/t68-a');root=p/'post-head-archive'
inputs=load_archive(root,fd_raw_dir='/workspace/work/t66-review-20261114/inputs/raw/football-data-co-uk/2026-11-14')
plan=json.loads((p/'post-head-kickoff-plan.json').read_bytes());selected=plan['selected']
raw_by_id={f"jc:{r['match_id']}":r for r in selected}
rawgroups={'A_direct':[r for r in selected if r['league_id'] not in clocks.GENERIC_IDS],
           'B_excluded':[r for r in selected if r['league_id'] in clocks.GENERIC_IDS],
           'A_and_B':selected}
def denominator(rows):
 return dict(matches=len(rows),unique_jc_team_ids=len({r[s+'_team_id'] for r in rows for s in ['home','away']}),
             competition_jc_team_items=len({(r['league_id'],r[s+'_team_id']) for r in rows for s in ['home','away']}))
apif_by_league=collections.defaultdict(list)
for i,r in enumerate(inputs['apif']):
 if (when:=_clock(r)) is not None:apif_by_league[r['league']].append((when,i))
for values in apif_by_league.values():values.sort()
heads=json.loads((p/'post-head-input-analysis.json').read_bytes())['heads']
contracts=[];league_stats=collections.defaultdict(collections.Counter)
for row in inputs['official']:
 if row['match_id'] not in raw_by_id:continue
 targets={s:inputs['teams'].get(str(row[s])) for s in ['home','away']}
 missing=[s for s,t in targets.items() if not t or t.get('ambiguous')]
 types=[s for s,t in targets.items() if t and valid_identity_category(t.get('category'))]
 record=dict(match_id=row['match_id'],league=row['league'],kickoff_utc=row['kickoff_utc'],
             home=row['home'],away=row['away'],home_source_id=row['home_source_id'],away_source_id=row['away_source_id'],
             unresolved_canonical_sides=missing,canonical_category_verified_sides=types,
             provenance=row['provenance'])
 when=_clock(row);neighbors=[]
 if when:
  group=apif_by_league[row['league']];lo=bisect_left(group,(when-timedelta(hours=3),-1));hi=bisect_right(group,(when+timedelta(hours=3),len(inputs['apif'])))
  neighbors=[inputs['apif'][i] for _,i in group[lo:hi]]
 exact=[r for r in neighbors if _clock(r)==when]
 typed=lambda r:all(valid_identity_category(r.get(s+'_category')) for s in ['home','away'])
 record.update(new_head=row['match_id'].removeprefix('jc:') in heads,
               source_window_rows=len(neighbors),source_window_typed_rows=sum(map(typed,neighbors)),
               source_exact_clock_rows=len(exact),source_exact_clock_typed_rows=sum(map(typed,exact)))
 contracts.append(record);stats=league_stats[row['league']];stats['matches']+=1;stats['verified_clock']+=_clock(row) is not None
 stats['both_canonical_targets']+=not missing;stats['one_or_more_unresolved_targets']+=bool(missing)
 stats['both_canonical_categories']+=len(types)==2
rawstats=collections.defaultdict(collections.Counter)
for row in inputs['apif']:
 if row['league'] not in inputs['summary']['new_route_leagues']:continue
 stats=rawstats[row['league']];stats['raw_rows']+=1;stats['both_source_categories']+=all(valid_identity_category(row.get(s+'_category')) for s in ['home','away'])
 stats['one_or_more_missing_categories']+=any(not valid_identity_category(row.get(s+'_category')) for s in ['home','away'])
others=collections.defaultdict(list)
for i,r in enumerate(inputs['official']):
 if (when:=_clock(r)) is not None:others[r['league']].append((when,i))
for v in others.values():v.sort()
conflict=[]
for row in inputs['apif']:
 if '10184' not in {str(row[s]) for s in ['home','away']}:continue
 when=_clock(row);neighbors=[]
 if when:
  group=others[row['league']];lo=bisect_left(group,(when-timedelta(hours=3),-1));hi=bisect_right(group,(when+timedelta(hours=3),len(inputs['official'])))
  for instant,i in group[lo:hi]:
   other=inputs['official'][i]
   neighbors.append(dict(match_id=other['match_id'],kickoff_utc=other['kickoff_utc'],score=other['score'],
                         home_source_id=other.get('home_source_id'),away_source_id=other.get('away_source_id'),
                         home=other['home'],away=other['away'],reasons=_pair_reasons(row,other,inputs['teams'])))
 conflict.append(dict(row=row,neighbors=neighbors,not_an_association=True))
new_contracts=[r for r in contracts if r['new_head']]
new_checks=dict(matches=len(new_contracts),unresolved_canonical_target=sum(bool(r['unresolved_canonical_sides']) for r in new_contracts),
  no_two_verified_target_categories=sum(len(r['canonical_category_verified_sides'])!=2 for r in new_contracts),
  no_source_in_window=sum(not r['source_window_rows'] for r in new_contracts),
  source_window_exists_but_none_fully_typed=sum(bool(r['source_window_rows']) and not r['source_window_typed_rows'] for r in new_contracts),
  at_least_one_fully_typed_source_in_window=sum(bool(r['source_window_typed_rows']) for r in new_contracts),
  no_exact_clock_source=sum(not r['source_exact_clock_rows'] for r in new_contracts),
  exact_clock_exists_but_none_fully_typed=sum(bool(r['source_exact_clock_rows']) and not r['source_exact_clock_typed_rows'] for r in new_contracts),
  at_least_one_fully_typed_source_at_exact_clock=sum(bool(r['source_exact_clock_typed_rows']) for r in new_contracts),
  counts_overlap=True,window_is_not_identity_proof=True)
result=dict(new_head_contract_checks=new_checks,observed_utc=datetime.now(timezone.utc).isoformat(),denominators={k:denominator(v) for k,v in rawgroups.items()},
            official_by_league=dict(league_stats),apif_categories_by_league=dict(rawstats),
            official_totals=sum(league_stats.values(),collections.Counter()),official_contracts=contracts,
            provider_10184=dict(raw_rows=len(conflict),rows=conflict),summary=inputs['summary'])
(p/'post-head-contract-summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['observed_utc','denominators','official_totals','new_head_contract_checks']},ensure_ascii=False))
