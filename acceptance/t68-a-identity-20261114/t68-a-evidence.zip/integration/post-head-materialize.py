"""Build an isolated, hash-verified partial archive; never writes linked inputs."""
import argparse, hashlib, json, os, subprocess
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

COMMIT='afdf86dd9adbd5cf9bec0e5d3dee832eba1b208a'
ROOT=Path('/workspace/work/football-t68-a-rest')
OLD=Path('/workspace/work/football-t68/work/t68-a/fixed-archive')
OUT=ROOT/'work/t68-a/post-head-archive'
WORK=ROOT/'work/t68-a'

def git(*args):
    return subprocess.check_output(['git',*args],cwd=ROOT)
def sha(raw): return hashlib.sha256(raw).hexdigest()
def blob(raw): return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()

args=argparse.ArgumentParser();args.add_argument('--write',action='store_true');args=args.parse_args()
manifest_raw=git('show',COMMIT+':feed_manifest.json'); manifest=json.loads(manifest_raw)
old_blobs={};old_names=set()
for path in OLD.rglob('*'):
    if path.is_file():
        raw=path.read_bytes();old_blobs.setdefault(blob(raw),path);old_names.add(path.relative_to(OLD).as_posix())
selected=[]
for line in git('ls-tree','-r','-l',COMMIT).decode().splitlines():
    props,name=line.split('\t',1);mode,kind,oid,size=props.split()
    if name in old_names or name.startswith(('state/catalogue/','state/alias_candidates/','raw/jc-kickoffs/')):
        if kind!='blob': raise ValueError(name)
        selected.append(dict(path=name,git_blob=oid,bytes=int(size)))
missing=old_names-{r['path'] for r in selected}
if missing: raise ValueError(('Old selected path absent at new commit',missing))
unique_new={r['git_blob']:r['bytes'] for r in selected if r['git_blob'] not in old_blobs}
summary=dict(commit=COMMIT,selected_files=len(selected),logical_bytes=sum(r['bytes'] for r in selected),
             reused_from_old_files=sum(r['git_blob'] in old_blobs for r in selected),
             unique_new_blobs=len(unique_new),new_allocated_bytes_estimate=sum(unique_new.values()),
             available_bytes=os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize,
             reserved_for_model_bytes=108*1024*1024,manifest_sha256=sha(manifest_raw),
             counts=Counter('/'.join(r['path'].split('/')[:3]) for r in selected))
(WORK/'post-head-input-plan.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False))
if not args.write: raise SystemExit
if OUT.exists(): raise FileExistsError(OUT)
# Leave room for two output sets and the parent's model acceptance copy.
assert summary['available_bytes'] > summary['new_allocated_bytes_estimate']+220*1024*1024
OUT.mkdir()
content_sources=dict(old_blobs); records=[]
proc=subprocess.Popen(['git','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
try:
    for item in selected:
        name,oid=item['path'],item['git_blob'];target=OUT/name;target.parent.mkdir(parents=True,exist_ok=True)
        source=content_sources.get(oid)
        if source:
            os.link(source,target);raw=target.read_bytes();method='hardlink'
        else:
            proc.stdin.write((oid+'\n').encode());proc.stdin.flush()
            head=proc.stdout.readline().decode().split()
            assert head==[oid,'blob',str(item['bytes'])],head
            raw=proc.stdout.read(item['bytes']);assert proc.stdout.read(1)==b'\n'
            assert len(raw)==item['bytes'] and blob(raw)==oid
            target.write_bytes(raw);method='git_blob';content_sources[oid]=target
        digest=sha(raw); declared=manifest['files'].get(name)
        if declared is not None: assert digest==declared,(name,digest,declared)
        records.append(dict(item,sha256=digest,manifest_sha256=declared,method=method,
                            linked_from=str(source) if source else None))
finally:
    proc.stdin.close();proc.wait()
result=dict(summary,materialized_utc=datetime.now(timezone.utc).isoformat(),
            root=str(OUT),old_root_read_only=str(OLD),files=records)
(WORK/'post-head-input-manifest.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('Materialized and SHA checked',len(records))
