# Task4 PR139 最新增补：回填与每日 collection 隔离

按 PR139 `f963cfe95db4c6104914cb967e445c1c87198b69` 相对 `3dbabc7` 的任务第 5 节 2 增补实施。父级全量 `a-rest-integration-2-*`（4321/0/0/0）完成并明确 GO 后才开始写产品。此前 freeze-3、红绿日志、审查修复报告保持原件。

## 发布与读取契约

- APIF、FDORG、FD 的普通回填和 catalogue 回填分别写 `collection.apif_backfill`、`fdorg_backfill`、`fd_backfill`；同一来源仍是最近一次回填报告，报告的 `operation=backfill/catalogue-backfill` 区分入口。
- 回填把独立报告合入既有 collection，原每日来源记录逐值保留；本轮 Actions 摘要从独立键取原报告，入库、请求、held、deferred、真实失败计数均不改。
- sync/apis 保留独立历史回填，但 `collection_status` 排除历史回填记录。当前回填则纳入其自己的报告状态，真实失败仍 partial；任何真实 `pending_result_count` 仍使全局 partial。内部 `export_feeds(..., status_collection=...)` 仅指定状态汇总输入，不改变被归档的完整 collection；未传时保留旧行为。
- 旧 `collection.apif/fdorg/fd` 只有 `operation` 明确为 `backfill` 或 `catalogue-backfill`，且可选 `source` 与键不冲突时，才移入独立键。FD 旧普通报告可无 `source`。无 operation、未知 operation、来源冲突的旧值不猜、不改成成功。若旧槽与独立槽同时存在不同报告，既有独立槽保留，旧报告另存 `<source>_backfill_legacy_<record SHA256>`，避免丢失；该指纹是排序 JSON 的记录指纹，不是 raw 证据哈希。
- 日报完整 `generate` 顶部四来源状态、异常区来源状态/重复/拒收/held，以及 APIF 配额记录都使用同一每日视图。直接只读旧明确回填清单时，缺每日证据显示“未记录”，不显示旧回填 partial/523；归档输入 bytes 不变。没有来源标记的旧值仍照录。
- 无新 CLI 参数；`backfill --relink-jc` / `--relink-fdorg`、probe、identity、reconcile 的既有入口和键保持不变。T2/T3 身份与回执防护未改。

## 离线验证

新增 `tests/test_t68_backfill_collection.py`，复用已检入 fixtures 和 responses，仅虚拟 key。三来源 × 普通/catalogue × 成功/真实失败使用实际 `cloud_feeds.main`、导出恢复、`GITHUB_STEP_SUMMARY` 流程；断言原每日记录保留、独立键和本轮状态准确，其他历史 partial 不污染。本轮失败 APIF 回填随后只跑真实 JC sync，不发 APIF 请求，保持上一次每日 APIF 行，完整保留失败回填且总状态恢复为当前每日 complete。

旧普通/catalogue 报告经过真实 sync/apis 的迁移与状态汇总、未知旧值保留、命名空间冲突保留，以及真实 `generate` 全文顶部/异常区一致性均覆盖。旧 FD 无 source 的形状也覆盖。原回填测试仅更新新键读取；原 held 回填测试不再把回填当日报，独立每日 held/混合拒收测试仍保留。relink 原计数断言未改。

证据（均保留，不覆盖）：

- `task-4-separate-red.log/.xml`：13 failed / 1 passed，重现旧来源覆盖、旧回填继承和日报错误归类。
- `task-4-separate-green1.log/.xml`：6 failed / 8 passed，6 项是新增测试误以为旧回填摘要包含 run ID；校正为既有实际标题与新增计数，未修改产品摘要格式。
- `task-4-separate-green2.log/.xml`：253 passed。
- `task-4-separate-final.log/.xml`：537 passed，31.74s；随后父级指出日报顶部漏读，该轮不能作为最终冻结验证。
- `task-4-separate-header-red.log/.xml`：真实全文 6 failed / 3 passed（21 deselected），明确回填顶部错误显示 partial；无 operation 旧值保持正确。
- 最终 `task-4-separate-final2.log/.xml`：**546 tests，0 failures/errors/skipped，JUnit 94.731s**，含新增 30 项。Ruff check、format check（8 文件）通过，`git diff --check` 通过；文件与日志 SHA 冻结在 `task-4-owned-freeze-4.json`。

本阶段产品仅改 `cloud_feeds.py` 与 `daily_digest.py`。`identity_daily_gate.py` 及其余已冻结 Task4 产品 SHA 与 freeze-3 一致，训练模块未改。父级继续负责独立复查、最终全量、26 模型、最终恢复、统一文档和提交推送。
