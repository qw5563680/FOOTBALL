通过

这是 Task4 的 fresh 内部审查与限定复查结论，不是 Claude 正式批准，也不是用户合并授权。初轮三条 Important 已解决，当前没有未解决 Critical / Important，可进入父级最终整合。首轮报告与失败证据继续保留在 `task-4-review-initial.md`、`task-4-review-initial-with-reporting.md` 及各 counterexample 日志。

## 基线与范围

- HEAD：`13e968dd2725338b0451aac886d6834addb19921`。
- 最终审查对象：`task-4-owned-freeze-3.json`，SHA256 `6406fe6d10c64c7d1ba719d117d72a3c4bed2b71a9c457b23fe5c1f4555e2c89`，20个owned文件。
- 先读变更代码、调用的JC原件验证器和新增测试，再核对 `task-4-review-fixes.md`。复查仅涵盖 I1/I2/I3、旧回填摘要兼容及相关回归；不重复全量pytest或26模型拟合。
- reviewer只写 `work/t68-a/task-4-review*` 证据，未改产品源码/产品测试/正式数据，未commit、push、开PR、触发Actions、发体育HTTP或用正式key。

## Spec 与 quality

**Spec：本轮实现范围通过。** 请求预算分流、held分计及保护、候选按安全赛事归属隔离、普通Actions/daily/backfill展示、只读gate的固定分母与证据门槛，在已读代码和限定离线验收范围内符合要求。I1新增近期官方原件入口，没有删掉真实官方分母要求；I2没有以交集、无凭据赛季提示或解释文本冒充已解决；I3未把旧字段缺失填成0。

**Quality：通过限定内部复查。** 独立定向71项通过，无未解释失败。20个owned文件复查前后均与冻结一致。初轮63项已验证且未变的预算/候选/导入保护仍适用；此次改动没有触及其实现。父级最终全量、模型和正式规模恢复仍为独立整合门，不由本结论替代。

## 分级与三条问题的关闭证据

### Critical

无已确认项。

### Important

无未解决项；以下初轮问题已关闭。

1. **I1 双窗口互斥已修复。** `src/zucai/identity_daily_gate.py:229` 新增 `_recent_official`，12个完整月继续由固定归档提供；近期缺失北京日从 `recent_replay.official_originals` 校验URL/日页参数/HTTP/raw与sidecar SHA/完整分页/官方字典/球队ID。`:425` 核验重放列出的官方ID集合。独立测试 `task-4-review3-gate-boundaries.py::test_review3_midmonth_with_new_official_match_is_ready_only_for_review` 使用统一截止 `2026-11-14T10:43:21.807840+00:00`、31个UTC日期原件、11月1日至13日独立官方补件，并增加11月5日 `jc:21` / `apif:11`。整体assess达到ready；12月窗口仍止10月31日、其场次仍为1，近期分母为 `jc:20,jc:21`。缺官方日、真实两页只给第一页、错行日期、官方赛事ID冲突、重放漏官方ID、缺UTC边界日、sidecar SHA错七项全部返回insufficient。原I1探针只有API日期原件，缺11月官方材料，仍不应通过；原文件与失败记录保留，未删分母校验来“变绿”。

2. **I2 此前held静默消失已修复。** `identity_daily_gate.py:168`–224 保留全部相关held ID，只有匹配已验证原件ID/raw SHA的明确别季证据才列 `excluded_other_season_ids`。未解释缺失ID失败；缺赛事范围或与原件冲突失败。原 `task-4-review-counterexamples.py::test_prior_held_id_cannot_disappear_without_resolution_or_reason` 未修改即通过。独立完整bundle加 `apif:999` 的 still_held 说明后，整体状态为blocked，`:667` 的 `current_season_held_unresolved` 保留，resolved_ids为空，不把有说明等同于已解决。

3. **I3 日报拒收计数已修复。** `src/zucai/daily_digest.py:221`–227 分别显示疑似重复、单行拒收、未绑定暂缓；缺rejected字段经 `_text` 显示“未记录”。原 `task-4-review-reporting-counterexample.py` 从真实离线import得到1held+1rejected，未改即通过。3份T25 expected Markdown仅增加新显示列，仍是离线fixture，不是旧生产日报改写。

4. **父级首轮整合摘要兼容失败已关闭。** `src/zucai/cloud_api_backfill.py:406`–408 对旧报告缺 `failed_scopes` 用 `.get(..., [])`；`test_collection_and_backfill_summaries_count_real_late_jc_links` 的真实lateJC计数断言保留并通过，新增默认摘要值也通过。

### Suggestion

无阻止整合的额外建议。本轮只完成实现和离线审查，不扩大到正式绑定批准、daily开启或B段实现。

## 实跑证据

- `task-4-review3-freeze-before.json` / `task-4-review3-freeze-after.json`：**20/20 SHA一致**，freeze SHA也一致。父级文档不在owned清单内。首轮 `after-findings` 曾验证16/16一致；首轮最后一次检查发现父级受控修复已开始，已单独保留记录，没有混用两个版本。
- `task-4-review3-targeted.log` / `.xml`：**71 tests，0 failures，0 errors，0 skipped，3.340s**；输入与临时证明文件在 `task-4-review3-targeted-artifacts/`。
- 新独立文件 `task-4-review3-gate-boundaries.py` 共9项：1个充分月中整体正向、7个破坏证据的负向、1个解释后仍blocked；全部HTTP由responses拦截，原件仅由已入库fixture派生。
- 同轮还跑原I2/I3反例、`tests/test_t68_daily_gate.py`、`tests/test_t68_collection_status.py`、真实lateJC摘要回归、`tests/test_daily_digest.py`。普通三日Actions路径含held的实跑测试再次通过。
- 初轮独立 `task-4-review-targeted.xml`：63项通过；其中新写预算分页/FDORG id-code矛盾/真实混合held-risk三项通过，A2正常导入binding_scope与A3回执roundtrip/旧档残留清理通过。相关源码在freeze3未变。
- 核对实现方 `task-4-final5-pytest.xml`：404 tests，0 failures/errors/skipped，24.347s。未把实现方结果冒称本reviewer重跑。
- 父级首轮全量4305测的1个失败与冻结日志保留为 `a-rest-integration-1-*`，不是通过证据。父级报告的正式副本207导出内容文件、SQLite逻辑表、候选138/audit26以及DB bytes恢复对照，本reviewer没有重复执行，属于父级整合证据。

本轮复跑命令：

```sh
PYTHONPATH=src:tests /workspace/work/t48-venv/bin/python -m pytest -q \
  work/t68-a/task-4-review3-gate-boundaries.py \
  work/t68-a/task-4-review-counterexamples.py::test_prior_held_id_cannot_disappear_without_resolution_or_reason \
  work/t68-a/task-4-review-reporting-counterexample.py \
  tests/test_t68_daily_gate.py tests/test_t68_collection_status.py \
  tests/test_jc_relink_workflow.py::test_collection_and_backfill_summaries_count_real_late_jc_links \
  tests/test_daily_digest.py
```

## 固定真实证据及限制

再次核验 `task-4-fixed-evidence/daily-gate-all62-review3-final.json` SHA256=`c6203407ff18d7d492cad3ee6f97bd51c42a26bd1580255710643dadf8b62cb4`，与修前同内容：62路线、1083场、32零场路线，全部insufficient。逐code官方分母独立复算由父级提供，本reviewer核对产物总数与SHA，没有冒称另算全目录。

固定归档缺11月完整官方/API日期材料、当前季重放与完整开启证据；新routes无正式current_season仍null，不取最大历史年。0/0仍null。447项只是独立的旧预算解释与离线200次请求模拟，39个有raw partial保持不变；不改旧日志。138旧候选只有保留证据，普通日期raw为0份，不能称真实隔离重放。合成ready正向只证明程序路径可达，不证明真实赛事可开启。

## 固定四问

1. **是否碰冻结 predictions、parameters、run_log？** Task4不写这些产物，也不改既有账本/评分/日报。3份新改Markdown是离线golden fixture。gate只写归档外的新报告；reviewer只写work证据。全归档不可变文件验收归父级整合。
2. **是否影响其他比赛匹配、路由或概率？** 正式registry、来源、params、API key和B泛称实现未在Task4改变；held改变报告分类，仍不入库。候选变化只允许此前被其他赛事坏行连带阻断的案例。独立正向新增合成 `jc:21/apif:11` 仅用于近期分母测试；初轮 `apif:91001` held、`apif:91002` suspected未新增Match。真实普通日期raw缺失，无法逐ID穷举新候选；全模型输入与概率结论待父级26模型对照。
3. **是否只用开球前可得信息？** 本模块处理赛后历史原件和身份/开启验收，不是赛前特征。没有放宽available_utc或训练来源规则，没有把离线审查证据冒称当时赛前可见。模型时标整合由父级验证。
4. **测试是否覆盖改动点？** 71项覆盖修订三问题、月中整体正向及七类缺证据、held解释不自动放行、旧摘要兼容和日报缺字段语义；初轮相关保护回归保留。剩余是真实当季/30日材料、正式配置后的连续三次线上链路与父级全量/模型，不可由fixture代替。

可以继续父级最终整合；该结论不授权真实HTTP、正式绑定、daily变更、生产发布或合并。`ready_for_review`始终只表示材料可交审。
