"""Independent review probes. Fixtures only; intentionally preserve failing expectations."""
import json
from copy import deepcopy
from datetime import UTC, date, datetime, timedelta
from hashlib import sha256
from pathlib import Path

import pytest
import responses

from zucai.identity_daily_gate import _current_replay, _recent_replay
from zucai.sources.base import RawStore

ROOT = Path(__file__).resolve().parents[2]
FACTS = ROOT / "data/fixtures/t68/daily_gate/facts.json"


@pytest.fixture(autouse=True)
def offline_only():
    with responses.RequestsMock():
        yield


def ref(root, name, value):
    raw = json.dumps(value).encode()
    (root / name).write_bytes(raw)
    return dict(path=name, sha256=sha256(raw).hexdigest())


def test_midmonth_complete_daily_originals_are_accepted(tmp_path):
    """A real 12-complete-month window cannot simultaneously include November 13."""
    facts = json.loads(FACTS.read_bytes())
    template = json.loads((ROOT / "data/fixtures/t14/apif.json").read_bytes())
    originals = []
    for offset in range(31):
        day = date(2026, 10, 14) + timedelta(days=offset)
        doc = deepcopy(template)
        doc["parameters"] = {"date": day.isoformat()}
        if day == date(2026, 10, 20):
            row = doc["response"][0]
            when = datetime(2026, 10, 20, 12, tzinfo=UTC)
            row["league"]["id"] = 307
            row["fixture"].update(id=10, date=when.isoformat(), timestamp=int(when.timestamp()))
            row["teams"]["home"]["id"] = 10
            row["teams"]["away"]["id"] = 11
        else:
            doc.update(response=[], results=0)
        raw = json.dumps(doc).encode()
        path = RawStore(tmp_path).save(
            "api-football", "fixtures", raw, "json", status_code=200,
            url="https://v3.football.api-sports.io/fixtures?date=" + day.isoformat(),
            captured_at=datetime(2026, 11, 14, tzinfo=UTC),
        )
        originals.append(dict(path=path.relative_to(tmp_path).as_posix(), sha256=sha256(raw).hexdigest()))
    replay = ref(tmp_path, "replay.json", dict(
        fixture_ids=["apif:10"], raw_sha256=[r["sha256"] for r in originals], inserted=0,
        risk_ids=[], outcomes=[dict(fixture_id="apif:10", outcome="unchanged")],
    ))
    result = _recent_replay(facts, "307", dict(originals=originals, results=replay),
                            tmp_path, date(2026, 10, 15), date(2026, 11, 13))
    assert result["distinct_fixtures"] == 1


def test_prior_held_id_cannot_disappear_without_resolution_or_reason(tmp_path):
    facts = json.loads(FACTS.read_bytes())
    current = ref(tmp_path, "current.json", dict(processed_files=1, scopes=[dict(
        code="307", season=2026, status="complete", parsed_matches=1,
        raw={"sha256": "a" * 64}, held_unbound=0, suspected_duplicates=0, rejected_rows=0,
    )]))
    raw = ("raw_sha256,league,provider_match_id,kickoff_utc,season\n"
           + "a"*64 + ",测试联赛,999,2026-10-21T12:00:00Z,2026\n").encode()
    (tmp_path / "held.csv").write_bytes(raw)
    section = dict(report=current, held_before=dict(path="held.csv", sha256=sha256(raw).hexdigest()))
    with pytest.raises(ValueError, match="unresolved|unexplained|missing"):
        _current_replay(facts, "307", section, tmp_path)
