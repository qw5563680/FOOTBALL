"""Offline core/results/candidate roundtrip; not a production backup or deployment."""
import hashlib
import json
import shutil
import sqlite3
from datetime import UTC, date, datetime
from pathlib import Path
from unittest.mock import patch
from zoneinfo import ZoneInfo

import requests
from zucai.cloud_feeds import export_feeds, restore_feeds
from zucai.source_results_audit import audit_source_results

HERE = Path(__file__).resolve().parent
BASE = Path('/workspace/work/football-t68/work/t68-a')
ROOT = HERE / 'a-rest-roundtrip'
ORIGINAL = BASE / 'model-fixture/data/zucai.db'
QUEUE = HERE / 'task-2-verified-replay/apif.json'
EXPECTED = '719f06b8cf800ccccc70f4eb158ecb092aa15d8da3ee8e29f98a4fca43abfb3a'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def table_inventory(path):
    out = {}
    with sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True) as db:
        db.execute('PRAGMA query_only=ON')
        tables = [r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
        for table in tables:
            quoted = '"' + table.replace('"', '""') + '"'
            cols = [r[1] for r in db.execute('PRAGMA table_info(' + quoted + ')')]
            digest, count = hashlib.sha256(), 0
            digest.update(json.dumps(cols).encode())
            for row in db.execute('SELECT * FROM ' + quoted + ' ORDER BY ' + ','.join(str(i+1) for i in range(len(cols)))):
                digest.update(json.dumps(row, ensure_ascii=False, separators=(',', ':')).encode() + b'\n')
                count += 1
            out[table] = dict(rows=count, logical_sha256=digest.hexdigest())
    return out


assert sha(ORIGINAL) == EXPECTED
ROOT.mkdir(exist_ok=False)
before = ROOT / 'before/data/zucai.db'
before.parent.mkdir(parents=True)
shutil.copy2(ORIGINAL, before)
candidate = before.parent / 'state/alias_candidates/apif.json'
candidate.parent.mkdir(parents=True)
shutil.copy2(QUEUE, candidate)
audit_before = before.parent / 'state/audit/apif_results_crosscheck.csv'
with patch.object(requests.sessions.Session, 'request', side_effect=AssertionError('Offline roundtrip forbids HTTP')):
    first_audit = audit_source_results(before, audit_before)
    first_tables = table_inventory(before)
    first = export_feeds(before, ROOT / 'archive-1', date(2026, 11, 14), 't68-a-offline-roundtrip-1')
    restored = ROOT / 'restored/data/zucai.db'
    restore_feeds(ROOT / 'archive-1', restored)
    second_tables = table_inventory(restored)
    audit_after = restored.parent / 'state/audit/apif_results_crosscheck.csv'
    second_audit = audit_source_results(restored, audit_after)
    assert first_tables == second_tables, 'Logical database rows changed on restore'
    assert first_audit == second_audit, 'Audit summary changed on restore'
    assert sha(audit_before) == sha(audit_after), 'Audit CSV changed on restore'
    assert sha(candidate) == sha(restored.parent / 'state/alias_candidates/apif.json') == sha(QUEUE)
    second = export_feeds(restored, ROOT / 'archive-2', date(2026, 11, 14), 't68-a-offline-roundtrip-2')
    assert first['counts'] == second['counts']
    assert first['sources'] == second['sources']
    differing = {key: (first['files'].get(key), second['files'].get(key)) for key in first['files'].keys() | second['files'].keys() if first['files'].get(key) != second['files'].get(key)}
    assert not differing, differing
assert sha(ORIGINAL) == EXPECTED and sha(before) == EXPECTED
now = datetime.now(UTC)
summary = dict(status='passed', observed_utc=now.isoformat(), observed_beijing=now.astimezone(ZoneInfo('Asia/Shanghai')).isoformat(),
               purpose='Fixed results/identity/candidates only; not full production backup',
               source_database_sha256=EXPECTED, restored_database_sha256=sha(restored),
               tables=first_tables, audit=first_audit, audit_csv_sha256=sha(audit_after), candidate_sha256=sha(candidate),
               exported_files=len(first['files']), all_exported_content_hashes_equal=True, http_calls=0,
               source_archive_commit='e370db1d5cabe1cb33ddbfff3029c6d802bb8992')
(ROOT / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(summary, ensure_ascii=False))
