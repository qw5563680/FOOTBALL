"""Independent collection namespace probes; no live requests or real Release actions."""
import json
from copy import deepcopy

import pytest
import responses

from test_cloud_feeds import seed_cloud_archive, mock_calendar, mock_result_day, run_cloud_sync
from test_stats_batch import batch as batch, run as run_stats
from zucai.cloud_feeds import archive_info, daily_collection, separate_backfill_collection


@pytest.fixture(autouse=True)
def offline_only():
    with responses.RequestsMock():
        yield


def historical(provider, run_id="old"):
    return dict(source=provider, operation="backfill", status="partial", run_id=run_id,
                suspected_duplicates=523, rejected_rows=7)


def test_late_daily_statistics_do_not_reintroduce_historical_backfill_partial(batch):
    database, archive, release, client = batch
    path = archive / "feed_manifest.json"
    meta = json.loads(path.read_bytes())
    daily = {p: dict(status="complete", run_id="current-daily") for p in ("jc", "apif", "fdorg", "fd")}
    meta.update(collection={**daily, "apif_backfill": historical("apif")}, collection_status="complete")
    path.write_text(json.dumps(meta))
    with responses.RequestsMock() as http:
        result = run_stats(batch, run_id="review-late-daily", daily=True)
        assert not http.calls
    assert result["mode"] == "daily" and result["status"] == "complete", result
    after = archive_info(archive)
    assert after["pending_result_count"] == 0
    assert all(after["collection"][p] == row for p, row in daily.items())
    assert after["collection"]["apif_backfill"] == historical("apif")
    assert after["collection_status"] == "complete"


def test_only_jc_sync_preserves_real_pending_despite_history_filter(tmp_path, monkeypatch):
    archive = seed_cloud_archive(tmp_path)
    path = archive / "feed_manifest.json"
    meta = json.loads(path.read_bytes())
    old_daily = dict(status="complete", run_id="prior-daily", suspected_duplicates=0)
    meta["collection"] = {"apif": old_daily, "apif_backfill": historical("apif")}
    path.write_text(json.dumps(meta))
    with responses.RequestsMock() as http:
        mock_calendar(http)
        mock_result_day(http, "2026-10-30", [{"matchId": 4}])
        mock_result_day(http, "2026-10-31", [{"matchId": 5, "sectionsNo1": "9:0"}])
        mock_result_day(http, "2026-11-01", [{"matchId": 7}])
        run_cloud_sync(monkeypatch, tmp_path / "sync", archive, "2026-11-01")
        assert not any("api-sports.io" in call.request.url for call in http.calls)
    after = archive_info(archive)
    assert after["collection"]["apif"] == old_daily
    assert after["collection_status"] == "partial"
    assert after["pending_result_count"] == 1
    assert after["collection"]["jc"]["rejected_rows"] == 1


@pytest.mark.parametrize("provider", ["apif", "fdorg", "fd"])
def test_legacy_migration_is_idempotent_and_preserves_conflicting_records(provider):
    old, newer = historical(provider), historical(provider, "newer")
    original = {provider: old, provider + "_backfill": newer}
    before = deepcopy(original)
    moved = separate_backfill_collection(original)
    assert original == before
    assert moved[provider + "_backfill"] == newer
    assert len(moved) == 2 and old in moved.values()
    assert separate_backfill_collection(moved) == moved
    assert daily_collection(moved) == {}


@pytest.mark.parametrize("change", [{"operation": "reconcile"}, {"operation": None}, {"source": "fdorg"}])
def test_uncertain_legacy_status_is_not_reclassified(change):
    record = {**historical("apif"), **change}
    original = {"apif": record}
    assert separate_backfill_collection(original) == original
    assert daily_collection(original) == original
