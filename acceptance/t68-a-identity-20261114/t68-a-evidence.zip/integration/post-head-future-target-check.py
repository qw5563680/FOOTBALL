"""Synthetic read-only check: explicit future canonical targets must conflict."""
import json
from copy import deepcopy
from pathlib import Path
from zucai.identity_binding import propose_bindings
p=Path('work/t68-a');base=json.loads(Path('data/fixtures/t68/identity/strict-pair.json').read_bytes())
rows=[];official=[];teams={};kinds=['national/men/U23/standard','national/men/U23/asian_games']
for i,kind in enumerate(kinds):
 source=deepcopy(base['apif'][0]);target=deepcopy(base['official'][0]);league=f'Synthetic category {i}'
 source.update(match_id=f'apif:synthetic-{i}',league=league,competition_id=str(98+i),home='10184',away=str(102+i),home_category=kind,away_category=kind)
 target.update(match_id=f'jc:synthetic-{i}',league=league,competition_id=str(98+i),home=str(1+2*i),away=str(2+2*i))
 for side in ['home','away']:teams[target[side]]=dict(name=f'Synthetic {target[side]}',category=kind)
 rows.append(source);official.append(target)
results=[]
for anchor in [False,True]:
 formal={'Synthetic category 0':{'10184':dict(canonical='Synthetic 1',status='approved')}} if anchor else {}
 r=propose_bindings(rows,official,teams,formal=formal)
 active=[e for es in r['apif'].values() for e in es.values() if e.get('evidence_status')=='strict_verified']
 assert not active
 results.append(dict(formal_anchor=anchor,strict_verified=len(active),summary=r['summary'],proposals=r['apif'],issues=r['unverified']))
(p/'post-head-future-target-check.json').write_text(json.dumps(dict(synthetic=True,not_approval_evidence=True,results=results),ensure_ascii=False,indent=2)+'\n')
print(json.dumps([dict(formal_anchor=r['formal_anchor'],strict_verified=r['strict_verified'],withdrawn=r['summary']['withdrawn']) for r in results]))
