# T68 A 段实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task. 使用 `- [ ]` 记录步骤。本计划依据已获条件批准的方案，不再次请求已授权的A段实施许可。

**Goal:** 提供严格绑定证据与补时刻工具，修正跨日重复和采集口径，产出可复核离线证据。
**Architecture:** 沿用正式候选队列、reconcile/relink-jc、原来源保存策略；只新增离线校验/审核工具和局部保护。B段仅文档，不实现。
**Tech Stack:** Python 3.12、SQLAlchemy/SQLite、requests、现有pytest/ruff；不新增依赖。
**Spec:** `docs/experiments/T68-identity-binding-protocol.md`；PR140 review5904223500；PR139 task增补，由所有者本轮指示采用。

## Global Constraints

- B段泛称赛事关联不实现；不设新赛事独立留行/时标范围，不修改模型来源/参数。
- 正式API密钥仅Actions，开发不发体育请求；全部测试仅data/fixtures离线样本。
- 只产生待审候选，不自行核准别名，不开启daily，不改生产数据/冻结预测/旧报告/账本。
- 同联赛同向，绑定提案开球准确相等、90分钟完赛比分相等、完整窗口双向唯一；不用模糊名称或比分消歧。
- 既有18联赛原条目不改不删；新T68条目逐赛事范围限制，旧条目语义不变。
- 每批保存实际捕获/核验时间；新证据不倒填，不用后到证明改写既有冻结结果。
- 主干测试基线4023通过；最终全量pytest、ruff check、ruff format --check；reports≤200KB。

## Review Focus

- 目录中的同ID与主客/日期不符：补时刻不补造、不写比赛表。
- 多原件同fixture冲突/缺页或拒收隐藏竞争者：不推断新绑定。
- 同层互相自证、上层锚被否：阻断与撤下全部传递依赖。
- 36h重叠有多个候选/第三方已有关系：隔离不得因“不唯一”或“已有任意链接”而漏掉。
- 当前配置注入过去归档：无实际观察证据的跨日决定不影响更早cutoff。

### Task 2: 严格绑定提案与正式目标范围

Files: 新增 `src/zucai/identity_binding.py`（必要时拆 `identity_binding_archive.py`），修改 `sources/apif_aliases.py`、`sources/apif_reconcile.py`、`alias_propagation.py`；测试 `tests/test_t68_identity_binding.py`，样本 `data/fixtures/t68/identity/`。
Interfaces: CLI `python -m zucai.identity_binding --archive ... --out <全新目录> [--leagues ...]`；输出 `apif.json` 使用既有按联赛/球队ID候选结构，`summary.json`、证据与未提案原因。所有新项status=proposed。可支持 `--reject <候选ID>` 撤下层级依赖。
- [ ] 正反测试：严格时间/90min/方向/唯一性；FD早年证据；女足/预备/青年/奥运亚运类型不得合并；缺完整性不得提案。
- [ ] 分层算法只用上一轮新增锚；记录layer/depends_on/原件SHA及ID；冲突或拒绝撤下全传递依赖；候选不成为生产active。
- [ ] 归档适配器从完整JC目录+匹配库内行/已核验head、T61完整原件（含未入库）、规范FD证据读入。并列真实未核实原因，不把原件名当规范身份。
- [ ] 已核准同providerID传播仅明确兼容类别；新正式项 `binding_scope` 限定target leagues（与原件身份类别一致），reconcile/propagate拒绝越界，旧无该字段项兼容。
- [ ] 固定归档已知答案：目标93条及新赛事审查基线107项，仅记录真实结果；不同逐条解释，出现相反阻止交付；不写正式别名。


## Additional context at dispatch

Worktree /workspace/work/football-t68; branch codex/T68-new-competition-team-identity; user authorizes A only after revised protocol; B is docs-only waiting independent review. Main273008329b15fabe8b5dd0cdc1ed78f139dcc270. Python /workspace/work/t48-venv/bin/python, MUST PYTHONPATH=src; Ruff samebin. No real HTTP or keys, no commit/push, no child agents.

Partial fixed input at work/t68-a/fixed-archive, all2305 selected files SHA verified from e370db1d5cabe1cb33ddbfff3029c6d802bb8992; this is NOT a full production archive (manifest references missing odds/etc). It includes all catalogue raw, teams/matches/results/proofs/index. No full checkout (~1GB); free space~500MB. Results-only regression DB at work/t68-a/model-fixture/data/zucai.db is immutable; no modifying it. Don't re-materialize data. Fixed-inputs.json documents exact scope.

Task1 module supplies strict verified JC time proof (headers, calculator schedules, or limited same-JC-ID manifest-backed DB row proof) and excludes conflicts. Reviewer independently verified146 DB clocks within1262 fixed catalogue set;143finished/3cancelled. DB clock reuse is not itself APIF alias authorization. Strict binding still needs independent source times/scores, complete competitors, unique existing canonical target, and category evidence. Fixed official catalogue ends2026-10-31; review107 baseline used150finished DB rows through later dates, so actual denominators may differ. Don't force either107 or93, investigate and itemize every difference, no conflicting proposal allowed.

Reuse existing parsers and graph concepts, but not old infer_aliases' auto_verified behavior: every T68 output stays proposed. No status mutation of formal API aliases/registry/nations. Runtime scope guard applies only new entries carrying binding_scope; legacy semantics unchanged. New same-provider cross-category propagation must fail closed. Raw fixtures retain unimported/rejected/unplayed competitors before uniqueness; all730-ish files is not same as completed unique seasons. Source hashes/actualcapture are not approval dates.

Required delivery: narrowly scoped code/tests/fixture changes, test red→green log paths under work/t68-a/, fixed input CLI outputs and clear differences if possible, full implementation report work/t68-a/task-2-report.md. Parent owns docs and full integration checks. Do not alter Task1 files unless interface bug discussed first. If evidence missing, preserve detailed unverified output; do not weaken validator or create identity facts to meet a count.

Idempotency detail: output dirs stay new; if needed accept explicit --previous-candidates or existing archive candidate queue to merge stable proposal IDs/evidence, preserve first observation, second identical replay reports0new instead of merely producing another identical file. Do not infer second run0new if both runs used empty old queues. Global prior formal ID conflicts must still block even where new binding_scope target filters apply.
Useful read-only base inspection: docs/research/2026-11-14-jc-sfc-competition-master-table.csv and registry.competitions[].master_fields contain explicit groups/type categories (e.g adult nationalgroup7, youth/women/group8). Do not infer adult merely because raw name lacks Women/U21; reserve may appear within adult leagues. Exact name tokens may veto wrong propagation but may not create mapping.

## Latest authorized split / location overrides
Worktree is now /workspace/work/football-t68-a-rest, branch codex/T68-A-identity-and-quarantine. PR140 review5904285942 explicitly requests PR140 only proposal+Task1; remaining A/B followup PRs. Task2 writes ONLY this new worktree. Parent creates followup draftPR later; no commits/push by worker.
Shared immutable fixed source: /workspace/work/football-t68/work/t68-a/fixed-archive (use absolute --archive; no duplicate/copy/symlink source root). Shared immutable resultsDB: /workspace/work/football-t68/work/t68-a/model-fixture/data/zucai.db. Parent-owned prior baseline/evidence remain there. Your logs/report under currentnewworktree work/t68-a/.
Already existing independent FD originals FOUND at /workspace/work/t66-review-20261114/inputs/raw/football-data-co-uk/2026-11-14/ (CSV+meta; no newrequests). Reuse read-only after HTTP/URL/SHA/capture/source/timezone checks; consider explicit --fd-raw-dir input. Files include JPN/FIN/NOR/SWE/USA-all andseasonal E0/E1/F2/etc. Multiplecapturesmayrepeatraw; preserve provenance, reject actual identity/timeconflicts. These are preserved earlier task inputs, never modify/delete them. Their real capture~02:00UTC precedes e37010:43UTC. Record auxiliary source provenance; don't claim CSVs were in e370 catalogue.
No per-item107artifact provided in review; only aggregate150newJCfinished/173teamitems/107possible withcompleteAPIFraw. 93known answers countsJPN19SWE14NOR14MLS17KOR12FIN6AUS11. Parent can further search prior approved archive artifacts as needed, but don't call missing whole raw when scoped already-saved sources exist.
B design has now passed review; owner classificationapproval comment6877359853 (PR139commit3dbabc7) establishessets. Still NO B implementation in Task2; approvedcategories may inform typed identity constraints withexplicitreference. Parentwillmirror approvedtask source context as needed.
