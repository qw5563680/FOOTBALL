"""Read-only comparison of final T68 outputs and frozen source pointers."""
import collections
import hashlib
import json
from pathlib import Path

HERE = Path('/workspace/work/football-t68-a-rest')
BASE = Path('/workspace/work/football-t68/work/t68-a')
ARCHIVE = BASE / 'fixed-archive'
OUT = HERE / 'work/t68-a/task-2-verified-evidence'
OUT.mkdir(exist_ok=True)
REPLAY = HERE / 'work/t68-a/task-2-verified-replay'

def read(path):
    return json.loads(path.read_bytes())

def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

summary = read(REPLAY / 'summary.json')
issues = read(REPLAY / 'unverified.json')
manifest = read(ARCHIVE / 'feed_manifest.json')
formal = read(HERE / 'data/team_aliases/api_football.json')
queue = read(ARCHIVE / 'state/alias_candidates/apif.json')
result = read(REPLAY / 'apif.json')
assert queue == result
assert all(result[league][key] == entry for league, entries in queue.items() for key, entry in entries.items())
reasons = collections.defaultdict(collections.Counter)
examples = collections.defaultdict(list)
for row in issues:
    for key in row.get('provider_team_ids', []):
        pair = row['league'], key
        reasons[pair].update(row['reasons'])
        if len(examples[pair]) < 5 and any(reason not in {'no_counterpart_in_window','not_bidirectionally_unique'} for reason in row['reasons']):
            examples[pair].append(row)

inventory = read(BASE / 'unbound-raw-inventory.json')
source_cache = {}
gaps = []
for item in inventory['rows']:
    league, key = item['league'], item['provider_team_id']
    sample = item['sample']
    path = ARCHIVE / sample['path']
    if path not in source_cache:
        assert sha(path) == manifest['files'][sample['path']]
        source_cache[path] = read(path)
    assert sha(path) == sample['sha256']
    row = source_cache[path]
    for part in sample['pointer'].strip('/').split('/'):
        row = row[int(part)] if isinstance(row, list) else row[part]
    assert str(row['id']) == key
    assert formal.get(league, {}).get(key, {}).get('status') not in {'approved','auto_verified'}
    pair = league, key
    gaps.append(dict(item, raw_pointer_reverified=True, proposed=False,
                     source_category='not explicitly established for this provider ID',
                     reason_counts=dict(reasons[pair]), examples=examples[pair]))
assert len(gaps) == 88
write('task-2-earlier-88-gaps.json', dict(source_commit=inventory['source_commit'], total=88,
      counts=inventory['counts'], not_in_db_inventory=inventory['not_in_temporary_db_inventory'],
      reason_item_counts=dict(collections.Counter(reason for row in gaps for reason in row['reason_counts'])), rows=gaps))

new = read(REPLAY / 'new_competition_diagnostic.json')['apif']
new_items = []
for league, entries in new.items():
    for key, entry in entries.items():
        proofs = [dict(apif_id=e['apif']['match_id'], counterpart_id=e['counterpart']['match_id'],
                       apif_provenance=e['apif']['provenance'], counterpart_provenance=e['counterpart']['provenance'])
                  for e in entry['evidence'] if e.get('kind') == 'strict_oriented_fixture']
        new_items.append(dict(league=league, provider_team_id=key, candidate_id=entry['candidate_id'],
                              diagnostic_canonical=entry['canonical'], diagnostic_canonical_team_id=entry['canonical_team_id'],
                              evidence_status=entry['evidence_status'], not_for_approval=True, layer=entry['layer'],
                              depends_on=entry['depends_on'], witnesses=proofs,
                              full_check_reason_counts=dict(reasons[league,key])))
write('task-2-new-107-comparison.json', dict(reference_aggregate=107, actual_diagnostic=len(new_items),
      delta=len(new_items)-107, reference_item_list_available=False,
      warning='A net count difference cannot identify expected-but-missing/excess items without the 107-item reference list. These are diagnostics, not proposals.',
      independent_no_anchor_new_count=sum(v for k,v in summary['diagnostic_counts'].items() if k in summary['inputs']['new_route_leagues']),
      by_league={league:len(entries) for league,entries in new.items()},
      review_finished_db=summary['inputs']['new_route_finished_db_count'],
      in_fixed_catalogue=summary['inputs']['new_route_finished_in_catalogue'],
      outside_fixed_catalogue=summary['inputs']['new_route_finished_outside_catalogue'], rows=new_items))

conflicts = read(HERE / 'work/t68-a/task-2-raw-conflicts.json')
for mid, copies in conflicts.items():
    for item in copies:
        path = ARCHIVE / item['path']
        item['raw_sha256'] = sha(path)
        item['metadata'] = read(path.with_suffix('.json.meta.json'))
        item['metadata_sha256'] = sha(path.with_suffix('.json.meta.json'))
        assert item['raw_sha256'] == item['metadata']['sha256']
    assert len({(item['fixture']['date'],item['teams']['home']['id'],item['teams']['away']['id']) for item in copies}) == 1
write('task-2-raw-conflicts.json', conflicts)

raw_scopes = set()
for path in ARCHIVE.glob('state/catalogue/*/backfill/api-football/*/fixtures_*.json'):
    if path.name.endswith('.meta.json'):
        continue
    doc = read(path)
    raw_scopes.add((str(doc['parameters']['league']),int(doc['parameters']['season'])))
validation = dict(source_manifest_sha256=sha(ARCHIVE/'feed_manifest.json'),
                 unique_provider_seasons=len(raw_scopes),
                 old_queue_entry_count=sum(map(len,queue.values())), old_queue_logically_preserved=True,
                 original_queue_sha256=sha(ARCHIVE/'state/alias_candidates/apif.json'),
                 output_queue_sha256=sha(REPLAY/'apif.json'),
                 source_files={str(path.relative_to(HERE)):sha(path) for path in [
                    HERE/'src/zucai/identity_binding.py', HERE/'src/zucai/identity_binding_archive.py',
                    HERE/'src/zucai/sources/apif_aliases.py', HERE/'src/zucai/sources/apif_reconcile.py',
                    HERE/'src/zucai/alias_propagation.py', HERE/'src/zucai/sources/apif_ingest.py',
                    HERE/'src/zucai/stats_link.py', HERE/'src/zucai/sources/cup_identity.py',
                    HERE/'tests/test_t68_identity_binding.py']},
                 protected_files={str(path.relative_to(HERE)):sha(path) for path in [
                    HERE/'data/team_aliases/api_football.json',HERE/'data/league_map.json',HERE/'data/api_football/nations.json']},
                 summary=summary)
write('task-2-validation.json',validation)
print(json.dumps(dict(earlier_items=len(gaps),new_diagnostic=len(new_items),unique_provider_seasons=len(raw_scopes),
                      reason_item_counts=collections.Counter(reason for row in gaps for reason in row['reason_counts'])),ensure_ascii=False))
