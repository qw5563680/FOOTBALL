"""Finalize read-only T68 validation after both frozen-code runs finish."""
import collections
import gzip
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).parents[2]
work = root / 'work/t68-a'
first = work / 'task-2-verified-replay'
repeat = work / 'task-2-verified-repeat'
evidence = work / 'task-2-verified-evidence'

def read(path):
    if path.exists():
        return json.loads(path.read_bytes())
    return json.loads(gzip.decompress(path.with_suffix('.json.gz').read_bytes()))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

frozen = read(work / 'task-2-review-freeze-2.json')
assert all(sha(root / name) == expected for name, expected in frozen['files'].items())
a, b = read(first / 'summary.json'), read(repeat / 'summary.json')
assert (first / 'apif.json').read_bytes() == (repeat / 'apif.json').read_bytes()

def diagnostic(directory, name):
    return sorted((league, key, entry['candidate_id'], entry['canonical'],
                   entry['evidence_status'], entry['layer'], tuple(entry.get('depends_on', [])))
                  for league, entries in read(directory / name)['apif'].items()
                  for key, entry in entries.items())
for name in ['diagnostic_matches.json', 'new_competition_diagnostic.json']:
    assert diagnostic(first, name) == diagnostic(repeat, name)
assert a['unverified_reasons'] == b['unverified_reasons']
assert a['strict_verified'] == b['strict_verified'] == 0
assert a['new_candidates'] == b['new_candidates'] == 0
assert a['legacy_preserved'] == b['legacy_preserved'] == 138
assert read(first / 'diagnostic_known_answers.json') == read(repeat / 'diagnostic_known_answers.json')
old_reasons = collections.Counter(r for row in read(work / 'task-2-final-replay/unverified.json') for r in row['reasons'])
new_reasons = collections.Counter(r for row in read(first / 'unverified.json') for r in row['reasons'])
diff = {key:dict(pre_review=old_reasons[key], verified=new_reasons[key])
        for key in sorted(old_reasons.keys() | new_reasons.keys()) if old_reasons[key] != new_reasons[key]}
(evidence / 'reason-differences.json').write_text(json.dumps(diff, ensure_ascii=False, indent=2)+'\n')
validation = read(evidence / 'task-2-validation.json')
validation.update(head=frozen['head'], verified_utc=datetime.now(timezone.utc).isoformat(),
                  frozen_source_manifest=str(work / 'task-2-review-freeze-2.json'),
                  frozen_source_manifest_sha256=sha(work / 'task-2-review-freeze-2.json'),
                  frozen_file_count=len(frozen['files']), frozen_files_unchanged=True,
                  targeted_tests=368, task2_tests=89, independent_internal_tests=280,
                  repeated=dict(queue_byte_identical=True, diagnostic_business_rows_identical=True,
                                diagnostic_known_answers_identical=True, reason_counts_identical=True,
                                new_candidates=b['new_candidates'], legacy_preserved=b['legacy_preserved'],
                                output_queue_sha256=sha(repeat / 'apif.json'), summary=b),
                  replay_files={str(path.relative_to(work)):sha(path)
                                for folder in [first, repeat]
                                for path in folder.iterdir() if path.is_file()})
(evidence / 'task-2-validation.json').write_text(json.dumps(validation, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(dict(targeted_tests=368,known=read(first/'diagnostic_known_answers.json')['reproduced'],
                     new_diagnostic=a['new_competition_diagnostic_count'],strict=a['strict_verified'],
                     legacy=a['legacy_preserved'],queue_sha256=sha(first/'apif.json'),reason_differences=diff),ensure_ascii=False))
