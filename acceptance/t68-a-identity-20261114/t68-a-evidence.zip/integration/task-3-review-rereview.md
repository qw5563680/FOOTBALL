通过

T68 A Task3 限定独立内部复查，基于 `task-3-review-freeze-2.json`（2026-11-14 14:58:07 UTC）。这不是 Claude 正式批准，也不代替父级全量测试、最终 26 模型参数/概率及恢复后拟合验收。

**Spec compliance 通过；task quality 通过。原两项 Important 均关闭，无剩余 Critical / Important。** 可由父级按既有授权推进 Task4。原始失败报告和 RED 证据保留，未用本轮通过覆盖失败日志。

本轮范围严格限于原 finding 的三文件修订：`source_result_quarantine.py`、`source_results_audit.py`、`test_t68_cross_day.py`。其余九个 Task3 owned 文件与首冻哈希相同；第二冻全部 12 个文件在检查前后均精确匹配。本次未修改产品、正式测试、fixture 或来源/模型配置。

1. **Important 1 已关闭：完整旧来源声明图先核验，再许可桥接。**

   `src/zucai/source_result_quarantine.py:86` 的 `_validate_bridge_components` 从相关旧桥端点遍历完整 incoming/outgoing 指针和 proof，拒绝断引用、反向、越窗、跨联赛以及同来源多实体；`complete_old_source_links` 只为与当前 frame 相关的旧桥启动此检查。首轮的两 paid 错误放行及三个冲突声明反例均改为明确拒绝，不能再依赖过滤后的残存边获得免隔离。

   独立补测确认同联赛、跨联赛的**无关**多 JC 声明组件不会阻断选中的合法桥。原未来桥严格 cutoff 反例仍通过。合法 JC 来源编号并未进入同场授权：三种外部 FD/APIF/FDORG 引用下，未处理的 APIF 与 JC 仍有隔离记录。

2. **Important 2 已关闭：独立风险优先于 consistent/unmatched 导出筛选。**

   `src/zucai/source_results_audit.py:585` 起的后处理把有独立风险的 otherwise consistent/unmatched 行转成 unverified，并保留原因；首轮 FD→不存在 JC 的实质断指针现在逐场导出。没有实质风险的原摘要行为保留。

   `_non_entity_source_reference`（`:343`）仅识别 JC→不存在的、格式有效的 FD/APIF/FDORG 来源编号，且不赋予关系/身份/赛果证据。已逐项读到既有写入语义：`fd_ingest.py:258` 写 JC 的 FD 编号后 `continue`，`fdorg_ingest.py:516` 和 `apif_ingest.py:577` 的 JC target 分支也可能只保留编号而不创建 provider Match。以此纠正旧审计误报有代码依据，不依赖缺少 technical index 的假设。

   独立补测确认非法 FD 日期、APIF 0、非数值 FDORG 和 JC→缺失 JC 仍是 `counterpart_missing`；两 JC 争用一个外部编号时仍逐行保留 `multiple_counterpart_claims`，即使球队身份临时也不能汇总隐藏。

独立实测：

- `task-3-review-adversarial.py` **17 passed**，日志 `task-3-review-fix-adversarial.log`。覆盖全部原失败反例及原有 cutoff/决定快照/证据漂移检查。
- 新 `task-3-review-fix-boundaries.py` **10 passed**，日志 `task-3-review-fix-boundaries.log`。覆盖三种合法来源引用不免检、四种非法/错误来源编号保持风险、临时身份加竞争引用、两种无关组件不阻断。
- 本轮独立合计 **27 passed**。实施者 `652 passed` 的定向套件作为交付证据阅读，未重复全量跑；没有声称完成模型拟合。
- 修改三文件 `ruff check` 与 `ruff format --check` 均通过，`git diff --check` 通过。
- 第二冻 12 文件 SHA 前后全部匹配；只有指定三文件比首冻变化。

固定审计已重新独立复算：

- 输入 `/workspace/work/football-t68/work/t68-a/model-fixture/data/zucai.db`，前后 SHA 均为 `719f06b8cf800ccccc70f4eb158ecb092aa15d8da3ee8e29f98a4fca43abfb3a`。仍明确是 results-only 验收副本，partial 原件不称完整生产备份。
- `task-3-review-fixed-audit-rereview.csv` 与交付 `task-3-fixed-audit-reviewed.csv` **字节一致**；复算摘要保存于 `task-3-review-fixed-audit-rereview.json`。
- 最终 **26 CSV 行 = 21 风险详情 + 5 联赛汇总**；complete comparison **38821**，raw actionable **6592**，pure temporary **6571**。
- 原 6596 actionable + 13 新风险 − 17 合法来源引用 = 6592。六对临时身份条目仍按实质 counterpart 身份冲突重分类，所以 6577→6571；6592−6571=21。12 MLS 对引起完整比较分母 −12；挪超无 APIF 赛果反向对替换一条旧 unmatched，分母不变。
- 对 `task-3-fixed-audit-diff-reviewed.json` 的 17 条降级逐 ID 检查：当前确实是 JC、目标 Match 不存在、保存的 source key 与旧审计双方 ID 一致，旧联赛/比分也匹配，且新解释明确“不代表已找到 Match/已核实同场”。不是删掉来源行或伪称已匹配。
- 在既有 15 联赛范围内，独立枚举的 **552** 条引用与 `task-3-source-references-reviewed.json` **每个 `(match_id, counterpart_id)` 完全一致**：FD 481、APIF 17、FDORG 54。全库其它赛事的引用不混入此分母。首轮 43 和修复途中 578 均保留作历史证据，不再作为最终结果。

固定四问：

1. **冻结 predictions/parameters/run_log 是否改动？** 此三文件修订及本复查均没有修改冻结产物，固定 DB SHA 不变；生产操作、HTTP、密钥使用均为零。最终导出恢复与冻结产物 SHA 仍由父级验收。
2. **其他比赛匹配、路由、概率是否受影响？** 本轮只修组件拒绝与审计分类，没有改来源清单、拟合器或模型参数。真实设计影响仍是原指定 12 MLS APIF 隔离。父级另报告第二冻的 26 政策完整训练输入对照仅 primary 美职 4751→4739 删除这 12，另 25 完全相同；这是父级证据，本复查未代签参数/概率结论。
3. **是否遵循截点可知性？** 独立 future-bridge 两个 cutoff 边界仍通过，决定与原件未来/漂移反例通过；旧指针修复没有把来源编号变成 dated proof 或跨日授权。
4. **缺测是否补足？** 原两项缺测已有产品回归及本轮独立 27 例验证。当前限定范围没有剩余必须修问题；全项目及模型级最终验收仍属后续整体门槛。

复现：

```bash
PYTHONPATH=src:tests /workspace/work/t48-venv/bin/python -m pytest -o addopts= -q work/t68-a/task-3-review-adversarial.py work/t68-a/task-3-review-fix-boundaries.py -o tmp_path_retention_policy=failed --basetemp=work/t68-a/task3-review-final-rerun-tmp
```

原失败报告归档为 `task-3-review-initial.md`。本轮内部通过只关闭这两项 finding，不构成 Claude 正式批准、合并或生产应用授权。
