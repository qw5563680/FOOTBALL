"""Task3 fixed-corpus input regression before final integrated fits; no HTTP/DB writes."""
import hashlib
import json
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

import requests
from zucai.predict.command import load_corpus
from zucai.predict.parameters import read_parameters
from zucai.predict.pooled import select_training_history

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
BASE = Path('/workspace/work/football-t68/work/t68-a')
DB = BASE / 'model-fixture/data/zucai.db'
CUTOFF = datetime.fromisoformat('2026-11-14T10:43:21.807840+00:00')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


source_before = {str(p.relative_to(REPO)): sha(p) for p in sorted((REPO / 'src').rglob('*.py'))}
db_before = sha(DB)
expected = {row['paid_id'] for row in json.loads((BASE / 'same-ids-crossday-baseline.json').read_text())}
results = []
with patch.object(requests.sessions.Session, 'request', side_effect=AssertionError('Offline validation forbids HTTP')):
    for variant, params in [('primary', REPO / 'data/model/params.json'), ('source-expanded', BASE / 'model-regression-baseline/candidate-params.json')]:
        config, _ = read_parameters(params)
        for league, entry in config['leagues'].items():
            name = variant + '-' + league
            old = json.loads((BASE / 'model-regression-baseline' / (name + '.json')).read_text())
            frame, _, _, _ = load_corpus(DB, league, ','.join(entry['sources']), params_file=params, as_of=CUTOFF)
            selected = select_training_history(frame, CUTOFF)
            raw = selected.to_json(orient='records', date_format='iso', force_ascii=False)
            values_sha = hashlib.sha256(raw.encode()).hexdigest()
            removed = set(old['training_ids']) - set(selected.match_id)
            added = set(selected.match_id) - set(old['training_ids'])
            if league == '美职':
                assert removed == expected and not added, (name, removed, added)
                old_rows = {r['match_id']: r for r in json.loads((BASE / 'model-regression-baseline' / (name + '-training.json')).read_text())}
                assert all(old_rows[row['match_id']] == row for row in json.loads(raw)), name
            else:
                assert old['training_ids'] == selected.match_id.tolist() and old['training_values_sha256'] == values_sha, name
            results.append(dict(name=name, before=old['training_rows'], after=len(selected), removed=sorted(removed), added=sorted(added), values_sha256=values_sha))
            print(name, old['training_rows'], len(selected), 'removed', len(removed), flush=True)
assert len(results) == 26 and sha(DB) == db_before
assert source_before == {str(p.relative_to(REPO)): sha(p) for p in sorted((REPO / 'src').rglob('*.py'))}, 'Source changed during regression'
out = dict(status='passed', phase='Task3 input regression only; final integrated 26 fits still pending', cutoff_utc=CUTOFF.isoformat(), database_sha256=db_before, source_files=source_before, records=results, http_calls=0)
(HERE / 'task-3-full-input-regression.json').write_text(json.dumps(out, ensure_ascii=False, indent=2) + '\n')
print('26 policies: MLS12 only; other25 exact input equality', flush=True)
