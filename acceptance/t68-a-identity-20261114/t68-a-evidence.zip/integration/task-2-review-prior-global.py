import json
from pathlib import Path
from zucai.identity_binding import propose_bindings
v=json.loads(Path('data/fixtures/t68/identity/strict-pair.json').read_text())
one=propose_bindings(v['apif'],v['official'],v['teams'])
for cause in ('formal','occupied'):
 kwargs=({'formal':{'另一联赛':{'101':{'canonical':'丙队','status':'auto_verified'}}}} if cause=='formal' else {'occupied':{'101':{'3'}}})
 result=propose_bindings([],[],v['teams'],previous=one['apif'],**kwargs)
 print(json.dumps({'cause':cause,'strict_remaining':[(k,e['canonical'],e['evidence_status']) for d in result['apif'].values() for k,e in d.items() if e.get('evidence_status')=='strict_verified']},ensure_ascii=False))
