不通过

T68 A Task3 独立内部代码复查；不是 Claude 正式批准，不代替仓库所有者合并确认。复查基于 HEAD `13e968dd2725338b0451aac886d6834addb19921` 的未提交 Task3 改动与 `task-3-review-freeze.json` 冻结的 12 个 owned 文件。2026-11-14 复核结束时 12 个文件 SHA 均仍匹配；本复查未修改产品源码、原测试或正式数据。

**结论：spec compliance 不通过；task quality 不通过。Critical 0，Important 2。** 两项都有独立离线反例，已经同步父级及实施者；修复授权由父级控制。

1. **Important：完整旧来源组件在核验前过滤掉冲突声明，可错误放行付费赛果。**

   位置：`src/zucai/source_result_quarantine.py:97`、`:107`、`:114`、`:117`，调用链为 `read_history` → `complete_old_source_links` → `_linked_groups` → `exclude_pending_fd_overlaps`。

   `complete_old_source_links` 只读取当前范围内 JC/FD，并将目标缺失、反向主客、不同联赛、超过 3 小时的指针直接跳过。这个策略把“完整声明图中存在冲突”变成“没有该声明”，随后剩下的边可获得已核准组件的免隔离权；`_linked_groups` 的同来源多实体检查再也看不到被过滤的第二个 JC。

   最直接反例：`task-3-review-adversarial.py::test_invalid_old_component_releases_paid_row_without_reliable_result`。以 real12 为离线种子，构造英超 APIF/FDORG 两份同向规范 ID、同时间、同比分、同 cutoff 可知的付费赛果；分别存在 APIF→JC、FDORG→FD 的合格 dated proof；JC、FD 均无赛果且未选择。JC→FD 有一个有效指针，同时第二个 JC 以反向主客声明该 FD。当前代码忽略第二声明，把两份 paid 赛果连通，实际选择 `['fdorg:review-paid']`；应拒绝冲突组件或保留两 paid 的隔离。

   另有三个反例确认同根因：`test_conflicting_unselected_old_anchor_cannot_prove_component[reversed_claim/outside_window_claim/broken_outgoing]`。第二 JC 反向、第二 JC 越窗、FD 自身指向不存在 JC 三种情况，都仍经非赛果 JC anchor 免除了 APIF/FD 风险。

   修复要求：让完整 incoming/outgoing 声明参与端点及组件一致性核验，再授予旧来源边的免隔离作用；不能先删除不合法或跨范围声明后宣称组件完整。保留合法未选择/非赛果锚、dated proof 截点规则和现有可靠来源优先级。需新增对应产品回归。

2. **Important：独立风险虽已计算，`consistent` / `unmatched` 过滤仍会把风险证据从审计导出删掉。**

   位置：`src/zucai/source_results_audit.py:537`—`:545`、`:580`。

   新 `_independent_risks` 能算出断指针等实质风险，但后处理只在 `reason == temporary_team_identity` 时替换 reason，不调整 otherwise consistent/unmatched 行；`audit_source_results` 再按 classification 排除它们。

   独立反例：`task-3-review-adversarial.py::test_consistent_score_cannot_hide_broken_third_pointer`。使用已有离线 `consistent` fixture，仅设置 FD 的 `counterpart_id='jc:review-missing'`。APIF/FD 比分、时间和身份一致；新风险计算已有 `counterpart_missing`，实际 CSV 仍只有表头，`rows=raw_actionable_rows=0`。因此“纯临时身份汇总之外的其它风险继续逐场”并未完整兑现。

   修复要求：任何已计算的实质风险都必须进入逐场审计及相应分类/原因/计数，不可只按旧 classification 丢弃。没有实质风险的 consistent/unmatched 可继续保持原有摘要行为；固定数据分母及 added/reclassified diff 应在修复后重新核对。

复查实测和证据：

- 自建反例文件：`work/t68-a/task-3-review-adversarial.py`。第一批 11 例结果 **5 failed / 6 passed**，五个失败对应上述两个根因；日志 `task-3-review-adversarial.log`，失败 fixture DB 保留在 `task3-review-tmp/`。后追加的六例 **6 passed / 11 deselected**，日志 `task-3-review-additional.log`。总计独立 17 例：5 failed、12 passed。第一次探索中 source 字段漂移被数据库 CHECK 正确阻止，不属于 finding；最终测试已去掉这个错误期待。
- 通过的独立边界：未来桥接 proof 在等于 cutoff 时仍不能免检、严格后一秒生效；league、kickoff、result_checked、available_source、Team name、identity verified time、当前/未来新 dated link 的快照漂移都撤销已有决定；未来原件观察与嵌入回执原件篡改均拒绝授权。
- 本次没有重复实施者已报告的 623 定向测试，也未跑全量 pytest 或模型拟合；`623 passed` / 新增 54 例仅作为交付证据阅读。父级另行承担全量检查及 26 模型参数/概率和恢复拟合验收。
- 独立固定审计：输入 `/workspace/work/football-t68/work/t68-a/model-fixture/data/zucai.db`，前后 SHA256 均为 `719f06b8cf800ccccc70f4eb158ecb092aa15d8da3ee8e29f98a4fca43abfb3a`。它是 results-only 副本；`fixed-archive` 是 partial 原件，未称完整生产备份。
- 新产物 `task-3-review-fixed-audit.csv` 与交付 `task-3-fixed-audit.csv` **字节完全相同**；完整摘要保存为 `task-3-review-fixed-audit.json`。确认 43 行 = 38 details + 5 league summaries，comparison_rows 38821，raw_actionable 6609，pure temporary 6571；交付 diff 为 added 13 / reclassified 6 / removed 0。
- 分母解释成立：12 MLS 对把 24 unmatched 行替换成 12 风险对，38833→38821；无 APIF 赛果的反向挪超对替换一条旧 FD unmatched，分母不变。六对临时身份条目因独立 counterpart_identity_conflict 改分类，6577→6571；6609−6571=38。旧 19 详情数未被强凑。
- `git diff --check` 通过；冻结校验两次均为 12 文件无漂移。完整 owned 代码差异快照在 `task-3-review-full-owned-diff.txt`；仅写 `work/t68-a/task-3-review-*` 及本复查临时目录。

本次核对后没有提出问题的范围：

- 新分支以 `actual_result_leagues()` 与逐赛事既有 `apif_history_sources()` 为边界，T63 为 APIF 15 / FDORG 9；没有扩韩职/澳超 legacy、中超/丹超、新赛事或 B 泛称训练视图。原单侧未知 FD 三小时算法保留。
- 新同向双 ID 候选不读取比分来搜索或消歧，多候选全部保留；先做来源/身份/实际可知过滤，再隔离，最后折叠代表，既有 FD 折成 JC 时不会漏掉 APIF 隔离。
- 决定注册表为空；same/different 只对指定 pair、当前快照和真实 apply receipt 生效，不写超 3 小时 T63 link。两 paid 的 same_match 若比分冲突继续两条都 hold。PR/owner/UTC 语法核验不等同 GitHub 正式审批，报告已如实划清线下限制。
- receipt 可选导出恢复与旧档清理改动范围合适，未增加 DB schema；原件字节保存在 receipt 中以支持新路径恢复。
- 三个旧训练断言从异常改为明确隔离是获准 T68 语义；旧审计两个独立样例移到 36 小时外避免交叉干扰是合理调整。未见以删测试或忽略异常掩盖失败，但上面两个缺口需要补测。

固定四问：

1. **是否碰冻结 predictions/parameters/run_log？** 本次 owned diff 未改任何冻结预测、参数或账本；本复查也未改这些产物。固定 DB SHA 保持不变。生产数据未读取写入；父级最终保存恢复 SHA 验收仍需独立交付。
2. **是否影响其他比赛匹配、路由或概率？** 设计内应影响美职指定 12 APIF ID：`695164,695206,695213,816780,816884,980819,981244,981246,1150767,1151233,1151235,1151237`。本审计确认这些是待核隔离，未断言同场；原“11 单侧风险”无原 ID 清单，未冒称复现。Important 1 另证明合成 `fdorg:review-paid` 可被错误放行；其它模型参数/概率由父级完整对照，不凭源码阅读代签。
3. **是否只用截点前可知信息？** 独立 future-bridge 与 future-evidence 测试通过；当前 registry 不能改写实际 application 前的过去。Important 1 仍会把不完整旧组件当成身份授权，修复前不能判整体选择安全。
4. **测试是否覆盖改动点，缺什么？** 现有测试覆盖主路径与多项边界，缺的重点是“同端点含不合法/跨窗/断裂旧指针时的完整组件”和“非临时身份、比分一致时仍存在独立第三指针风险”。上面已提供可直接转为产品回归的失败样例。

复现命令（离线，无 HTTP、无密钥；请使用新的 basetemp 保留本轮失败证据）：

```bash
PYTHONPATH=src:tests /workspace/work/t48-venv/bin/python -m pytest -o addopts= -q work/t68-a/task-3-review-adversarial.py -o tmp_path_retention_policy=failed --basetemp=work/t68-a/task3-review-rerun-tmp
```

实施者修复后应对两个 finding 做 scoped re-review，再由父级完成其余整体验收。此报告不提供 Claude 正式批准，也不授权发布、合并或生产应用。
