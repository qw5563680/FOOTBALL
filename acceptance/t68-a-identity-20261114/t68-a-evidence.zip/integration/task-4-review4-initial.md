不通过

这是PR139最新增补（`f963cfe95db4c6104914cb967e445c1c87198b69`）的Task4最后限定内部复查，不是Claude正式批准或owner合并授权。先前freeze3通过的报告已原样保留为 `task-4-review-before-freeze4.md`；I1/I2/I3仍关闭，但最新回填状态分离存在下述一条Important。

## 审查对象与范围

HEAD `13e968dd2725338b0451aac886d6834addb19921`；`task-4-owned-freeze-4.json` SHA256=`22678ba7b89474779d1869c93feef392383293a234401b8b4a96d89553b8a993`，24owned。先读PR139相对3dbabc7的任务diff、两处产品变更和相关调用链，再读 `task-4-backfill-collection-report.md`。本轮不重跑全量或26模型，不修改产品、正式数据、工作流，不发体育HTTP/真实Release请求，不用正式key、不commit/push/开PR。

## 分级发现

### Critical

无已确认项。

### Important I4：晚班技术数据二次导出重新引入历史回填partial

- 位置：`src/zucai/stats_batch.py:424`–431、`src/zucai/cloud_feeds.py:450`–456；真实调用位于 `.github/workflows/football-feeds.yml:290` 和`:299`，在apis之后、发布数据之前执行 `cloud_stats daily`。
- `cloud_feeds main` 已正确为sync/apis传入每日状态视图，但stats_batch合并原collection后调用export_feeds时未传 `status_collection`。新保留的 `apif_backfill/fdorg_backfill/fd_backfill` 历史partial会再次被默认汇总计入。
- 独立复现：`task-4-review4-probes.py::test_late_daily_statistics_do_not_reintroduce_historical_backfill_partial`。以已有T32离线fixture构造四每日来源complete、历史apif_backfill partial、总状态complete；实际执行 `stats_batch.collect_batch(daily=True)`，HTTP请求0、mock Release、stats结果complete、pending_result_count=0，每日来源值保持不变，但新manifest.collection_status变为partial。原断言失败保留，不是仅模拟函数返回。
- 预期：晚班技术步骤不能因历史回填partial污染每日总状态；当前stats真正失败、当前回填失败和真实pending仍须partial。修复应覆盖所有实际导出调用方或明确传入适当汇总视图，不能简单忽略所有partial。
- 依据：最新任务第五节2要求回填不覆盖每日来源状态；本轮父级验收明确要求每日总status不被历史回填partial污染。该漏洞不会改比赛或概率，但最终发布清单仍给出错误整体状态。

### Suggestion

无须扩大训练/身份/gate修改范围。未复现其他必须修。

## Spec与quality结论

- **Spec：本轮增补未通过。** 六个回填入口与仅JC sync路径、日报顶部/异常区已正确分离；真实晚班技术数据导出仍遗漏，需修I4后复查。
- **Quality：局部通过。** 64项定向中63通过、1项上述独立反例失败，0error/skip。24owned在复查前与发现后全部符合freeze4，gate/身份/训练未动。本轮不撤销先前I1/I2/I3的已验证修复；也不以63通过掩盖最终链路遗漏。

## 已独立验证

- APIF/FDORG/FD × 普通/catalogue × 成功/真实失败的实际CLI回填，原每日记录逐值保留、独立键、当前操作摘要/状态与恢复检查通过。
- 回填后只做JC sync、不请求APIF时，上次每日APIF值保留、历史回填记录保留、无真实风险时总状态complete通过。
- 新独立真实pending用例：仅JC sync导入一条无效比分，保留APIF每日值，pending_result_count=1、JC rejected_rows=1、总状态partial，证明历史过滤没有掩盖真实失败。
- 旧operation明确的普通/catalogue回填迁移，FD缺source兼容，旧未知operation/无operation/矛盾source不猜；独立三provider冲突迁移幂等和两条记录完整保留通过。
- 日报完整generate顶部与异常区共用daily视图、归档bytes不变；普通/目录回填Actions摘要、旧lateJC实际计数通过。
- probe、identity、relink真实入口与回执导出恢复/旧档残留清理回归通过。

## 证据与复跑

- `task-4-review4-freeze-before.json`、`task-4-review4-freeze-after-findings.json`：24/24 SHA一致。
- `task-4-review4-targeted.log/.xml`：64 tests、1failure、0errors、0skipped、7.681s。输入与输出副本保存在 `task-4-review4-targeted-artifacts/`。
- 新独立探针：`task-4-review4-probes.py`，包括上述晚班实际调用失败、真实pending、三provider迁移幂等、未知旧记录保持。其余定向为 `tests/test_t68_backfill_collection.py`、probe/identity实际归档入口、`tests/test_jc_relink_workflow.py`、Task3回执roundtrip。
- 实现方546全通过/Ruff日志已核对交接，但不是本reviewer独立运行，也未覆盖上述新增反例。原13fail与顶部遗漏6fail记录继续保留。

独立失败复跑：

```sh
PYTHONPATH=src:tests /workspace/work/t48-venv/bin/python -m pytest -q \
  work/t68-a/task-4-review4-probes.py::test_late_daily_statistics_do_not_reintroduce_historical_backfill_partial
```

## 固定四问与边界

1. **冻结产物？** 本次产品变更仅collection清单/显示逻辑；未改冻结预测/参数/账本/旧日报，reviewer仅写work证据。正式副本完整恢复验收归父级。
2. **其他比赛匹配/路由/概率？** 无赛事/球队/比赛ID变化，gate及身份训练源码SHA与freeze3相同。I4只影响collection_status；父级26模型仍独立执行，不用本回归代替概率对照。
3. **赛前可知性？** 未修改时标、赛果或训练来源规则。历史回填记录与每日记录分离属于报告来源语义，不代表历史信息当时可用。
4. **测试缺口？** 本轮发现真实晚班 `cloud_stats daily → stats_batch → export_feeds` 调用缺口。补修后应复跑该反例，并覆盖技术步骤真实失败及pending不被过滤；不用重复全量546或模型拟合来替代这一边界验证。

固定62route/1083场/32零场的gate产物、447重分类、138旧候选保留及真实日期原件不足的限制沿用前一报告，均未改变。等待I4修复及新冻结后限定复查；这不影响父级正在只读冻结副本执行的26模型对照，但当前不能把本轮Task4状态分离称为完成。
