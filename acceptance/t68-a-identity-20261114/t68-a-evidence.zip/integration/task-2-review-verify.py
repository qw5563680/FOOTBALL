import json
from copy import deepcopy
from pathlib import Path
from datetime import UTC, datetime
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from zucai.identity_binding import propose_bindings
from zucai.sources.apif_aliases import binding_scope_allows
from zucai.sources.apif_ingest import _Teams
from zucai.db import get_engine, init_db, session_scope
from zucai.models import Team
from zucai import identity_binding_archive as adapter

BASE=json.loads(Path('data/fixtures/t68/identity/strict-pair.json').read_text())
def ready(out):
 return [(league,key,e['evidence_status']) for league,entries in out['apif'].items() for key,e in entries.items() if e.get('evidence_status')=='strict_verified']
def call(inp,formal):
 return propose_bindings(inp['apif'],inp['official'],inp['teams'],formal=formal,observed_utc='2026-11-14T15:00:00Z')
formal={'来源':{'101':{'canonical':'甲队','status':'auto_verified','category':'club/men/senior/first','identity_country':'England','evidence':[{'raw_sha256':'c'*64}], 'binding_scope':{'leagues':['来源'],'category':'club/men/senior/first','start_utc':'2018-01-01T00:00:00Z','end_utc':'2018-12-31T23:59:59Z'}}}}
first=deepcopy(BASE);first['official']=[];first['apif'][0]['home_country']='England'
print(json.dumps({'same_provider_expired_scope':ready(call(first,formal))},ensure_ascii=False))
conflict=deepcopy(first)
conflict['apif'].append(dict(conflict['apif'][0],home_category='club/women/senior/first',home_name='Alpha Women'))
conflict_formal=deepcopy(formal)
conflict_formal['来源']['101'].pop('binding_scope')
out=call(conflict,conflict_formal)
print(json.dumps({'same_provider_conflicting_originals':ready(out),'issues':out['unverified']},ensure_ascii=False))
with TemporaryDirectory(prefix='t68-review-',dir='work/t68-a') as td:
 engine=get_engine(Path(td)/'test.db');init_db(engine)
 entry={'canonical':'甲队','status':'auto_verified','binding_scope':{'leagues':['测试联赛'],'category':'club/men/senior/first','start_utc':'2018-01-01T00:00:00Z','end_utc':'2018-12-31T23:59:59Z'}}
 with session_scope(engine) as session:
  session.add_all([Team(name='甲队',aliases=[]),Team(name='乙队',aliases=[])]);session.flush()
  resolver=_Teams(session,{'测试联赛':{'101':entry,'102':dict(entry,canonical='乙队')}})
  game=SimpleNamespace(league='测试联赛',home_provider_id=101,away_provider_id=102,home_raw='Alpha',away_raw='Beta',kickoff_utc=datetime(2020,6,1,12,tzinfo=UTC))
  try:
   sides=resolver.sides(session,game,{})
   actual={'actual_sides':[(s.name,s.binding) for s in sides]}
  except ValueError as exc:
   actual={'rejected':True,'reason':str(exc)}
  print(json.dumps({'runtime_out_of_scope':{'guard_permits':binding_scope_allows(entry,'测试联赛',kickoff_utc=game.kickoff_utc.isoformat()),**actual}},ensure_ascii=False))
 engine.dispose()
# Existing-pointer grouping through an invalid third-source identity is still merged.
rows=[dict(BASE['official'][0],match_id='jc:20'),dict(BASE['official'][0],match_id='fd:test:20')]
links=[{'match_id':'jc:20','counterpart_id':'apif:bad'},{'match_id':'fd:test:20','counterpart_id':'apif:bad'},{'match_id':'apif:bad','counterpart_id':None,'league':'other','home_team_id':999,'away_team_id':998}]
joined,issues=adapter.official_entities(rows,links)
print(json.dumps({'third_source_unvalidated_entity':{'entities':len(joined),'issues':issues,'members':[r.get('entity_members') for r in joined]}},ensure_ascii=False))
import hashlib
from zucai.sources.teams import normalize_team
with TemporaryDirectory(prefix='t68-review-fd-',dir='work/t68-a') as td:
 root=Path(td); rawdir=root/'fd';rawdir.mkdir()
 good=Path('data/fixtures/t68/identity/fd-date-window.csv').read_text()
 bad='Country,League,Season,Date,Time,Home,Away,HG,AG,Res\nTest,Test,2020,01/06/2020,12:00,,Other,2,1,H\n'
 for name,raw in [('good',good),('bad',bad)]:
  p=rawdir/(name+'.csv');p.write_text(raw)
  p.with_suffix('.csv.meta.json').write_text(json.dumps({'url':'https://football-data.co.uk/new/JPN.csv','status_code':200,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'fetched_at_utc':'2020-06-02T00:00:00Z'}))
 config=root/'leagues.json';config.write_text(json.dumps({'JPN':{'div_code':'JPN','league':'测试联赛','status':'verified','verified_by':2,'verified_utc':'2020-01-01T00:00:00Z','time_basis':'UTC','publisher_country':'Test','publisher_league':'Test'}}))
 aliases=root/'aliases.json';aliases.write_text(json.dumps({'测试联赛':{'Alpha':{'canonical':'甲队','status':'auto_verified'},'Beta':{'canonical':'乙队','status':'auto_verified'}}}))
 old_cfg,old_alias=adapter.FD_LEAGUES,adapter.FD_ALIASES
 adapter.FD_LEAGUES,adapter.FD_ALIASES=config,aliases
 try:
  inp=deepcopy(BASE)
  for t in inp['teams'].values():t['name']=normalize_team(t['name'])
  rows,issues=adapter.load_fd(rawdir,inp['teams'],{},league_codes={'测试联赛':'98'})
  inp['official']=rows
  result=call(inp,{})
  print(json.dumps({'bad_fd_original_hidden_competitor':{'complete_retained_rows':sum(r['complete'] for r in rows),'input_issues':issues,'strict_proposals':ready(result)}},ensure_ascii=False))
 finally:adapter.FD_LEAGUES,adapter.FD_ALIASES=old_cfg,old_alias
original=call(BASE,{})
changed=deepcopy(BASE);changed['apif'].append(dict(changed['apif'][0],score=[9,9]))
retained=propose_bindings(changed['apif'],changed['official'],changed['teams'],previous=original['apif'],observed_utc='2026-11-14T15:01:00Z')
print(json.dumps({'prior_strict_survives_new_raw_conflict':{'strict_proposals':ready(retained),'unverified':retained['unverified']}},ensure_ascii=False))
amb=deepcopy(BASE)
amb['apif'][0].update(home='102',away='104')
amb['official'][0].update(home='2',away='4')
amb['official'].append(dict(amb['official'][0],match_id='jc:21',home='1',away='3'))
anchor={'测试联赛':{'101':{'canonical':'甲队','status':'auto_verified'}}}
result=propose_bindings(amb['apif'],amb['official'],amb['teams'],formal=anchor,occupied={'101':{'3'}},observed_utc='2026-11-14T15:00:00Z')
print(json.dumps({'conflicted_formal_anchor_hides_competitor':{'strict_proposals':ready(result),'unverified':result['unverified']}},ensure_ascii=False))
