"""Fresh reviewer regressions; all HTTP is intercepted and inputs are fixture derivatives."""
import json
from copy import deepcopy
from datetime import UTC, datetime, timedelta
from hashlib import sha256
from pathlib import Path

import pytest
import responses

from test_apif_ingest import WHEN, game, ingest, seed, db as db
from test_cloud_apis import environment as environment
from test_cloud_aliases import FIXTURES, alias_inputs
from test_t22_backfill import CASES, paid_status
from test_t61_catalogue_backfill import catalogue
from zucai.cloud_aliases import write_candidates
from zucai.cloud_apis import _record
from zucai.cloud_catalogue_backfill import collect_catalogue_backfill
from zucai.cloud_feeds import restore_feeds
from zucai.db import session_scope
from zucai.models import Result
from zucai.sources.base import RawStore

ROOT = Path(__file__).resolve().parents[2]


@pytest.fixture(autouse=True)
def offline_only():
    with responses.RequestsMock():
        yield


def test_mid_pagination_budget_is_failure_then_next_scope_is_deferred(environment, tmp_path, monkeypatch):
    monkeypatch.setenv("GITHUB_ACTIONS", "true")
    monkeypatch.setenv("GITHUB_EVENT_NAME", "workflow_dispatch")
    paid_status(environment)
    database = tmp_path / "budget/zucai.db"
    restore_feeds(environment, database)
    catalogue(database.parent)
    quota = database.parent / "state/api_football_quota.json"
    used = json.loads(quota.read_bytes())["used"]
    doc = json.loads((ROOT / "data/fixtures/t10/synthetic_page1.json").read_bytes())
    doc["parameters"] = {"league": "292", "season": "2022"}
    doc["paging"] = {"current": 1, "total": 2}
    for row in doc["response"]:
        row["league"].update(id=292, season=2022)
        when = datetime(2022, 5, 18, 12, tzinfo=UTC)
        row["fixture"].update(date=when.isoformat(), timestamp=int(when.timestamp()))
    with responses.RequestsMock() as http:
        http.get("https://v3.football.api-sports.io/fixtures", json=doc, headers=CASES["paid_headers"])
        report = collect_catalogue_backfill(database, "review-pages", provider="apif", codes="292", max_requests=1)
        assert len(http.calls) == report["requests"] == 1
    assert len(report["failed_scopes"]) == len(report["deferred_scopes"]) == 1
    assert "请求中途达到本批上限" in report["failed_scopes"][0]["reason"]
    assert report["scopes"][0]["status"] == "partial"
    assert report["scopes"][1]["status"] == "deferred"
    assert json.loads(quota.read_bytes())["used"] == used + 1
    assert json.loads((database.parent / "state/catalogue/backfill-checkpoint.json").read_bytes())["completed"] == {}


def test_fdorg_contradictory_id_and_code_cannot_choose_one_attribution(tmp_path):
    database, raw_dir, output = alias_inputs(tmp_path, "fdorg", "2026-11-01T12:00:00+00:00")
    doc = json.loads((FIXTURES / "fdorg.json").read_bytes())
    doc["matches"][0]["utcDate"] = "2026-11-01T12:00:00+00:00"
    bad = deepcopy(doc["matches"][0])
    bad.update(id=123456, utcDate="invalid", competition={"id": 2021, "code": "PD"})
    doc["matches"].append(bad)
    doc["resultSet"]["count"] = 2
    raw = json.dumps(doc).encode()
    RawStore(raw_dir).save("football-data-org", "review", raw, "json", status_code=200,
                           captured_at=datetime(2026, 11, 3, tzinfo=UTC))
    captures = [dict(scope=dict(competition="PL,PD", date_from="2026-11-01", date_to="2026-11-02"),
                     raw_sha256=sha256(raw).hexdigest())]
    assert write_candidates("fdorg", database, raw_dir, captures, output) == 0


def test_actual_mixed_import_keeps_held_and_suspected_separate(db):
    with session_scope(db) as session:
        seed(session, "jc:held")
        seed(session, "jc:risk1", when=WHEN + timedelta(days=1))
        seed(session, "jc:risk2", when=WHEN + timedelta(days=1), home="南川", away="西山")
        for mid in ("jc:held", "jc:risk1", "jc:risk2"):
            score = session.get(Result, mid)
            score.home_goals, score.away_goals = 2, 1
        result = ingest(session, game(), game(provider_match_id=91002, kickoff_utc=WHEN + timedelta(days=1),
            home_provider_id=553, away_provider_id=554), mapping={})
        assert result["held_unbound"] == 1
        assert result["suspected_duplicates"] == 1
        assert result["rejected_rows"] == result["inserted"] == 0
    report = dict(status="complete", errors=[])
    _record(report, result)
    assert report["status"] == "partial" and report["errors"]
