# T68 A Task 2 内部独立复查

这是开发内部复查，不是 Claude 的正式审查批准，不授权合并、球队绑定或每日采集。只读产品代码；独立脚本/日志仅写 `work/t68-a/task-2-review-*`。

**最新结论：内部代码复验通过，Critical / Important 未关闭项均为 0。89项Task2包含在280项读取链回归中，全部通过；最终结果见文末。旧初审与失败记录原样保留。此结论不代替Claude正式审查、父级全量集成或修后真实固定输入回放。**

## 初审结论（修复前）

**需修改：Critical 0、Important 7、Minor 0。** 现有定向测试通过，但以下独立反例能令不合格证据保持 `strict_verified`，或使新正式范围在正常导入时失效。实现者已收到具体复现，正在逐项修复。本文件后续追加复验，保留初审事实。

对象：`codex/T68-A-identity-and-quarantine` 的未提交 Task 2 diff，A1 基线 `db38f7660475b5df85e5782a2900bb37d8f24bbb`。初始文件 SHA 见实现者封存的 `task-2-validation.json/source_files`。读了 AGENTS、README/架构/来源相关入口、审定绑定协议、Task 2 brief、PR139 修订任务单，检查全部 Task 2 源码和测试，并查看实现回放结果。

## Important 问题与复现

1. **同源数字 ID 传播忽略重复原件的身份冲突。**
   `identity_binding.py:278` 调用 `same_provider_proposals`，后者在 `:758–823` 生成种子。`_deduplicate` 已记录 `source_conflicts`，但种子没有检查；后面的撤销只检查全局目标，不使该种子失效。
   独立反例：同一 `apif:10` 一份 `club/men/senior/first/Alpha`，另一份 `club/women/senior/first/Alpha Women`；无官方对照、正式源条目同 ID。实际同时输出 `conflicting_fixture_originals` 和该 ID 的 `strict_verified`。
   要求：矛盾原件不能成为严格传播证据，保留矛盾并阻断相关候选/依赖；不能用原件顺序决定身份。

2. **同源传播未执行源条目的时间范围。**
   `identity_binding.py:779–803` 只检查 active、类别、国别与 evidence，未检查正式 `binding_scope` 的时界。
   反例：源正式绑定仅有效于 2018，目标 fixture 在 2020，仍产生 `strict_verified`。此路径绕过主图中按 fixture 做的范围检查。
   要求：同源传播同样检查实际 fixture 时间，不把有界源身份当永久身份。目标扩展仍只能提案，不能自行成为正式项。

3. **新增正式时间范围不能约束正常 APIF 导入。**
   `apif_aliases.py:validate_approvals/binding_scope_allows` 接受合法带时界条目；但 `apif_ingest.py:120–157` 的 `_Teams.resolve/sides` 不传比赛时间，也不应用范围。
   反例：2018 限定正式项，传入 2020 fixture。`binding_scope_allows(...2020...)` 为 False，实际 `sides` 仍返回两队规范 ID 及 `apif:<league>:team:<id>` binding。仅在 reconcile 检查不足以保证新字段语义。
   要求：新 scope 在正常导入入口也拒绝越界；旧无 scope 条目语义不变。

4. **官方实体去重盲信指针路径，未校验中间节点。**
   `identity_binding_archive.py:439–482` 按所有 counterpart 指针 union，只核对输入选中的 JC/FD 端点。
   反例：`JC -> APIF <- FD`，JC/FD 端点同向同刻同分，但中间 APIF 明确是另一赛事、另一组球队，仍被折为 1 个实体且问题为空。坏第三节点能从唯一性图中隐藏竞争者。
   要求：只对完整且有效的已核准关系组件折叠；缺失/异赛事/异队/重复来源/冲突组件保留各行并阻断，不以两个端点相似代替证明。

5. **FD 坏原件被整份丢弃后，其他原件仍声称完整。**
   `identity_binding_archive.py:397–399` 只写 issue，没有将范围不完整带回引擎。
   反例：同赛事 `good.csv` 有正常 2020 比赛，另一有效 HTTP/SHA 的 `bad.csv` 同时刻一行缺主队；坏文件被丢弃，正常文件 2 行仍 `complete=True`，最终输出两条 `strict_verified`。未知身份竞争者被隐藏。
   要求：保留能够安全归属的赛事/时间不确定竞争窗口；不能归属时从严阻断。坏行存在本身必须影响相关完整性判定，而非仅写外围日志。

6. **新发现原件矛盾没有使既有 T68 严格候选失效。**
   `identity_binding.py:458–537` 的 previous 合并主要处理新候选/目标冲突；若新一轮因原件矛盾根本不能生成候选，旧 `strict_verified` 被原样保留。
   反例：先用完整 strict-pair 生成两条，再给同一个 API fixture 添加 `[9,9]` 的矛盾原件，以首轮队列作为 previous。第二轮明列 `conflicting_fixture_originals`，旧两条仍 `strict_verified`。
   要求：明确矛盾须撤下依赖该 witness 的旧 T68 候选及传递依赖，并留全证据。不能把“本轮范围没含旧证据”一律当矛盾清空；138 条 legacy 队列仍须保留。

7. **全局占用有冲突的正式锚仍参与其它球队的消歧。**
   `identity_binding.py:336–364` 的 anchors 读取 `authorized`，未用已合并 DB/旧队列冲突的 `globals_` 排除不可靠锚。
   反例：正式 `101 -> 甲(1)`、DB 占用 `101 -> 丙(3)`；当前 `102/104` 有同时刻官方 `(乙2,丁4)` 和 `(甲1,丙3)` 两个候选。冲突锚 101 的 reverse 过滤掉第二候选，最终产生 102/104 两条 strict，unverified 为空。
   要求：冲突锚不能用于排除任何竞争边；DB/旧队列只能否决，不能间接创造“唯一”。

## 独立执行

- `PYTHONPATH=src /workspace/work/t48-venv/bin/python -m pytest -q -o tmp_path_retention_policy=failed --basetemp=work/t68-a/task2-review-tmp tests/test_t68_identity_binding.py tests/test_alias_propagation.py tests/test_apif_reconcile.py tests/test_apif_approvals.py`：退出 0，101 项通过，日志 `task-2-review-pytest.log`。
- Ruff check 及 format --check：Task 2 的 6 个源码/测试文件通过，6 files already formatted。
- 独立复现命令：`PYTHONPATH=src /workspace/work/t48-venv/bin/python work/t68-a/task-2-review-repros.py`。输出 `task-2-review-repros.log` 逐项显示上述错误通过。全部使用库内离线 fixture 的显式变体，没有 HTTP。
- 初始命令误写不存在的 `test_apif_aliases.py` 返回 4，未算通过；改为实际 `test_apif_approvals.py` 后上述运行通过。
- 内部本轮未跑全量套件；父级负责最终集成全量。未改源码、正式别名、注册表、nations、冻结产物或生产数据库。

## 对已交证据的界定

实现者旧回放（修前封存）为：原件 728 / 去重 fixture 127361；无锚已知答案诊断 93、相反 0；新赛事有正式锚的图诊断 116；完整类型条件的严格新增 0；legacy138 原样保留且显式第二轮新增0。不能用当前固定资料严格新增0推论未来正面类别证据齐备时没有上述漏洞。

93 与116均是明确标记的诊断，不能据此自动批准身份。150 新路由完赛中固定目录内129/外21，与A1含泛称的143完赛分母不同。实现者已经如实披露107只有汇总而无逐项名单，没有强凑。旧队列SHA一致/正式配置未改只能证明这批数据保存边界，不能替代上面的行为反例。

## 复验

待实现者修复冻结后，使用相同独立脚本与新增回归再次核对，并在此追加结论。

### 读取链补充（Important 3 的同类入口）

父级检查并授权最小修复两个直接生效入口：`stats_link.py` 通过 `_formal_entry` 建索引时也必须按fixture校验scope；`cup_identity._bridge` 不得把scoped项经跨赛事桥、DB fallback或旧图推断丢成无scope的auto_verified。后者已独立复现于 `task-2-review-cup-scope.py/.log`：仅限来源联赛/2018的101被立即传播到欧罗巴，返回auto_verified且scope消失。正常采集/回填上层汇入这些入口；stats_context/batch/command汇入stats_link。metrics/snapshot只读统计、cloud_aliases/cloud_identity只写待审队列，未扩大为旧算法重构。

PR140现由所有者合并至main `13e968dd`，父级已将相同tree的merge提交fast-forward到A-rest；初审基线db38f766仍为有效历史。最终复验以冻结源码SHA与最新origin/main差异为准。

### 首轮修后复验

原七类独立反例与cup桥反例均已关闭，见 `task-2-review-verify.log` 和 `task-2-review-cup-verify.log`。9文件实际入口定向测试已退出0，JUnit为 `task-2-review-final-pytest.xml`。但Important6/7交叉边界仍未关闭：旧T68 strict见证在当前formal或DB明确占用为另一目标时，若本轮不含旧fixture仍保持strict。这不是输入缺范围本身，当前强冲突应撤回旧witness及依赖。独立复现 `task-2-review-prior-global.py`、失败输出 `task-2-review-prior-global-red.log`，已通知父级与实现者。


## 最终代码复验结论（冻结 2）

**通过内部代码复验：未解决 Critical 0 / Important 0 / Minor 0。** 父级可以继续 Task 3；这不是 Claude 正式批准或生产启用许可。

对象为 `task-2-review-freeze-2.json`（UTC 2026-11-14T14:16:15.139658+00:00；北京时间22:16:15.139658+08:00）的16份源码、测试和fixture SHA；复验后逐份重新计算均相同。基线HEAD `13e968dd2725338b0451aac886d6834addb19921`。正式APIF别名、赛事注册表、nations再次与HEAD逐字节比较相同，记录于 `task-2-review-final-summary.json`。

| 初审问题 | 修复与独立结果 |
| --- | --- |
| 1 同源传播原件冲突 | 同fixture男/女类别原件矛盾不再产生strict，保留冲突；本次反例移除了过期scope，确保不是被另一个检查遮住 |
| 2 同源传播源时界 | 源2018限定不再授权2020目标fixture，strict为空 |
| 3 运行时丢scope | 普通sides/resolve逐fixture拒绝越期；stats索引过期拒绝、范围内通过；cup跨赛事桥/DB fallback/旧infer均不降成无scope active，已有明确scoped项保留给逐场guard；旧无scope回归通过 |
| 4 不完整关系组件 | 异赛事/异队第三节点不能折叠JC/FD，实际保留2个实体并记完整组件冲突 |
| 5 FD坏行隐藏竞争 | HTTP200坏行作为不确定竞争者保留，严格提案0；正常空302跳转另记，不伪造比赛矛盾；未知范围从严阻断 |
| 6 旧T68矛盾 | 重复原件或单份改值均撤回旧witness及依赖、旧证据/冲突并存；仅缺本轮范围保留。补充formal/DB明确不同目标时，即使本轮无旧fixture也撤回整条依赖 |
| 7 冲突锚消歧 | formal与globals不一致不参与正/反向消歧，两个竞争者均保留，严格提案0 |

独立执行结果：

- `task-2-review-verify.py` → `task-2-review-verify-final.log`：七类原反例逐项安全关闭。
- `task-2-review-cup-scope.py` → `task-2-review-cup-verify-final.log`：原本会产生无scope auto_verified的桥现在返回空对象。
- `task-2-review-prior-global.py` → `task-2-review-prior-global-green.log`：formal和occupied两种旧T68强冲突均 `strict_remaining=[]`。失败输出 `task-2-review-prior-global-red.log` 保留。
- 9文件定向实际读取链回归 **280 tests / 0 failures / 0 errors / 0 skipped / 9.190秒**，含全部89项Task2测试，日志/XML `task-2-review-final2-pytest.log`、`task-2-review-final2-pytest.xml`。覆盖 identity binding、alias propagation、APIF reconcile/approvals/ingest、cup identity、stats link/context/schedule。
- Ruff check通过、format --check为9 files already formatted；未修改产品代码。

该复验不宣称完整T68已经结束：修后固定大资料回放与二次零新增由实现者另行封存；父级还须跑全量集成及A3/A4验收。此时旧93/116计数只是修前封存事实，不能先声称新代码下相同。真实开球时刻取数、具体别名批准、daily开启和线上三次运行依然属于后续正式流程。
