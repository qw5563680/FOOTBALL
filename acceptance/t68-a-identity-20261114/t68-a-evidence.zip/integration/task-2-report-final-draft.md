# T68 A Task 2 实现交接（源码冻结、内部复验通过）

工作树 `/workspace/work/football-t68-a-rest`，分支 `codex/T68-A-identity-and-quarantine`。A1 后续修订已由父级合入；当前 HEAD `13e968dd2725338b0451aac886d6834addb19921`（A1 已合入 main）。Task 2 未提交、未推送。**本报告不是审查批准，不授权任何新身份、daily 开关或生产迁移。**

## 实现与边界

- 新增 `identity_binding.py`：独立离线提案器和 CLI。原始三小时窗口内先双向唯一，再校验精确 UTC、同向、完赛常规时间比分及唯一规范目标/类型；比分和近似名称不选边。所有 T68 新项只为 `proposed`。
- 新增 `identity_binding_archive.py`：校验固定 manifest、表结构和主键、JC 官方目录及 A1 时刻、全部 T61 APIF 原件/sidecar、独立 FD CSV 与既有时区/别名配置。保留拒收/未完赛竞争者；不恢复或打开生产 DB。
- 层级提案有稳定 ID、`layer`、`depends_on`、原件 SHA/指针和真实捕获/提案时间；前层被否/冲突撤下整场证据及传递依赖。数据库 ID 占用和旧候选只可否决，不能充当授权锚。正式时间 scope 按当前 fixture 检查。
- A1 已判冲突的 head 不得 fallback 到 DB 时刻；旧赛事 head 同样重新校验。只在归档已有 counterpart 组件的全部节点均通过来源、赛事、主客规范 ID 和时刻检查后去重参考实体；不按同名/同分自行归并。
- `apif_aliases.py`、`apif_reconcile.py`、`alias_propagation.py`、普通 `apif_ingest.py` 和 `stats_link.py` 在身份使用处检查新 `binding_scope` 类型、目标赛事、可选时间界限；`cup_identity.py` 阻止新 scoped ID 经旧 bridge、DB fallback 或旧图推断变为无 scope 自动项。含 scoped ID/锚的杯赛范围不运行旧自动推断，保留所有竞争行；无新字段的旧项保持语义。正式表、赛事注册表、nations、模型参数/来源、冻结预测均未修改。
- 旧候选按 manifest SHA 读取；声明但缺文件时报错。旧字段格式兼容，同名旧项不因缺 T68 ID 被误判相反；原证据保留，独立复跑使用 `--previous-candidates`。旧队列不是正式授权。
- B 段泛称关联未实现；无体育 HTTP 请求、API key、生产写入或自动核准。

## 固定输入与真实结果

固定来源为旧工作树的只读 `fixed-archive`，数据提交 `e370db1d5cabe1cb33ddbfff3029c6d802bb8992`。这是明确的部分物化输入，不是完整生产备份；父级在原 2,305 文件之外补物化同一提交的 3 个候选文件并逐份验 SHA。FD 辅助原件来自既存 T66 审查输入（捕获约 2026-11-14 02:00 UTC），不冒称来自 e370 的 catalogue。15 个 302 空重定向捕获未作为证据，随后 HTTP 200 CSV 独立核验。

| 项目 | 实跑结果 |
|---|---:|
| APIF 完整原件 capture / 独立 provider-season | 728 / 696 |
| 原始竞争行 / 去重 fixture | 136,130 / 127,361 |
| 完整 JC 目录 | 4,966 |
| 本绑定适配器直连赛事子集有准确 JC 时刻 / 缺时刻 | 745 / 3,639 |
| A1 固定新路由+泛称目标时刻（不同分母） | 146 / 1,262 |
| 新路由库内完赛 / 固定目录内 / 目录外 | 150 / 129 / 21 |
| 无任何正式或 DB 授权锚的 93 已知答案诊断 | **93，逐联赛完全吻合，相反 0** |
| 使用合法正式锚的新赛事图诊断 | **116**，参考汇总 107，净差 +9 |
| 进一步经过完整类型/目标检查的 T68 提案 | **0** |
| 原候选队列保留 / 被错误计为撤下 | **138 / 0** |
| 显式载入首轮队列的第二轮新增 | **0**，队列字节相同 |

93 逐联赛为日职19、瑞超14、挪超14、美职17、韩职12、芬超6、澳超11。当前正式七联赛实际有97项；额外4项均为美职 `1599/费城、1596/圣何塞、1617/波特兰、1598/奥兰多`，未在无锚图中重现，逐项可核实的失败原因保存在 `diagnostic_known_answers.json`。它们未被改写，也没有生成相反提案。

116 **仅是诊断**：省略类别检查、允许既有正式锚，不具批准资格。没有锚的新赛事对应数为57。参考107只有审查汇总，没有逐项名单，不能声称已知道“具体多出哪9项”或补造一个107名单。当前116项逐一列出规范目标、层级、比赛证据及全检查原因；另将21场目录外 DB 比赛逐场列出，均在2026-11-01至11-14，不能从截至10月31日的固定目录得到官方证据。A1 的143完赛数包含泛称赛事，与这里129新路由完赛不是同一集合。

类别缺口不以默认成年男足补齐。已明确成年国家队分组与正式 nations 身份可提供相应类型证据；俱乐部/预备/青年等没有足够正面证据的维持未核实。类型过滤后的0不是对93图诊断的否认，也不是交付正式别名的依据。

## 88 项早年缺口及原件差异

`task-2-earlier-88-gaps.json` 对完整原件减正式 active 的88项逐个重新核验样本路径、SHA与JSON指针，并关联实际失败原因。分母为美11、日14、芬18、瑞19、挪13、韩10、澳3；DB 早年临时项72、全部临时项80不替代这个分母。八个原件中存在但 DB 无对应来源比赛的项为：瑞2163/2174/2176，挪2151/2144/7012，芬2078/10669。未推测它们当时为何未入库。

88项的非互斥原因覆盖数：目标不唯一/尚不能规范化74、窗口不双向唯一71、逐场类型缺证70、无对应窗口41、完整性待核14、全局ID冲突12、时刻不精确相等10、目标已有另一来源ID5、常规比分不同2。每项另注明未取得该 provider ID 的明确类别授权；这些原因不会被隐藏为一个笼统的“无数据”。

六个重复原件状态差异不是已证明的来源造假：日乙 `1606756–1606760` 保存了同日 `2H → FT`，国际友谊赛 `1649017` 保存了 `HT → FT`；比赛时间、主客ID一致，但结束状态/常规比分随捕获变化。当前严格策略不采取最新者胜出，保留各捕获 SHA、真实时间和 JSON 指针并阻断相应窗口。它们均在11月14日，固定目录窗口外。详见 `task-2-raw-conflicts.json`。

另有一组已有关系但参考证据不一致：`fd:SWE:20261029:hammarby:sirius` 与 `jc:2042320`。实体合并被拒绝，保留 `linked_entity_evidence_conflict`，未择一覆盖。

## 验证与证据入口

- 修订后 **89 个 Task 2 测试 + 279 个既有入口回归 = 368 通过**，日志 `task-2-verified-targeted.log`。覆盖普通 APIF 导入、命令、批准校验、reconcile、propagation、杯赛/历史/cloud 和 stats 索引/上下文/batch/command。Ruff check、format --check 与 diff --check通过。初版91通过的旧日志完整保留，不当作修订版验收。全量测试由父级集成验证，本 worker 不声称已跑全量。
- RED→GREEN日志含 `task-2-red.log`、`task-2-adapter-red.log`、`task-2-hardening-red.log`、`task-2-schema-red.log`、`task-2-manifest-red.log`、`task-2-head-red.log`、`task-2-scope-entity-red.log`、`task-2-legacy-red.log`、`task-2-final-boundaries-red.log` 及对应 GREEN/定向日志。合成 fixture 不冒充真实抓取。
- 首轮 `replay-1` 曾因 manifest 的 `.meta.json` 被误计为缺少 fixtures 得到错误的零完整性诊断；已用回归测试修复并保留失败证据。旧 replay 大型 `unverified.json` 仅压缩为 `.json.gz` 节省空间，没有删除其它任务备份。
- 修订版最终产物：`task-2-verified-replay/`、`task-2-verified-repeat/`，对应 `task-2-review-freeze-2.json` 源码 SHA。两次均保留全部138旧队列项、93已知诊断、116新赛事诊断与0新提案。旧 `final/repeat` 对应初审版本；`post-review-replay` 对应 freeze-1，均单独保留且不得混作最终代码验收。
- `task-2-verified-evidence/task-2-validation.json` 保存代码文件SHA、正式受保护文件SHA、来源manifest SHA、原/输出队列SHA、重复一致性和准确测试数。
- `task-2-verified-evidence/` 下 `task-2-new-107-comparison.json` 保存116逐项证据与21场范围差异；`task-2-earlier-88-gaps.json` 保存88逐项；`task-2-raw-conflicts.json` 保存六个原件状态变化。`task2_evidence_verified.py` 是只读生成脚本。

复现：

```bash
PYTHONPATH=src /workspace/work/t48-venv/bin/python -m zucai.identity_binding \
  --archive /workspace/work/football-t68/work/t68-a/fixed-archive \
  --fd-raw-dir /workspace/work/t66-review-20261114/inputs/raw/football-data-co-uk/2026-11-14 \
  --out <全新目录>
# 重跑显式加 --previous-candidates <首轮目录>/apif.json，并使用另一个全新输出目录。
```

## 独立复查与修订

初审确认的七类问题已按单一原因反例完成 RED→GREEN：同源种子的矛盾原件、源批准时界、运行入口时界、已有 counterpart 完整组件、FD 坏行隐藏竞争者、旧 T68 遇新原件矛盾撤回、冲突正式锚隐藏竞争者。随后还修复旧 T68 遇明确的新 formal/DB 全局归属冲突仍有效的问题。撤回保留旧见证和新矛盾/归属证据，撤下整场见证与传递依赖；只有本轮缺少原范围不会撤回，legacy 队列不变。

普通导入、reconcile、propagation、stats 技术索引、cup runtime bridge/DB fallback/infer 已统一检查新 scope 边界。没有重写 cloud 候选生成算法，也没有增加杯赛赛事范围或正式批准。

独立 reviewer 在 freeze-2 上复验 **280项，0失败/错误/跳过**，16个文件 SHA 与冻结清单一致；所有原反例、cup 漏洞与两个 prior-global 变体均闭合。证据 `task-2-review-final-summary.json`、`task-2-review-final2-pytest.log`、`task-2-review-verify-final.log` 与 `task-2-review-prior-global-green.log`、`task-2-review-cup-verify-final.log`。这是内部复验，不是 Claude 正式批准。

固定输入的93/116/0和88逐项缺口未因这些边界修复而改变。实际原因分类差异为旧版15个 `fd_original_unverified` 消失：其中12个属于本绑定赛事映射的空302捕获，现明确标为 `fd_redirect_observation`；另3个不在所选映射内，跳过。HTTP200有效CSV中的坏竞争行与这些空跳转不同，会保留相应时间窗口；不能用另一完整CSV把它隐藏。

初审报告 `task-2-report-pre-review.md` 和所有 RED/旧回放完整保留。大型旧 `unverified.json` 只做无损 gzip，原 SHA、压缩 SHA 及可还原检查记录于压缩清单；没有删改原始输入、其它任务备份或生产数据。
