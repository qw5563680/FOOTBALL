不通过

本结论是 Task4 冻结版本的 fresh 内部审查，不是 Claude 正式批准，也不是用户合并授权。审查基线为 HEAD `13e968dd2725338b0451aac886d6834addb19921`、`task-4-owned-freeze-2.json` 的16个 owned 文件。先读协议/完整 owned 差异和相关调用链，再读交接；未修改产品源码、产品测试或正式数据，未提交、推送、创建 PR、触发 Actions、发体育 HTTP 或使用密钥。

## 发现

### Critical

无已确认项。

### Important I1：最近30日与12个完整月共用一个官方窗口，非月初验收无法达到 ready

- 位置：`src/zucai/identity_daily_gate.py:190`–196、`:480`–488。
- `_recent_replay` 要求 `facts.catalogue_window.end_beijing >= 最近完整北京日`；`assess_league` 又要求同一个 window 精确等于 `complete_month_window(cutoff)`，其结束日是上月末。除每月1日外，这两个条件互斥。例如11月14日截止分别要求结束日不少于11月13日、且恰为10月31日。
- 独立反例：`task-4-review-counterexamples.py::test_midmonth_complete_daily_originals_are_accepted` 实际生成10月14日至11月13日全部31个UTC日的离线原件及 sidecar，重放窗口为10月15日至11月13日；仍在读取原件前于196行抛 `official 30-day denominator incomplete`。如果扩展同一 catalogue window，12月固定窗口检查必失败。此反例不声称“有31日 API 原件就足够”：最近30日官方竞彩分母仍必须有独立完整证据。问题是当前 API 没有容纳该独立官方窗口的可用路径。
- 要求：保留12个完整月的真实球队/场次分母，同时提供独立的最近30日官方窗口原件/覆盖证据入口并重验，不能只删除分母校验。增加非月1日、走整体 `assess_league`/CLI 的正向回归；新证据缺失、SHA错误、缺页时继续 insufficient。当前固定档止10月31日，仍不得因此改判 ready。
- 规格依据：已审协议第7节最近30日/等量样本真实分母，以及第10节不以不完整原件伪装覆盖。

### Important I2：此前 held ID 不在本次 current 原件时被静默丢弃

- 位置：`src/zucai/identity_daily_gate.py:163`–181，关键为171行 `held_before_ids & current_ids`。
- 先把此前暂缓清单与当前原件 ID 取交集，再检查入库/关联，导致此前 ID 从当前原件消失时无需任何解释，且报告称 `held_before=0`。
- 独立反例：`task-4-review-counterexamples.py::test_prior_held_id_cannot_disappear_without_resolution_or_reason` 提供同联赛、2026季、2026-10-21 的 `apif:999` held 记录；当前原件仅含 `apif:10`，库内没有999、也无 counterpart/处置理由。`_current_replay` 未抛异常（预期失败保护的测试报 `DID NOT RAISE ValueError`）。
- 要求：此前集合逐 ID 保留，逐项证明已补入、正确关联或有可审理由；不能因当前原件缺失就假定不属当季。只有可核验的范围证据才能归为别季；无范围凭据继续缺证据。
- 规格依据：协议第7节“此前暂缓集合逐 ID 已补入或正确关联，未解释遗漏=0”；父级要求“held修复或理由”。

### Suggestion

无额外必须扩大的实现范围。此次正向 gate 测试只用了11月1日截止，刚好没有覆盖 I1 的窗口冲突；建议后续窗口回归持续包含月初、月中与跨年。

## Spec 与 quality 分开结论

- **Spec：未通过。** 预算、held分计、候选隔离、普通 Actions 显示及固定62路线分母符合本轮已验证部分；只读 gate 仍有 I1/I2 两条必须修，不能进入父级最终批准材料。
- **Quality：上述两个 gate 边界未通过，其余抽查通过。** 专用预算异常只在实际请求增量0时 defer；中途分页仍 failed/partial；HTTP/validation未变成deferred。held仍不入库、不会写成功checkpoint；混合真正风险仍partial。FDORG ID/code矛盾不能择一归属，未知/布尔赛事ID缺覆盖，原±3h完整竞争窗口保留。A2 binding_scope导入保护和A3回执/旧档恢复的定向回归均通过。

## 独立验证与证据

- `task-4-review-freeze-before.json`、`task-4-review-freeze-after-findings.json`：16/16 SHA与冻结清单一致，无 owned 源码漂移。父级文档变化不计入此清单。
- `task-4-review-counterexamples.log` / `.xml`：**2 tests、2 failures、0 errors、0 skipped，0.718s**，失败原件保存在 `task-4-review-counterexample-artifacts/`；未隐藏或改为通过。首次 shell 无 pytest 的环境错误单独保留在 `task-4-review-environment-error.log`，不是测试结果。反例首次用现有 `/workspace/work/t58-fresh-venv/bin/python`，后续定向用父级指定 t48 环境。
- `task-4-review-boundaries.py` 为独立编写的3项正向边界：分页耗尽后本范围失败/下范围deferred/只扣1配额/无成功checkpoint；FDORG坏行 id=PL/code=PD 矛盾整捕获缺覆盖；实际同批1held+1suspected分别计数且batch partial。
- `task-4-review-targeted.log` / `.xml`：**63 tests、0 failures、0 errors、0 skipped，6.777s**。覆盖上述3项、Task4三个测试文件、旧候选完整窗口/跨原件冲突、FDORG重试预算、FD目录回填、Task3回执roundtrip/旧档残留清理和A2正常导入binding_scope。
- 普通三日 `cloud_feeds apis` 路径由 `test_normal_actions_summary_displays_held_and_duplicate_counts` 实际离线执行；输出在 `task-4-review-targeted-artifacts/test_normal_actions_summary_di0/summary-held/summary.md`，APIF行是 `complete | 入库2 | 拒绝0 | 疑似重复0 | 未绑定暂缓1 | 请求3`。不是仅拼接或手写报告测试。
- 核对交接 `task-4-final3-pytest.xml` 为365 tests、0 failures/errors/skipped、24.310s；这是实现方定向证据，本 reviewer 未重复跑365或全量套件。父级负责全量pytest/Ruff和26模型整合。
- 复验 `task-4-fixed-evidence/daily-gate-all62-final.json` SHA=`c6203407ff18d7d492cad3ee6f97bd51c42a26bd1580255710643dadf8b62cb4`，62 route / 1083场 / 32零场route，全部insufficient。逐code独立分母对照由父级提供，本 reviewer没有把其当自己复算。
- 447重分类证据清楚注明“200次离线预算模拟、447未请求、39有raw partial保留”，未回写历史日志。138旧候选清单仅证明保留，真实普通日期原件0份，因此不称作实际有数据的隔离重放。

复跑命令（只读产品；测试临时文件写 review 子目录）：

```sh
PYTHONPATH=src:tests /workspace/work/t48-venv/bin/python -m pytest -q \
  work/t68-a/task-4-review-boundaries.py \
  tests/test_t68_collection_status.py tests/test_t68_candidate_isolation.py tests/test_t68_daily_gate.py \
  tests/test_cloud_aliases.py \
  tests/test_t61_catalogue_backfill.py::test_fdorg_hard_limit_counts_retry_and_can_replay_later \
  tests/test_t61_fd_catalogue_backfill.py \
  tests/test_t68_cross_day.py::test_optional_receipt_roundtrip_and_old_archive_clears_residue \
  tests/test_t68_identity_binding.py::test_review_normal_import_checks_binding_scope_for_each_fixture
```

## 固定四问

1. **是否碰冻结 predictions/parameters/run_log？** Task4 owned差异不写冻结预测、参数、评分、账本或既有日报。gate只写新的归档外报告；审查只写work审查证据。本轮没有独立重做完整正式归档不可变文件哈希验收，由父级整合承担。
2. **是否影响其他比赛匹配、路由或概率？** 正式registry、来源、params、API key和B泛称实现未在Task4改动。held改变报告身份，不改变“不入库”保护。候选变化只允许此前被别赛事坏行连带阻断的案例；实测合成 `apif:91001` held、`apif:91002` suspected，未新增Match。真实普通日期raw缺失，无法逐ID穷举新增候选；138旧候选保留证据没有补足这一限制。模型影响由父级26模型验收，不能因本63项通过就称概率全不变。
3. **新计算是否只用开球前信息？** Task4 gate/身份审查使用已完赛历史证据，属于离线验收，不是赛前特征；没有把它作为新训练输入或预测时可知信息。赛后原件不得被当作当时可见；本轮未放宽 available_utc、来源或回填训练政策。
4. **测试是否覆盖改动点，缺什么？** 63项覆盖预算/HTTP/分页/held/候选/Actions/回执恢复等；独立2反例发现非月初双窗口及丢失held清单漏测。还需修后整体非月初gate正向/负向和逐held解释测试；正式30日原件、真实完整当季回放与线上三次链路仍是外部证据缺口，不能用合成用例替代。

## 剩余范围与交回

先修 I1/I2，再对新冻结版本限定复查。当前不建议进入父级最终整合批准；父级已在首轮全量测试中保留冻结与日志，可独立完成读时检查。没有体育HTTP、正式绑定批准、daily开启、生产发布或合并授权。新routes没有正式current_season元数据仍须null；`ready_for_review`永不等于许可。
