"""Scoped independent checks for bridge and non-entity-reference fixes."""
import csv
import sqlite3
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tests"))
import test_t68_cross_day as h
from test_t63_source_audit import database
from zucai.db import session_scope
from zucai.models import Match, Result
from zucai.predict.pooled import select_training_history
from zucai.result_source_links import record_result_link
from zucai.source_results_audit import audit_source_results

db = h.db


@pytest.mark.parametrize("reference", ["fd:E1:20260901:swansea:watford", "apif:999999", "fdorg:999999"])
def test_non_entity_reference_does_not_grant_pair_exemption(db, reference):
    with session_scope(db) as s:
        jc = h.clone(s, h.FD, "jc:review-reference")
        jc.counterpart_id = reference
        s.flush()
        selected = select_training_history(h.history(s, sources="jc,apif"), h.CUTOFF)
        assert jc.match_id in set(selected.match_id)
        assert h.API not in set(selected.match_id)
        assert any(row["match_id"] == h.API for row in selected.attrs["unverified_fd_identity_overlaps"])


@pytest.mark.parametrize("reference", ["fd:E1:20260230:swansea:watford", "apif:0", "fdorg:wrong", "jc:123"])
def test_malformed_or_wrong_source_missing_reference_is_still_risk(tmp_path, reference):
    path = database(tmp_path, "consistent")
    with sqlite3.connect(path) as conn:
        conn.execute("UPDATE matches SET match_id='jc:review',source='jc',counterpart_id=? WHERE source='fd'", (reference,))
        conn.execute("UPDATE results SET match_id='jc:review' WHERE match_id LIKE 'fd:%'")
    out = tmp_path / "audit.csv"
    report = audit_source_results(path, out)
    rows = list(csv.DictReader(out.open()))
    assert any("counterpart_missing" in row["risk_reasons"] for row in rows)
    assert report["non_entity_source_references"] == {}


def test_external_reference_with_temporary_identity_and_competing_claims_is_not_summarized(tmp_path):
    path = database(tmp_path, "consistent")
    with sqlite3.connect(path) as conn:
        conn.execute("DELETE FROM matches")
        conn.execute("DELETE FROM results")
        conn.execute("UPDATE teams SET name='apif:team:temporary' WHERE id=1")
        for key in ("jc:one", "jc:two"):
            conn.execute("INSERT INTO matches VALUES (?,'jc','英超',1,2,'2026-09-01T14:00:00Z','apif:999999')", (key,))
            conn.execute("INSERT INTO results VALUES (?,2,1,'2026-09-01T18:00:00Z','captured')", (key,))
    out = tmp_path / "audit.csv"
    report = audit_source_results(path, out)
    rows = list(csv.DictReader(out.open()))
    assert len(rows) == 2 and report["temporary_identity_rows"] == 0
    assert all("multiple_counterpart_claims" in row["risk_reasons"] for row in rows)


@pytest.mark.parametrize("remote_league", ["美职", "日职"])
def test_unrelated_duplicate_source_component_does_not_block_selected_bridge(db, remote_league):
    with session_scope(db) as s:
        old = s.get(Match, h.FD)
        old.kickoff_utc = s.get(Match, h.API).kickoff_utc
        s.get(Result, h.FD).available_utc = h.KNOWN.isoformat()
        anchor = h.clone(s, h.API, "jc:review-valid", result=False)
        anchor.counterpart_id = h.FD
        remote_fd = h.clone(s, h.API, "fd:review-remote", result=False)
        remote_fd.league = remote_league
        for key in ("jc:review-remote-one", "jc:review-remote-two"):
            remote = h.clone(s, remote_fd.match_id, key, result=False)
            remote.counterpart_id = remote_fd.match_id
        s.flush()
        record_result_link(s, s.get(Match, h.API), anchor, h.KNOWN.to_pydatetime())
        selected = select_training_history(h.history(s, sources="fd,apif"), h.CUTOFF)
        assert h.FD in set(selected.match_id) and h.API not in set(selected.match_id)
        assert not any(row["match_id"] == h.API for row in selected.attrs["unverified_fd_identity_overlaps"])
