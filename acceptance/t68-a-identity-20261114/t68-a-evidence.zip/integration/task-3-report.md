# T68 A Task3 implementation handoff

Status: two Important review findings fixed; second implementation freeze ready for scoped independent re-review. No commit, push, PR, production write, sports HTTP request, formal key, alias approval, model/source-policy change, or B implementation was performed. Parent owns all repository docs, final full suite, exact 26-model regression and packaging.

## Scope and behavior

- `pending_fd_identity_overlaps` retains its public API. Its old one-unknown-FD branch remains the original complete-database, bidirectionally unique, unclaimed <=3h rule. New `unverified_same_identity_overlap` candidates require equal oriented canonical IDs, same league, different allowed sources and <=36h, including the boundary; score agreement is never an input to candidate discovery. Every candidate is retained, including multiple candidates and candidates having an unrelated third-source link.
- The new branch is restricted to `actual_result_leagues()` (the existing 15 T63 `actual_capture` leagues) and each league's unchanged `apif_history_sources()`: APIF 15, FDORG 9. It does not extend source or proof policy to 韩职/澳超, 中超/丹超, new competitions, or legacy source-policy models. Current policy contains 韩职/澳超 without `actual_capture`, and no 中超/丹超 entry. Four explicit boundary tests retain their prior behavior; this delivery makes no universal training guarantee for new competitions.
- `read_history` retains current proof/receipt candidates, and selection applies existing identity/actual-result availability gates before quarantine. Both results must be eligible at the same strict cutoff. Future or absent counterpart results do not remove a currently eligible paid result. Future links cannot exempt an earlier cutoff.
- Complete components include dated links through unselected/non-result sources and exact old JC/FD pointer anchors in the T63 scope. Old anchors remain <=3h, same-league, same-oriented canonical IDs; no timeless paid proof is added. Before adding a relevant old bridge, its complete incoming/outgoing claim component is checked, including unselected/non-result/cross-league/out-of-window/reversed/dangling claims and duplicate source IDs. Invalid components are rejected; unrelated components cannot block the selected one. Quarantine runs before `linked_representatives`, preserving protection when FD later collapses to its JC representative. Already connected exact pairs are exempt only through the cutoff-valid component.
- Reliable JC/FD rows remain. Two unresolved added paid sources with no reliable old row are both withheld. Explicit `same_match` on two paid rows with different scores also withholds both; a decision is not an authority for choosing a score.

## Minimal decision registry and receipts

The committed `data/identity_reviews/t68-cross-day.json` has `schema_version: 1` and an empty `decisions` list. There are no real approvals.

Command: `PYTHONPATH=src python -m zucai.cross_day_decisions apply --db <isolated.db> --registry <approved.json>`.

An entry has exactly `decision_id`, `decision` (`same_match`/`different_match`), sorted two `match_ids`, `snapshot`, `approved_utc`, `approved_by`, `approval_ref`, and nonempty `evidence`. Read-only `decision_snapshot(session, match_ids)` captures all Match/Result/Team columns, current identity verification timestamps and the complete touching graph of verified links/pointers. This includes source/league/team IDs, canonical names and aliases, regular-time scores, availability basis and timestamps, result observation timestamps and counterpart references.

Evidence entries contain `path`, `sha256`, `observed_utc`. Apply verifies the actual local original bytes and embeds their base64 copies in the optional receipt (each original <=1 MiB). Receipt restoration therefore does not depend on the original development path. Entries only cover same-league, oriented canonical pairs with 3h < kickoff delta <=36h, and must be approved after both results/identities/evidence are known. They cannot widen the ordinary <=3h guard/link window.

Approval syntax reuses `apif_aliases.validate_approvals(require_metadata=True)` (UTC approval timestamp and complete `https://github.com/qw5563680/FOOTBALL/pull/<positive-number>` reference, optionally its accepted issuecomment suffix). This tool additionally requires `approved_by == "qw5563680"`. Neither a string nor a well-formed URL proves a PR was reviewed/approved: offline code does not query GitHub. Actual authorization remains the repository approval process and explicit application. All test approvals use clearly synthetic fixture evidence and placeholder PR numbers.

Apply writes only `<db parent>/state/t68_cross_day_receipts.json`, with actual `datetime.now(UTC)` application time and entry/receipt/evidence hashes. There is no CLI backdating option. Reapplication is byte-idempotent. Training requires a matching current registry entry and current full snapshot plus a validated receipt; effectiveness is strictly after its actual application (which is >= approval). Configuration alone, future approvals/receipts, missing/tampered originals, changed snapshots or changed registry entries cannot authorize a pair. `different_match` only releases its exact pair; another unresolved overlap continues to withhold it. `same_match` selects the existing source priority within this quarantine layer, without writing T63 links or creating a shared B relation view.

`cloud_feeds` validates and hashes the optional receipt; old archives remain readable and clear a stale destination receipt. Roundtrip selection is tested. No database schema was added.

## Fixed input and audit evidence

Input: immutable results-only DB `/workspace/work/football-t68/work/t68-a/model-fixture/data/zucai.db`, SHA256 `719f06b8cf800ccccc70f4eb158ecb092aa15d8da3ee8e29f98a4fca43abfb3a`; before/after hash matches. It is not a complete production backup. Real fixture `data/fixtures/t68/cross_day/real12.json` preserves the parent-prepared 26,972-byte clip (24 matches/results, 11 teams, 12 original identity proofs), SHA256 `36352b09a31f0eb6b5e32fd4eba71dfec297872fdb2edfaf7a31b0abc9585a40`.

All twelve fixed APIF IDs are withheld after both sides become known, leaving their twelve FD rows: `695164,695206,695213,816780,816884,980819,981244,981246,1150767,1151233,1151235,1151237`. No pair is asserted to be the same match. The original review's eleven one-sided-unbound risks lack an available original ID list; the retrospective score locator is not used as authority and this report does not claim to reproduce eleven IDs. A synthetic independently validated binding transition proves that an identified row moves into the new same-ID protection regardless of score.

`source_results_audit` keeps all raw comparisons and independently checks source/binding/time/score/orientation/pointer/multiple-candidate risks. Only a row whose sole reason is temporary identity is summarized by league. Temporary team IDs, distinct APIF match IDs and comparison rows are separate counts. All other risks retain per-pair evidence even when names are temporary. Independent risks change an otherwise consistent/unmatched row into unverified before actionable filtering. JC may hold an absorbed FD/APIF/FDORG source key without a separate Match; these are independently counted as non-entity source references rather than falsely labeled broken Match pointers. Source references confer no identity or same-match authority, and competing claims remain per-row risks. The audit remains source-comparison evidence, not a training or score-truth decision.

Final fixed outputs: `work/t68-a/task-3-fixed-audit-reviewed.json`, `.csv`, `task-3-fixed-audit-diff-reviewed.json`, and `task-3-source-references-reviewed.json`. Initial 43-row and intermediate 578-row outputs are retained as review evidence; neither is the final audit. The reviewed diff preserves old evidence for every added/reclassified/downgraded pair.

| Measure | Old baseline code 2730083 | Final Task3 |
|---|---:|---:|
| Complete comparison denominator | 38,833 | 38,821 |
| Raw actionable comparisons | 6,596 | 6,592 |
| Pure temporary identity comparisons | 6,577 | 6,571 |
| Per-pair substantive details | 19 | 21 |
| League summary rows | 0 | 5 |
| Actual exported CSV data rows | 6,596 | 26 |

The twelve new pairs replace 24 unmatched APIF/FD records with 12 risk records (denominator -12). One newly visible reversed Norwegian pair (`apif:681704`, `fd:NOR:20210630:brann:lillestrom`) has no APIF result; it replaces one FD unmatched record, with no denominator change. Six formerly temporary-only pair keys are reclassified for counterpart identity conflict: APIF `1494327,1490588,1490589,1490592,1490594,1490595` (full counterpart IDs in the diff JSON). The former seventeen counterpart_missing entries are all JC→APIF source references, allowed by the legacy API ingestion target branch. Their old values and each ID are preserved in the reviewed diff, explicitly labeled “合法外部来源引用，不代表已找到Match/已核实同场”. They become unmatched source-reference records in the full denominator, not silently deleted rows. Thus final raw actionable = 6,596 + 13 added risks - 17 source references = 6,592; 6,592 - 6,571 pure temporary = 21 risk details, plus five summaries = 26 CSV rows. The old 6,596/6,577 totals, nineteen-detail remainder and initial 43-row output were not forced.

The intermediate 578-row output exposed 535 more stored JC source keys (481 FD and 54 FDORG) which are also allowed to lack a Match. `fd_ingest.py` writes the FD key on JC then continues without creating FD; `fdorg_ingest.py` and the legacy `apif_ingest.py` target branches likewise preserve source keys. This classification does not depend on omitted `apif_fixture_index` or technical tables. Final `non_entity_source_references` = `{apif:17, fd:481, fdorg:54}` (552 total), with all IDs in the source-reference inventory. By contrast, the reviewer’s FD→missing JC remains a structural risk; two JC rows claiming the same external source key remain `multiple_counterpart_claims`.

## Verification

Final command (offline, explicit task basetemp):

`PYTHONPATH=src /workspace/work/t48-venv/bin/python -m pytest -o addopts= -q tests/test_t68_cross_day.py tests/test_t63*.py tests/test_t66_fd_apif.py tests/test_pooled_pipeline.py tests/test_cloud_feeds.py work/t68-a/task-3-review-adversarial.py -o tmp_path_retention_policy=failed --basetemp=work/t68-a/pytest-task3-final-reviewed`

Result: **652 passed**, 1,097 existing penaltyblog/NumPy deprecation warnings, 31.49s. This includes 66 product Task3 cases and all 17 independent review counterexamples. Only the targeted regression group was run, not the full project suite. Targeted `ruff check`, `ruff format --check` on all nine owned Python files and `git diff --check` pass. Parent-requested final full-suite and 26-model comparison are intentionally left to the parent; they are not claimed here.

Logs: `task-3-red-core.log`, `task-3-red-decisions.log`, `task-3-red-audit.log`, `task-3-red-audit-proof.log`, `task-3-red-old-anchor.log`, `task-3-red-approval.log`; green iterations plus final `task-3-final-targeted-reviewed.log` and `task-3-ruff-reviewed.log`. Review red/green evidence: `task-3-worker-review-red.log` (independent 5 failed/12 passed), `task-3-worker-regression-red.log` (7 product failures), `task-3-worker-reference-red.log`, `task-3-worker-ref-claims-red.log`, and `task-3-worker-reference-green.log` (122 passed).

The expanded regression first exposed a Connection-bound SQLAlchemy Session adapter defect; fixed by obtaining the database through `session.connection().engine.url`. Three old T63 assertions expecting overlap exceptions after both same-ID rows were known now assert the approved T68 behavior (retain FD plus explicit quarantine evidence). The old combined audit example was separated beyond 36h because its two synthetic cases otherwise introduce a genuine new cross-day risk; the temporary-only tests now assert a league summary. Other old unknown-FD/three-hour boundaries remain unchanged.

All 16 files in `task-2-review-freeze-2.json` still match their frozen hashes. Second owned product/test/fixture hashes are recorded in `task-3-review-freeze-2.json`; the original `task-3-review-freeze.json` is retained. Relative to the first freeze, only `source_result_quarantine.py`, `source_results_audit.py` and `test_t68_cross_day.py` changed. After this second freeze the worker is read-only pending parent-triggered re-review. Parent must rerun its 26-policy input check and final fits against this freeze; pre-fix numbers are not asserted here.
