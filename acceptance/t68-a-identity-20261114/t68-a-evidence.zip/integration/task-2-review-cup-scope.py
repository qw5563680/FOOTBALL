import json
from pathlib import Path
from tempfile import TemporaryDirectory
from zucai.db import get_engine,init_db
from zucai.sources.cup_identity import _bridge
with TemporaryDirectory(prefix='t68-review-cup-',dir='work/t68-a') as td:
 db=Path(td)/'test.db';engine=get_engine(db);init_db(engine);engine.dispose()
 entry={'canonical':'Alpha','status':'auto_verified','binding_scope':{'leagues':['来源联赛'],'category':'club/men/senior/first','start_utc':'2018-01-01T00:00:00Z','end_utc':'2018-12-31T23:59:59Z'}}
 result=_bridge('apif',db,'欧罗巴',{'101':'Alpha'},{'来源联赛':{'101':entry}})
 print(json.dumps(result,ensure_ascii=False))
