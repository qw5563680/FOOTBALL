# Task4：采集分类、候选隔离与只读开启登记

实施仅写 Task4 源码、测试、离线 fixture 和本工作目录证据；未发体育 HTTP，未使用正式 key，未改正式别名/registry/nations/模型参数或来源，未改 Task3 receipt/审计/训练适配，未提交或推送。保留 Task2 `binding_scope` 防护。完整套件、26模型对照、正式导出恢复、文档与发布由父级统一负责。

## 实现与边界

- `request_budget.DeferredRequestBudget`（兼容 ValueError）只表示本批请求上限；API/FD catch 仅在当前 scope 的实际请求增量为0时记 `deferred_scopes[].reason=deferred_request_budget`。不中断剩余范围登记、不占 APIF 本地配额、不进入成功 checkpoint。已发请求后截断分页/重试仍是 failed/partial，原因明确“请求中途达到本批上限，分页/范围未完成”；HTTP、配额、配置、解析、导入异常保持原失败分类。
- 目录报告新增 `scope_counts={completed,partial,failed,deferred,held}`，与 `planned_scopes/resumed_scopes/requests/max_requests` 分列。文本摘要同时列计划、成功、部分、失败、未请求待续、暂缓和已完成跳过。
- APIF 新增 `held_unbound` 数字和 `held` 逐场列表（含 `reason_code=held_unbound`），只针对没有其他实质冲突的单个 JC 三小时窗口未绑定保护。比赛仍不入库。已知侧反向/不符、多个 JC、占用、同窗 APIF、比分冲突、无效行保持原 suspected/rejected。混合批次真实风险仍使日报 partial。
- `state/audit/apif_held_unbound.csv` 沿现有 APIF 审计字段归档；现有 feeds 通用 CSV 白名单已支持，不改 Task3 whitelist。日报显示“未绑定暂缓 N（不计异常）”。只有 held 的 scope 状态为 `held`，即使批次没有异常也不写成功 checkpoint。
- `cloud_aliases` 从原件严格正整数赛事 ID 归属拒收行，只排除该赛事的 games 和 coverage。FDORG 同时核验 numeric ID 与 code。缺 ID、布尔 ID、未知归属、部分分页整 capture 缺覆盖；原窗口/跨原件唯一性与旧候选合并语义保留。未对受保护新 daily 路由放行。

## 新 CLI 与输出字段（供父级同步文档）

```
PYTHONPATH=src python -m zucai.identity_daily_gate \
  --archive /path/to/read-only-frozen-archive \
  --cutoff 2026-11-14T12:00:00Z \
  --codes 307,79,1,89,17,13,6,18,41,99 \
  --out work/t68-daily-register.json
```

`--codes` 可省略（全部已核准 import route）；`--evidence /path/to/bundle.json` 可选。输出必须不存在且位于归档之外；只读取归档与正式配置，不改 daily。

顶层 `version/archive/daily_changed/leagues`；逐赛事 `provider_code/league/status/cutoff_utc/official_window/recent_window/teams/matches/current_season/missing_evidence/blockers/evidence/daily_changed/online_permission`。

`teams` 含实际官方球队 ID 分母 `total`、已核准且满足范围的 `bound/bound_ids/binding_rate`、逐队 `unbound` 原因；`matches` 含实际官方场次分母 `total`、一一核验的 `linked/relations/link_rate` 与逐场 `unresolved`。0分母率为 null，不报100%。正式 `current_season` 缺失即 null，不取 max 历史年补造当季。当前 roster 或官方窗口有未绑定者保守阻止开启；完整原因清单不等于全绑定。

状态为 `insufficient_evidence` / `blocked` / `ready_for_review`。最后一种也仅允许交审，`daily_changed=false`、`online_permission=reviewer_verification_required`；工具不会替代审查或线上验收。

可选 bundle 按 provider code 组织，每项必须绑定 `provider_code/archive_sha256/cutoff_utc`。全部文件引用为 `{path,sha256}`，路径相对于 bundle 所在目录、禁止逃逸/符号链接、重新核验 SHA。不能用 `complete=true` 代替证据。四组必需证据：

1. `current_season_replay`: `report`（实际回填 JSON scope 必须为完整当季、原件 SHA 属于已验证当前季、解析数对应完整集合、held/rejected/suspected均0）和 `held_before`（逐场 CSV；此前当季集合必须已存入或关联当前状态）。
2. `recent_replay`: `mode=dates|equivalent`、`originals`、`results`。日期模式重验原件/sidecar/API URL/完整页/时间与日期，要求覆盖30北京日涉及的全部31个UTC日。等量模式还须从已验证且捕获足够新的完整赛季原件推导同窗不同 fixture 分母，与样本逐ID相同，并给 `boundary_cases`，每项含 `category/fixture_ids/source_sha256/original/outcome`；验证未绑定、同队同刻、反向、拒收、部分分页、跨日的实际原件结构，六个标签贴同一易匹配行不能通过。`results` 含 `fixture_ids/raw_sha256/inserted/risk_ids/outcomes`；每ID一条 outcome，疑似/拒收不可从 risk inventory 删掉，原件解析拒收也不能伪称插入。
3. `risk_review`: JSON列表，每项 `fixture_id/reason/disposition/review_evidence`；ID集合必须等于重放风险集合，处置为 quarantined/same_match/different_match，逐项核验证据哈希。
4. `persistence`: `repeat_report`（实际处理非0、第二次 inserted=0）、`before_repeat/after_repeat/restored`（完整相同的 `coverage/relations/quarantine/training_selection/immutable_sha256` 快照）、`before_manifest/after_manifest/restored_manifest`。初始 manifest 必须属于当前冻结归档，三份 manifest 核心与关系文件相同，逐文件实际存在且哈希正确；immutable inventory非空并核验三份实际文件。只提供相同的清单声明、缺实文件不能通过。

## 实跑结果

- 最终定向：`task-4-final2-pytest.log` / XML，**364 tests，0 failures，0 errors，0 skipped，24.73s**。涵盖3个Task4新测试文件、目录/API/FD回填、APIF导入/CLI/审批/审计、候选、日报、T65每日范围、T63留行、T68绑定。
- `task-4-ruff-check.log`：All checks passed；`task-4-ruff-format-check.log`：14 files already formatted。`git diff --check` 通过。
- 红绿证据：`task-4-collection-red.log`（缺专用分类/held），`task-4-alias-red.log`（跨赛事连带跳过、未知/布尔归属），`task-4-gate-red.log`，`task-4-gate-boundary-red.log`，`task-4-gate-equivalent-red.log`，`task-4-gate-hardening-red.log`，`task-4-gate-risk-red.log`；对应绿日志全部保存。
- 首次扩大定向误写不存在的 `tests/test_apif_aliases.py`，仅产生无测试的 `task-4-final-path-error.log`，随后改为真实存在的 verify/approvals 文件。没有把该次当作通过。

## 固定真实证据与限制

所有本任务固定产物在 `work/t68-a/task-4-fixed-evidence/`。

- `daily-gate-all62-final.json` 覆盖全部62条新route，与父级独立 `a-rest-jc-denominator-baseline.json` 逐code球队/比赛分母一致（本任务对照 `daily-gate-final-comparison.json`）：合计1083不同场次；32条0场，率全部null；62条均 `insufficient_evidence`。前十沙职172/21、德乙138/24、世界杯104/48、荷乙90/19、亚冠精英66/38、解放者杯62/31、非洲杯48/23、亚冠乙44/29、英甲43/24、日乙40/25（场/队）。
- 固定官方目录止于2026-10-31，截止2026-11-14时要求的最近30北京日为2026-10-15至11-13，11月缺档；固定 partial archive 没有普通日常API日期原件，也没有本轮完整当季held复放/30日重放/本工具恢复证据bundle。新route正式current_season元数据缺失另列。不得用结果fixture或稀疏库内行称完整30天。
- `request-budget-reclassification.json` 核对原43572899357-1 SHA，planned696/resumed49/scopes647，前200有raw=requests=max200，后447全部无raw且集合恰等failed_scopes；另外39个WITHraw partial逐scope原样保留。新RequestBudget与defer_scope按同序实际离线运行得到200调用/447专用deferred；它是明确标记的离线预算模拟，不冒充历史HTTP/导入重放，也不改旧log。
- `candidate-retention.json`：固定138条既有候选逻辑逐条相同、原文件SHA未变，空日期输入两次新增均0。因真实日期原件不存在，只证明旧队列保留；按赛事坏行隔离实效由data/fixtures离线红绿案例证明，不宣称真实全量每日回放完成。只读结果/model fixture 查询用于此保留检查，不称full backup。
- held回填fixture实跑证明无成功checkpoint，新CSV导出/全新恢复字节相同；完整离线gate fixture证明 `ready_for_review` 仍不改daily，恢复ledger被改后立即退回 `insufficient_evidence`。这些均是合成fixture回归，不是线上开启证据。

实现已停止写产品文件，等待父级独立复查。文件冻结清单见 `task-4-owned-freeze.json`；如复查要求修复，将另存新阶段日志与清单。
