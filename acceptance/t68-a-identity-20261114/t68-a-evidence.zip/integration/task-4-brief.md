# T68 A 段实施计划


**Goal:** 提供严格绑定证据与补时刻工具，修正跨日重复和采集口径，产出可复核离线证据。
**Architecture:** 沿用正式候选队列、reconcile/relink-jc、原来源保存策略；只新增离线校验/审核工具和局部保护。B段仅文档，不实现。
**Tech Stack:** Python 3.12、SQLAlchemy/SQLite、requests、现有pytest/ruff；不新增依赖。
**Spec:** `docs/experiments/T68-identity-binding-protocol.md`；PR140 review5904223500；PR139 task增补，由所有者本轮指示采用。

## Global Constraints

- B段泛称赛事关联不实现；不设新赛事独立留行/时标范围，不修改模型来源/参数。
- 正式API密钥仅Actions，开发不发体育请求；全部测试仅data/fixtures离线样本。
- 只产生待审候选，不自行核准别名，不开启daily，不改生产数据/冻结预测/旧报告/账本。
- 同联赛同向，绑定提案开球准确相等、90分钟完赛比分相等、完整窗口双向唯一；不用模糊名称或比分消歧。
- 既有18联赛原条目不改不删；新T68条目逐赛事范围限制，旧条目语义不变。
- 每批保存实际捕获/核验时间；新证据不倒填，不用后到证明改写既有冻结结果。
- 主干测试基线4023通过；最终全量pytest、ruff check、ruff format --check；reports≤200KB。

## Review Focus

- 目录中的同ID与主客/日期不符：补时刻不补造、不写比赛表。
- 多原件同fixture冲突/缺页或拒收隐藏竞争者：不推断新绑定。
- 同层互相自证、上层锚被否：阻断与撤下全部传递依赖。
- 36h重叠有多个候选/第三方已有关系：隔离不得因“不唯一”或“已有任意链接”而漏掉。
- 当前配置注入过去归档：无实际观察证据的跨日决定不影响更早cutoff。

### Task 4: 采集分类、候选隔离、开启门槛与整合

Files: `cloud_catalogue_backfill.py`、`cloud_api_backfill.py`等实际catch入口、`cloud_aliases.py`、`sources/apif_ingest.py`、报告渲染；必要新增 `identity_daily_gate.py`。测试 `tests/test_t68_collection_status.py`、`tests/test_t68_daily_gate.py`。
- [ ] RequestBudget专用待续原因：到上限无请求/无配额/无成功checkpoint；HTTP/校验失败仍失败，摘要数字分开。
- [ ] 未绑定导致暂缓与真疑似重复/拒收分开；未绑定单独发生不使日报异常；混合真实冲突仍异常。
- [ ] 候选坏行按可安全确定的赛事隔离；未知归属整份不作候选。旧候选差异只允许此前被别赛事坏行牵连的情况。
- [ ] 每赛事只读开启登记校验：球队/场次分母可解释、当季暂缓补齐或明确原因、30天完整覆盖、风险逐项、重复0及恢复一致；缺证据不判可开。工具不写daily开关。
- [ ] README、ARCHITECTURE、DATA_SOURCES更新；独立固定归档副本跑A段工具、二次0新增及导出恢复；正式冻结/旧账本SHA不变。
- [ ] 全量pytest/ruff、内部独立review；报告大文件放独立证据分支，原PR推送并逐项回复，不合并。线上head请求、条目核准和开启仍等Claude。


Worktree: /workspace/work/football-t68-a-rest; branch codex/T68-A-identity-and-quarantine. Read AGENTS.md and task139-revised-T68.md/task139-review-T68.md (PR139 3dbabc7f). Task1 is delivered separately PR140 at58548359; latestdocfollowup4427f233. Parent owns docs, finalfullsuite, commit/push/PR and packaging. No production/sportsHTTP/formalalias/registry/modelparams/nations changes, no commits/push/subagents. TDDfixturetests and per-task logs.

Read-only parent baseline /workspace/work/football-t68/work/t68-a/request-budget-447-baseline.json verifies original backfill43572899357-1 manifestSHA: planned696,resumed49,scopes647,first200raw=requests=max_requests200,remaining447allno raw and equalfailed_scopes set. Other39partial scopes WITHraw remain separately; do not relabelall486errors. Historicalreinterpretation groundedoriginalorder+sourceBudget+formalreviewT65:110, not ambiguousValueErroralone. No oldlog rewrite. Include new fixture actual447deferrals preservation with dedicatedexception; do not network.
