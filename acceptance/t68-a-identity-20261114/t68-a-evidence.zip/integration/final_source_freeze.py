"""Save/check all final source, tests and small fixtures before regression runs."""
import argparse
import hashlib
import json
import subprocess
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'work/t68-a/a-rest-source-freeze.json'
parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=('save', 'check'))
args = parser.parse_args()
files = {}
for name in ('src', 'tests', 'data', '.github'):
    for path in sorted((ROOT / name).rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts or '.pytest_cache' in path.parts:
            continue
        relative = str(path.relative_to(ROOT))
        # Include all tracked/owned implementation files, including new fixtures;
        # ignore runtime/raw DB artifacts that must never be product commits.
        known = subprocess.run(['git', 'check-ignore', '--quiet', relative], cwd=ROOT).returncode
        if known == 0:
            continue
        files[relative] = hashlib.sha256(path.read_bytes()).hexdigest()
if args.mode == 'save':
    assert not OUT.exists(), 'A freeze must never be silently overwritten'
    OUT.write_text(json.dumps(dict(observed_utc=datetime.now(UTC).isoformat(), files=files), ensure_ascii=False, indent=2) + '\n')
    print('frozen_files', len(files))
else:
    original = json.loads(OUT.read_text())['files']
    differences = [key for key in original.keys() | files.keys() if original.get(key) != files.get(key)]
    assert not differences, differences
    print('unchanged_final_source_files', len(files))
