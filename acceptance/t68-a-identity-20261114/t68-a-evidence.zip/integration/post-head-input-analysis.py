import collections,hashlib,json
from datetime import datetime,timezone
from pathlib import Path
from zucai import jc_catalogue_kickoffs as clocks

p=Path('work/t68-a'); root=p/'post-head-archive'; old=Path('/workspace/work/football-t68/work/t68-a/fixed-archive')
def read(path):return json.loads(path.read_bytes())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
plan=read(p/'post-head-kickoff-plan.json')
catalogue,_,_=clocks._catalogue(root)
selected={row['match_id'] for row in plan['verified']+plan['pending']}
counts=collections.Counter((row['league_id'],row['league']) for row in catalogue if row['match_id'] in selected)
heads=collections.defaultdict(list)
for path in root.glob('state/catalogue/*/jc-heads/*.json'):
 if path.name.endswith('.meta.json'):continue
 meta=read(path.with_suffix('.json.meta.json'))
 heads[path.stem].append(dict(path=path.relative_to(root).as_posix(),sha256=sha(path),metadata_sha256=sha(path.with_suffix('.json.meta.json')),fetched_at_utc=meta['fetched_at_utc'],url=meta['url'],status_code=meta['status_code']))
unique_captures={(r['sha256'],r['metadata_sha256']):r for copies in heads.values() for r in copies}
times=[r['fetched_at_utc'] for r in unique_captures.values()]
core={}
for name in ['state/matches.jsonl','state/teams.jsonl','state/results.jsonl','state/alias_candidates/apif.json']:
 core[name]=dict(before_sha256=sha(old/name),after_sha256=sha(root/name))
 core[name]['same_bytes']=core[name]['before_sha256']==core[name]['after_sha256']
result=dict(observed_utc=datetime.now(timezone.utc).isoformat(),data_commit='afdf86dd9adbd5cf9bec0e5d3dee832eba1b208a',
 catalogue_matches=len(catalogue),target_matches=len(selected),verified=len(plan['verified']),pending=len(plan['pending']),
 a_direct_target_matches=sum(n for (code,name),n in counts.items() if code not in clocks.GENERIC_IDS),
 b_excluded_target_matches=sum(n for (code,name),n in counts.items() if code in clocks.GENERIC_IDS),
 by_competition=[dict(league_id=code,league=name,matches=n,scope='B_excluded' if code in clocks.GENERIC_IDS else 'A_direct') for (code,name),n in sorted(counts.items())],
 head_files=sum(map(len,heads.values())),distinct_head_ids=len(heads),distinct_captures=len(unique_captures),
 actual_capture_min=min(times),actual_capture_max=max(times),core_comparison=core,heads=heads)
(p/'post-head-input-analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['heads','by_competition']},ensure_ascii=False))
