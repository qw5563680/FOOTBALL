import collections,json
from pathlib import Path
p=Path('work/t68-a');a=Path('/workspace/work/football-t68/work/t68-a/fixed-archive');b=p/'post-head-archive'
m=json.loads((b/'feed_manifest.json').read_bytes());output={}
for table in ['matches','results']:
 cols=m['columns'][table]
 def load(root):
  return {v[0]:dict(zip(cols,v)) for line in (root/f'state/{table}.jsonl').read_bytes().splitlines() for v in [json.loads(line)]}
 old,new=load(a),load(b); changes=[]
 for key in sorted(old.keys()|new.keys()):
  if old.get(key)!=new.get(key):
   changes.append(dict(id=key,changed_fields={c:dict(old=old.get(key,{}).get(c),new=new.get(key,{}).get(c)) for c in cols if old.get(key,{}).get(c)!=new.get(key,{}).get(c)},new_row=key not in old,removed_row=key not in new))
 output[table]=dict(old_rows=len(old),new_rows=len(new),changed_rows=len(changes),field_counts=collections.Counter(c for row in changes for c in row['changed_fields']),rows=changes)
(p/'post-head-core-diff.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:{f:v for f,v in t.items() if f!='rows'} for k,t in output.items()},ensure_ascii=False))
