"""Verify offline evidence after the final product freeze, without accuracy claims."""
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from datetime import UTC, datetime
from pathlib import Path
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
BASE = Path('/workspace/work/football-t68/work/t68-a')


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


subprocess.run(['/workspace/work/t48-venv/bin/python', str(HERE/'final_source_freeze.py'), 'check'], check=True)
root = ET.parse(HERE/'a-rest-pytest.xml').getroot()
suites = list(root.iter('testsuite'))
tests = {key: sum(int(s.get(key, 0)) for s in suites) for key in ('tests','failures','errors','skipped')}
tests['seconds'] = sum(float(s.get('time', 0)) for s in suites)
assert tests['tests'] >= 4321 and not any(tests[key] for key in ('failures','errors','skipped'))
assert 'All checks passed!' in (HERE/'a-rest-ruff.log').read_text()
assert 'already formatted' in (HERE/'a-rest-format.log').read_text()
for name in ('a-rest-immutable-validation.json','a-rest-gate-final-comparison.json'):
    assert read(HERE/name)['status'] == 'passed', name
roundtrip = read(HERE/'a-rest-roundtrip-final/summary.json')
assert roundtrip['status'] == 'passed' and roundtrip['all_exported_content_hashes_equal']
model = read(BASE/'model-regression-comparison.json')
restored = read(BASE/'model-regression-restored-comparison.json')
assert model['status'] == restored['status'] == 'passed'
snapshot = read(HERE/'model-code-snapshot.json')
used = read(BASE/'model-regression-current/summary.json')['loaded_project_modules']
used_after = read(BASE/'model-regression-restored/summary.json')['loaded_project_modules']
assert used == used_after and used
for name, expected in used.items():
    assert sha(REPO/name) == expected, ('Model used module changed after snapshot', name)
for name, expected in snapshot['files'].items():
    if name.startswith('data/'):
        assert sha(REPO/name) == expected, ('Model configuration/data changed',name)
unloaded_diffs = {name:dict(snapshot=expected, final=sha(REPO/name))
                  for name,expected in snapshot['files'].items()
                  if name.startswith('src/') and sha(REPO/name) != expected}
assert not (set(unloaded_diffs) & set(used))
assert '最新结论：内部代码复验通过，Critical / Important 未关闭项均为 0' in (HERE/'task-2-review.md').read_text()
for task in (3,4):
    assert (HERE/f'task-{task}-review.md').read_text().startswith('通过'), task
stage4 = read(HERE/'task-4-owned-freeze-5.json')
post_head = read(HERE/'post-head-validation.json')
assert post_head['strict'] == post_head['new'] == post_head['requests'] == post_head['production_writes'] == 0
assert post_head['legacy_preserved'] == 138
assert post_head['queue_byte_identical'] and post_head['diagnostic_business_identical'] and post_head['reason_counts_identical']
for name in ('src/zucai/identity_binding.py','src/zucai/identity_binding_archive.py'):
    assert sha(REPO/name) == post_head['current_code_files'][name]
# The final Task4 review carries its own frozen-file inventory and independent logs;
# the whole product tree is separately guarded by a-rest-source-freeze.json above.
now = datetime.now(UTC)
result = dict(status='passed', observed_utc=now.isoformat(),
              observed_beijing=now.astimezone(ZoneInfo('Asia/Shanghai')).isoformat(),
              baseline_main='9d3d0540baa38ac183526d0ae7fbc7a053f43126',
              starting_main='13e968dd2725338b0451aac886d6834addb19921',
              task_amendment='f963cfe95db4c6104914cb967e445c1c87198b69',
              tests=tests, ruff_check=True, ruff_format=True,
              full_source_freeze_sha256=sha(HERE/'a-rest-source-freeze.json'),
              model_comparison_sha256=sha(BASE/'model-regression-comparison.json'),
              restored_comparison_sha256=sha(BASE/'model-regression-restored-comparison.json'),
              models=26, loaded_model_modules_equal_to_final=len(used),
              snapshot_difference_in_unloaded_modules=unloaded_diffs,
              model_config_data_equal_to_final=True,
              roundtrip_summary_sha256=sha(HERE/'a-rest-roundtrip-final/summary.json'),
              immutable_validation_sha256=sha(HERE/'a-rest-immutable-validation.json'),
              gate_validation_sha256=sha(HERE/'a-rest-gate-final-comparison.json'),
              post_head_validation_sha256=sha(HERE/'post-head-validation.json'),
              boundary='Offline code/behavior validation; no predictive validity, production publication, binding approval, daily permission or formal Claude approval claim')
(HERE/'a-rest-final-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
