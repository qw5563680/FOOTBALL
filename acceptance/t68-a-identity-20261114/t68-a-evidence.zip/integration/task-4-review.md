通过

Task4 fresh内部审查及全部限定复查通过，当前无未解决Critical / Important。I1/I2/I3以及PR139最新增补中的I4均已关闭，可进入父级最终整合。此结论不是Claude正式批准，也不是owner合并、正式绑定、daily开启或生产发布授权。

## 审查基线与范围

- HEAD：`13e968dd2725338b0451aac886d6834addb19921`；最新任务增补：PR139 `f963cfe95db4c6104914cb967e445c1c87198b69` 第五节2。
- 最终冻结：`task-4-owned-freeze-5.json`，SHA256 `42fbfb08f06b62df7fe9d4ec595988f360b8bea5872fa6704b867c4ae3c43b15`，26owned。复查前后26/26一致；freeze4原24个文件均未改变，本次仅新增拥有stats_batch产品改动和相应测试。
- 每轮先读产品差异、代码和实际调用链，再读实现方交接。reviewer只在work写探针/日志/报告，未改产品、正式数据或工作流，未commit/push/开PR、触发Actions、发体育HTTP/真实Release请求或使用正式key。
- 未重复全量pytest或26模型拟合。父级负责最终全量、模型、完整正式副本恢复和统一交付。

## Spec与quality结论

**Spec：本轮授权实现范围通过。** 专用预算异常、held/疑似重复/拒收分计、候选安全隔离、只读每日开启gate和回填collection独立命名空间符合已验证要求。PR139最新新增的回填状态分离覆盖三来源普通/catalogue入口、仅JC同步、日报顶部/异常区，以及实际晚班技术二次导出。缺证据不ready，历史partial不能污染每日状态；真实当前失败和pending仍partial。

**Quality：通过内部限定审查。** 独立失败均保留且随后用未改原探针验证修复；最终I4限定16项全过，26owned无漂移。前轮未变代码的独立63项、gate修复71项及回填分离63项通过证据继续适用。这里不以局部用例代替父级最终全量或模型验证。

## 分级发现与关闭证据

### Critical

无已确认项。

### Important

无未解决项。累计四条发现已关闭：

1. **I1：固定12月与近期30日窗口互斥。** `src/zucai/identity_daily_gate.py:229` 的 `_recent_official` 独立核验近期JC原件，`:425` 核验重放官方ID集合。独立充分月中assess在统一截止 `2026-11-14T10:43:21.807840+00:00` 达到ready_for_review；固定窗口仍止10月31日，近期新增合成 `jc:21/apif:11` 只计入近期分母。缺官方日、缺第二页、错日、官方身份冲突、遗漏官方ID、缺UTC边界日、sidecar SHA错七项均insufficient。原API-only探针没有近期官方分母，因此仍不得通过，失败原件保留；没有删校验来变绿。

2. **I2：此前held被current_ids交集静默丢弃。** `identity_daily_gate.py:168`–224 保留此前ID；只凭匹配已验证原件ID/raw SHA的明确别季依据排除，不凭CSV年份猜测。原反例未改即通过。缺失 `apif:999` 仅有still_held说明时，`:667` 仍加 `current_season_held_unresolved` blocker，整体blocked、resolved_ids为空。

3. **I3：日报拒收数量缺失。** `src/zucai/daily_digest.py:221`–227 分别显示疑似重复、拒收、held；缺字段显示未记录。实际import产生1held+1rejected的原反例未改即通过。旧回填摘要缺failed_scopes兼容也已验证，真实lateJC计数未改变。三份T25 Markdown仅是离线golden更新，不是生产旧日报。

4. **I4：晚班stats二次导出恢复历史partial污染。** 最小修复位于 `src/zucai/stats_batch.py:9` 与`:429`：daily调用传 `status_collection=daily_collection(collection)`，非daily仍传None，完整collection归档不删。已核实际链路 `.github/workflows/football-feeds.yml:290`、`:299` → `cloud_stats.py:125` 的daily=True → 新调用参数。原review4实际collector探针未改通过：四每日来源complete、历史apif_backfill partial、stats complete、pending0、HTTP0，最终complete。新独立HTTP503、真实未解决赛果、未知旧partial三负边界仍partial；worker的真实解析/cursor错误、已有每日partial、非daily兼容也独立复跑通过。导出器默认行为、gate、身份和模型源码未改。

### Suggestion

无阻止整合的额外建议，不扩大到B段、训练或正式开关。

## PR139最新collection增补的覆盖

- 三来源APIF/FDORG/FD × 普通/catalogue × 成功/真实失败的实际CLI验证：写各自 `_backfill` 键，原每日记录逐值保留；当前操作摘要/状态、导出恢复正确。
- 失败回填后仅JC sync不采API：旧每日APIF行保留、历史回填保留；无真实异常时总complete。独立真实拒收场景pending=1、JC rejected_rows=1时仍partial。
- 只有明确operation=backfill/catalogue-backfill且source不矛盾的旧记录才迁移；未知operation、缺operation、矛盾source保留，不猜成功。三provider冲突记录均保留、迁移幂等；旧FD无source兼容。
- 日报完整generate顶部和异常区使用同一daily视图，输入归档bytes不变；Actions回填摘要、lateJC、probe、identity、relink、Task3回执和旧档恢复回归通过。
- 晚班stats最终导出已补齐，真实当前stats错误/pending不被过滤。非daily技术回填维持既有汇总语义。

## 独立实跑证据

| 阶段 | reviewer结果 | 证据 |
| --- | --- | --- |
| 初轮边界 | 63通过；I1/I2另2失败，I3另1失败 | task-4-review-targeted.xml、counterexamples/reporting-counterexample日志 |
| I1/I2/I3限定复查 | 71通过，0失败/error/skip，3.340s | task-4-review3-targeted.xml |
| 回填独立状态初查 | 63通过、I4独立1失败，0error/skip，7.681s | task-4-review4-targeted.xml |
| I4最终限定复查 | **16通过，0失败/error/skip，3.626s** | task-4-review5-targeted.log/.xml |

最终新独立负边界文件 `task-4-review5-negatives.py`；原I4探针 `task-4-review4-probes.py` 保持不变。全部HTTP由responses拦截，Release是本地测试替身，输入来自已检入fixtures。最终副本位于 `task-4-review5-targeted-artifacts/`。

`task-4-review5-freeze-before.json` / `task-4-review5-freeze-after.json` 记录26/26 SHA一致及原24未变。实现方270/0/0/0、78.083s和Ruff证据属于实现方交接，本reviewer没有冒称再跑。父级中止的全量integration3记录不是通过证据，最终全量由父级重新执行。

最终限定命令：

```sh
PYTHONPATH=src:tests /workspace/work/t48-venv/bin/python -m pytest -q \
  work/t68-a/task-4-review4-probes.py \
  work/t68-a/task-4-review5-negatives.py \
  tests/test_t68_stats_collection.py
```

历史审查报告不覆盖：`task-4-review-initial.md`、`task-4-review-initial-with-reporting.md`、`task-4-review-before-freeze4.md`、`task-4-review4-initial.md`。其中失败结果如实保留，当前结论以freeze5为准。

## 固定真实证据与限制

固定 `daily-gate-all62-review3-final.json` SHA=`c6203407ff18d7d492cad3ee6f97bd51c42a26bd1580255710643dadf8b62cb4`：62路线/1083场/32零场路线，全部insufficient，零分母率null。新routes没有正式current_season仍null，不取最大历史年。逐code官方分母独立计数由父级提供，reviewer仅独立核SHA/总数，不冒称重算全目录。

固定归档缺完整近期官方/API日期材料、当季重放和开启证据bundle；合成ready只证明程序路径，不是赛事已可开启。447项是200调用/447deferred的离线预算与历史解释，39有raw partial不变；不改旧日志。138旧候选只证明保留，普通日期raw为0份，不能称真实隔离回放。

## 固定四问

1. **冻结predictions/parameters/run_log？** Task4不写冻结预测、参数、评分、账本或生产旧日报。新Markdown是离线fixture；gate只写新报告；reviewer只写work。正式全归档不可变验收归父级。
2. **其他比赛匹配/路由/概率？** 正式registry、来源、params、API key和B泛称实现未改。held仍不入库，候选变化只限此前被其他赛事坏行连带阻断的情况；真实日期raw缺失不能穷举新增候选。最新collection与stats调用修复不改任何比赛ID/球队/比分/训练输入；模型结论由父级26模型对照。
3. **赛前可知性？** 未放宽available_utc或训练来源规则。历史身份/gate证据是赛后离线验收，不声称当时赛前可见；回填/每日报告分类不改变训练可知性。
4. **覆盖与缺口？** 原四条独立失败均复测关闭；预算、候选、held、gate完整/缺证据、全部回填入口、日报、仅JC同步、真正pending及晚班二次导出已有相应证据。剩余为父级最终全量/模型/正式规模恢复，以及审查者真实当季/30日材料和正式开启后三次链路；不能用离线fixture替代。

可以继续父级最终整合。`ready_for_review`始终仅表示可提交审查，本报告不授予正式批准或发布权限。
