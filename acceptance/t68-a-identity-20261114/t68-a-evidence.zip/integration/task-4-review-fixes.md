# Task4 独立复查后的修复交接

本阶段在父级保存 `a-rest-integration-1-*`（4305 tests，1 fail，源码运行前后相同）并明确 GO 后实施。原 `task-4-owned-freeze-2.json`、`task-4-report.md`、首轮测试/反例日志均保留；最终以 `task-4-owned-freeze-3.json` 与本交接为增补。

## I1：固定12月窗口与最近30日窗口冲突

保留 `catalogue_window` 的12个完整北京时间月，不改旧官方分母。新增 `recent_replay.official_originals`，是一组相对 evidence bundle 目录的 `{path,sha256}`，读取对应 `.meta.json`。只补充已归档的近期官方原件，不采集。

`_recent_official` 复用 `cloud_jc_catalogue._archived_page`、`parse_day_pages` 和官方字典解析，检查来源URL、日/页参数、HTTP、raw SHA、完整页数、重复比赛、字典冲突和正整数球队ID。12月窗口内已验证日期可复用；缺失的新日期必须有完整补页。补页覆盖旧窗口时按比赛ID及双方官方队ID核对，不能替换旧目录。实际 `build_register` 还用固定官方字典核对赛事身份。

`recent_replay.results` 增加必需 `official_match_ids`，须等于实际近期官方分母。返回证据新增 `official_match_ids` 和独立 `official_window`，后者含 `start_beijing/end_beijing/official_match_ids/official_team_ids/covered_beijing_dates/supplement_originals`，各补页保存 raw/sidecar SHA。无新CLI选项，继续走既有 `--evidence`。

11月14日整体 `assess_league` 正向fixture现在通过：12月窗口仍止于10月31日，11月1日至13日的已归档官方补页独立覆盖近期窗口，结果仅 `ready_for_review`。另覆盖近期真实新场次计入近期分母、不扩写12月分母；缺日、坏sidecar SHA、错日、部分分页、缺球队ID、重放遗漏近期官方场次均拒绝。

原 review 的 I1 探针只有API日原件，没有11月官方补页，仍应因为官方分母欠证据而拒绝；不能删官方分母要求来让这个不完整输入通过。新完整正向fixture补足了必要官方证据。

## I2：此前held集合被current_ids交集静默缩减

先完整收集相关赛事的此前held ID，`held_before` 不因当前原件缺ID而减少。CSV的season/date字段不是独立scope证明；只有冻结已验证APIF原件中同fixture ID、同raw SHA的明确别季证据可以单列排除，并拒绝与当季原件/CSV声明冲突的scope。没有league/competition归属信息时拒绝，不假定不相关。

返回字段新增 `held_before_ids/excluded_other_season_ids/explained_unresolved`；`resolved_ids` 仅含实际已存入或关联的相关ID。`apif:999` 在当前原件之外、既未存入/关联又无说明时直接失败；标2026、标2025、缺season均不能凭提示消失。

可选 `current_season_replay.held_explanations` 引用逐ID JSON：`fixture_id/reason/disposition/evidence`，其中 disposition 只接受 `still_held`，evidence 继续核验 `{path,sha256}`。这仅保留解释，不算已解决；整体门槛加 `current_season_held_unresolved` blocker，不能 ready。重复解释或解释无关ID拒绝。

## I3 与整合摘要兼容

- `daily_digest` 独立显示“单行拒收 N”，与“疑似重复 N”“未绑定暂缓 N”并列。沿 `_text` 处理旧字段缺失为“未记录”，没有填造0。真实1 held + 1 rejected的reviewer反例通过。
- `cloud_api_backfill.write_summary` 对旧报告缺 `failed_scopes` 用 `.get(..., [])`，和held/deferred保持兼容。原lateJC实际计数断言未变；加新摘要默认0文案断言。
- 日报3份旧golden fixture的collection原本不含 `rejected_rows`，只在 `data/fixtures/t25/expected_{partial,gates,empty}.md` 增加“单行拒收 未记录”。没有修改真实旧日报/账本/预测。

## 验证记录

- 修前独立重现摘要KeyError：`task-4-review-summary-red.log`。
- gate、日报拒收、held scope/冲突红测：`task-4-review-gate-red.log`、`task-4-review-digest-red.log`、`task-4-review-held-conflict-red.log`、`task-4-review-held-scope-red.log`。
- `task-4-review-final-pytest.xml`：69 tests通过，含原reviewer I2和I3反例；两份原反例文件均未修改。
- `task-4-final4-pytest.xml`：403 tests中3份golden因新增必需列而失败（400通过），故更新上述离线预期；没有把此轮算通过。
- 最终 `task-4-final5-pytest.log/.xml`：**404 tests，0 failures/errors/skipped，24.37s**。`task-4-ruff-check-4.log` 与 `task-4-ruff-format-check-4.log`：通过，16 Python文件格式符合。
- 固定62赛事修后新产物：`task-4-fixed-evidence/daily-gate-all62-review3-final.json`，仍无近期官方/API补件、current_season/重放恢复材料，仍须全部 `insufficient_evidence`；独立12月分母仍为1083场、32项零场且率null。其哈希与逐code独立对照随freeze-3保存。

除gate、Task4两处文本报告及其测试/离线golden外，本阶段未改产品代码；保留A2/A3防护，未新增体育HTTP、生产改动、正式配置或开关，未提交推送。父级统一全量检查、模型拟合、最终恢复、文档和发布。
