"""Prepare an immutable standalone evidence ref; do not push or edit production data."""
import hashlib
import json
import subprocess
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
OUT = HERE / 'published-a-rest'
BRANCH = 'data/t68-a-identity-acceptance-20261114'
PART = 't68-a-identity-20261114'
RELATIVE = 'acceptance/' + PART


def git(*args, content=None):
    return subprocess.check_output(['git', *args], cwd=REPO, input=content).decode().strip()


assert subprocess.run(['git', 'show-ref', '--verify', '--quiet', 'refs/heads/' + BRANCH], cwd=REPO).returncode == 1
summary = json.loads((HERE / 'a-rest-final-validation.json').read_text())
assert summary['status'] == 'passed'
package = json.loads((HERE / 'evidence-package.json').read_text())
assert hashlib.sha256((OUT / package['file']).read_bytes()).hexdigest() == package['sha256']
entries = []
for name in ('README.md', 'SHA256SUMS', package['file']):
    blob = git('hash-object', '-w', '--stdin', content=(OUT / name).read_bytes())
    entries.append(f'100644 blob {blob}\t{name}\n')
artifact_tree = git('mktree', content=''.join(entries).encode())
acceptance_tree = git('mktree', content=f'040000 tree {artifact_tree}\t{PART}\n'.encode())
tree = git('mktree', content=f'040000 tree {acceptance_tree}\tacceptance\n'.encode())
commit = git('commit-tree', tree, content=b'T68: preserve offline identity, quarantine and collection acceptance evidence\n')
git('update-ref', 'refs/heads/' + BRANCH, commit, '0' * 40)
result = dict(branch=BRANCH, commit=commit, path=RELATIVE,
              url=f'https://github.com/qw5563680/FOOTBALL/tree/{commit}/{RELATIVE}',
              zip_url=f'https://github.com/qw5563680/FOOTBALL/blob/{commit}/{RELATIVE}/' + package['file'],
              zip_sha256=package['sha256'])
(HERE / 'evidence-ref.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False))
