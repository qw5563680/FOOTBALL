"""Daily output must expose all three independently counted import dispositions."""
import pytest
import responses

from test_apif_ingest import db as db, game, ingest, seed
from zucai.db import session_scope
from zucai.models import Result
from zucai.cloud_apis import _record
from zucai.daily_digest import _anomaly_sections


@pytest.fixture(autouse=True)
def offline_only():
    with responses.RequestsMock():
        yield


def test_daily_displays_rejected_and_held_counts_from_actual_import(db):
    with session_scope(db) as session:
        seed(session, "jc:held")
        score = session.get(Result, "jc:held")
        score.home_goals, score.away_goals = 2, 1
        imported = ingest(session, game(), game(provider_match_id=99999, full=(-1, 1)), mapping={})
    assert imported["held_unbound"] == imported["rejected_rows"] == 1
    assert imported["suspected_duplicates"] == 0
    report = dict(status="complete", errors=[])
    _record(report, imported)
    output = "\n".join(_anomaly_sections({"collection": {"apif": report}}, {}, {}, "example/repo"))
    assert "未绑定暂缓 1" in output
    assert "疑似重复 0" in output
    assert "拒绝 1" in output or "拒收 1" in output
