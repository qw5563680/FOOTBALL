"""Verify fixed inputs and unchanged protected configuration after offline integration."""
import hashlib
import json
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
BASE = Path('/workspace/work/football-t68/work/t68-a')
ARCHIVE = BASE / 'fixed-archive'
DATA = 'e370db1d5cabe1cb33ddbfff3029c6d802bb8992'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


initial = json.loads((BASE / 'fixed-inputs.json').read_text())
supplement = json.loads((BASE / 'fixed-inputs-candidate-supplement.json').read_text())
files = {**initial['files'], **supplement}
assert len(files) == 2308
for name, item in files.items():
    assert sha(ARCHIVE / name) == item['sha256'], name
    assert (ARCHIVE / name).stat().st_size == item['bytes'], name
protected = json.loads((BASE / 'a-rest-protected-before.json').read_text())
for row in protected['protected_configuration']:
    assert sha(REPO / row['path']) == row['sha256'], row['path']
assert sha(BASE / 'model-fixture/data/zucai.db') == protected['database_sha256']
saved = json.loads((BASE / 'frozen-git-objects-before.json').read_text())
raw = subprocess.check_output(['git', 'ls-tree', '-rz', DATA], cwd=REPO)
current = {}
for item in raw.split(b'\0'):
    if not item:
        continue
    meta, _, name = item.partition(b'\t')
    current[name.decode()] = meta.decode().split()[2]
assert all(current[name] == value for name, value in saved.items())
registry = json.loads((REPO / 'data/identity_reviews/t68-cross-day.json').read_text())
assert registry == {'schema_version': 1, 'decisions': []}, 'No real crossday decisions authorized here'
now = datetime.now(UTC)
result = dict(status='passed', source_commit=DATA, fixed_input_files=len(files), original_input_files=2305,
              candidate_supplement_files=3, protected_configuration=protected['protected_configuration'],
              source_database_sha256=protected['database_sha256'], frozen_git_objects=len(saved),
              fixed_frozen_object_hashes_equal=True, live_sports_requests=0, production_writes=0,
              observed_utc=now.isoformat(), observed_beijing=now.astimezone(ZoneInfo('Asia/Shanghai')).isoformat(),
              boundary='Fixed archive objects and local read-only inputs; no production data publication')
(HERE / 'a-rest-immutable-validation.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False))
