"""Finalize the separate post-head read-only replay evidence."""
import collections,gzip,hashlib,json
from datetime import datetime,timezone
from pathlib import Path
from zucai.identity_binding import _utc
p=Path('work/t68-a');first=p/'post-head-replay-1';second=p/'post-head-replay-2';root=p/'post-head-archive'
def read(path):return json.loads(path.read_bytes())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def business(path):
 return sorted((league,key,e['candidate_id'],e['canonical'],e['evidence_status'],e['layer'],tuple(e.get('depends_on',[]))) for league,entries in read(path)['apif'].items() for key,e in entries.items())
a,b=read(first/'summary.json'),read(second/'summary.json')
assert (first/'apif.json').read_bytes()==(second/'apif.json').read_bytes()==(root/'state/alias_candidates/apif.json').read_bytes()
for name in ['diagnostic_matches.json','new_competition_diagnostic.json']:
 assert business(first/name)==business(second/name)
assert read(first/'diagnostic_known_answers.json')==read(second/'diagnostic_known_answers.json')
assert a['unverified_reasons']==b['unverified_reasons']
old=read(p/'task-2-verified-replay/summary.json')
reasons={r:dict(old_e370=old['unverified_reasons'].get(r,0),post_head=a['unverified_reasons'].get(r,0)) for r in sorted(old['unverified_reasons'].keys()|a['unverified_reasons'].keys()) if old['unverified_reasons'].get(r,0)!=a['unverified_reasons'].get(r,0)}
(p/'post-head-reason-differences.json').write_text(json.dumps(reasons,ensure_ascii=False,indent=2)+'\n')
contract=read(p/'post-head-contract-summary.json');official={r['match_id']:r for r in contract['official_contracts']}
registry=read(Path('data/league_map.json'));examples=[]
for item in contract['provider_10184']['rows']:
 row=item['row'];side='home' if row['home']=='10184' else 'away'
 for neighbor in item['neighbors']:
  if _utc(neighbor['kickoff_utc'])!=_utc(row['kickoff_utc']) or neighbor['score']!=row['score']:continue
  if neighbor[side+'_source_id'] not in ['2277','2071']:continue
  category_records=[dict(pointer=f'/competitions/{i}',master_name=c['master_name'],master_fields=c['master_fields'],mappings=c['mappings']) for i,c in enumerate(registry['competitions']) if any(m['provider']=='apif' and m['code']==row['competition_id'] for m in c['mappings'])]
  examples.append(dict(apif=row,jc=dict(official[neighbor['match_id']],score=neighbor['score']),apif_id_side=side,
                       jc_id=neighbor[side+'_source_id'],pair_check_reasons=neighbor['reasons'],category_evidence=dict(registry_path='data/league_map.json',registry_sha256=sha(Path('data/league_map.json')),records=category_records,explicit_source_category=row.get(side+'_category'),explicit_target_category=None,name_veto_token=row.get(side+'_name'),unknown_is_not_approval=True),
                       not_an_approved_association=True))
conflict=dict(provider_team_id='10184',official_team_ids=['2277','2071'],examples=examples,
             actual_strict_proposal=False,diagnostic_entry=read(first/'new_competition_diagnostic.json')['apif'].get('亚运男足',{}).get('10184'),
             limitation='Unknown JC 2277 has no canonical target, so current diagnostic graph does not represent it as a conflicting canonical owner; strict proposal remains blocked. Do not approve the surviving partial diagnostic.',
             future_known_target_check=read(p/'post-head-future-target-check.json'))
(p/'post-head-conflict-10184.json').write_text(json.dumps(conflict,ensure_ascii=False,indent=2)+'\n')
inputs=read(p/'post-head-input-manifest.json')
assert all(sha(root/r['path'])==r['sha256'] for r in inputs['files'])
aux=read(p/'post-head-auxiliary-input-manifest.json')
assert all(sha(Path(r['path']))==r['sha256'] for r in aux['files'])
assert all(sha(Path(name))==digest for name,digest in aux['current_code_files'].items())
validation=dict(observed_utc=datetime.now(timezone.utc).isoformat(),archive_commit=inputs['commit'],manifest_sha256=inputs['manifest_sha256'],
                current_code_files=aux['current_code_files'],code_unchanged_since_pre_replay_task_freezes=True,
                known_integrated_source_changes=aux['known_integrated_source_changes'],task4_pre_replay_proof=aux['task4_pre_replay_proof'],
                inputs_reverified=len(inputs['files']),auxiliary_inputs_reverified=len(aux['files']),
                first_observed_utc=a['observed_utc'],second_observed_utc=b['observed_utc'],
                known_answer=read(first/'diagnostic_known_answers.json'),
                strict=a['strict_verified'],new=a['new_candidates'],legacy_preserved=a['legacy_preserved'],new_competition_diagnostic=a['new_competition_diagnostic_count'],
                queue_sha256=sha(first/'apif.json'),queue_byte_identical=True,diagnostic_business_identical=True,reason_counts_identical=True,
                same_business_diagnostics_as_e370=business(first/'new_competition_diagnostic.json')==business(p/'task-2-verified-replay/new_competition_diagnostic.json'),
                reason_differences=reasons,new_head_contract_checks=contract['new_head_contract_checks'],requests=0,production_writes=0,
                first_output_hashes={f.name:sha(f) for f in first.iterdir() if f.is_file()},second_output_hashes={f.name:sha(f) for f in second.iterdir() if f.is_file()})
# First preserve final JSON hashes, then make an equivalent compressed duplicate output.
large=second/'unverified.json';raw=large.read_bytes();blob=gzip.compress(raw,compresslevel=6,mtime=0);z=large.with_suffix('.json.gz');z.write_bytes(blob)
assert gzip.decompress(z.read_bytes())==raw
validation['second_unverified_compression']=dict(original_sha256=hashlib.sha256(raw).hexdigest(),original_bytes=len(raw),compressed_path=str(z),compressed_sha256=sha(z),compressed_bytes=len(blob),round_trip_equal=True)
(p/'post-head-validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
large.unlink()
print(json.dumps({k:validation[k] for k in ['observed_utc','strict','new','legacy_preserved','new_competition_diagnostic','inputs_reverified','queue_byte_identical','same_business_diagnostics_as_e370']},ensure_ascii=False))
