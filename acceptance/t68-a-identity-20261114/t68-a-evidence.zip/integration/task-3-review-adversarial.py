"""Independent internal-review counterexamples; synthetic changes to fixture-only DBs."""
import json
import sqlite3
import sys
from pathlib import Path

import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tests"))
import test_t68_cross_day as h

from zucai.db import session_scope
from zucai.models import Match, Result
from zucai.predict.pooled import select_training_history
from zucai.result_source_links import record_result_link
from zucai.source_results_audit import audit_source_results

db = h.db


def test_invalid_old_component_releases_paid_row_without_reliable_result(db):
    with session_scope(db) as s:
        paid = s.get(Match, h.API)
        paid.league = "英超"
        second = h.clone(s, h.API, "fdorg:review-paid")
        from zucai.models import Team
        for key in (paid.home_team_id, paid.away_team_id):
            team = s.get(Team, key)
            team.aliases = [*team.aliases, f"apif:英超:team:{key}", f"fdorg:英超:team:{key}"]
        h.refresh_identity(s, h.API)
        h.refresh_identity(s, second.match_id)
        jc = h.clone(s, h.API, "jc:review-anchor", result=False)
        fd = h.clone(s, h.API, "fd:review-anchor", result=False)
        rival = h.clone(s, h.API, "jc:review-rival", result=False)
        jc.counterpart_id = fd.match_id
        rival.counterpart_id = fd.match_id
        rival.home_team_id, rival.away_team_id = rival.away_team_id, rival.home_team_id
        s.flush()
        record_result_link(s, paid, jc, h.KNOWN.to_pydatetime())
        record_result_link(s, second, fd, h.KNOWN.to_pydatetime())
        try:
            selected = select_training_history(h.history(s, "英超", "apif,fdorg"), h.CUTOFF)
        except ValueError:
            return
        assert selected.empty, list(selected.match_id)


@pytest.mark.parametrize("bad", ["reversed_claim", "outside_window_claim", "broken_outgoing"])
def test_conflicting_unselected_old_anchor_cannot_prove_component(db, bad):
    with session_scope(db) as s:
        old = s.get(Match, h.FD)
        old.kickoff_utc = s.get(Match, h.API).kickoff_utc
        s.get(Result, h.FD).available_utc = h.KNOWN.isoformat()
        anchor = h.clone(s, h.API, "jc:review-anchor", result=False)
        anchor.counterpart_id = h.FD
        if bad == "broken_outgoing":
            old.counterpart_id = "jc:missing-review-target"
        else:
            rival = h.clone(s, h.API, "jc:review-rival", result=False)
            rival.counterpart_id = h.FD
            if bad == "reversed_claim":
                rival.home_team_id, rival.away_team_id = rival.away_team_id, rival.home_team_id
            else:
                rival.kickoff_utc = (pd.Timestamp(anchor.kickoff_utc) + pd.Timedelta(days=10)).isoformat()
        s.flush()
        record_result_link(s, s.get(Match, h.API), anchor, h.KNOWN.to_pydatetime())
        try:
            selected = select_training_history(h.history(s, sources="fd,apif"), h.CUTOFF)
        except ValueError:
            return  # Rejecting an internally conflicting component is also fail-closed.
        assert any(row["match_id"] == h.API for row in selected.attrs["unverified_fd_identity_overlaps"]), (
            "Invalid old pointer claims were silently dropped, and APIF/FD was exempted via the surviving JC anchor."
        )


def test_consistent_score_cannot_hide_broken_third_pointer(tmp_path):
    import csv
    from test_t63_source_audit import database
    path = database(tmp_path, "consistent")
    with sqlite3.connect(path) as conn:
        conn.execute("UPDATE matches SET counterpart_id='jc:review-missing' WHERE source='fd'")
    target = tmp_path / "review-audit.csv"
    report = audit_source_results(path, target)
    rows = list(csv.DictReader(target.open()))
    assert any("counterpart_missing" in row["risk_reasons"] for row in rows), report


@pytest.mark.parametrize("delay", [0, 1])
def test_future_bridge_cutoff_is_strict(db, delay):
    with session_scope(db) as s:
        old = s.get(Match, h.FD)
        old.kickoff_utc = s.get(Match, h.API).kickoff_utc
        s.get(Result, h.FD).available_utc = h.KNOWN.isoformat()
        anchor = h.clone(s, h.API, "jc:review-future-anchor", result=False)
        anchor.counterpart_id = h.FD
        s.flush()
        record_result_link(s, s.get(Match, h.API), anchor, h.CUTOFF.to_pydatetime())
        selected = select_training_history(h.history(s, sources="fd,apif"), h.CUTOFF + pd.Timedelta(seconds=delay))
        held = any(row["match_id"] == h.API for row in selected.attrs["unverified_fd_identity_overlaps"])
        assert held == (delay == 0)


@pytest.mark.parametrize("field", ["league", "kickoff_utc", "result_checked_utc", "available_source"])
def test_full_pair_snapshot_changes_revoke_decision(db, tmp_path, monkeypatch, field):
    module, registry, _ = h.approval(db, tmp_path, monkeypatch)
    module.apply_decisions(db.url.database, registry)
    with session_scope(db) as s:
        if field == "available_source":
            s.get(Result, h.FD).available_source = "captured"
        else:
            row = s.get(Match, h.FD)
            values = dict(source="jc", league="日职", kickoff_utc="2021-04-24T23:00:00Z", result_checked_utc="2026-11-14T10:00:00Z")
            setattr(row, field, values[field])
        s.flush()
        assert module.load_decisions(s) == []


@pytest.mark.parametrize("drift", ["team_name", "identity_time", "dated_link", "future_dated_link"])
def test_additional_proof_drift_revokes_exact_decision(db, tmp_path, monkeypatch, drift):
    from sqlalchemy import select
    from zucai.models import ResultSourceIdentity, Team
    module, registry, _ = h.approval(db, tmp_path, monkeypatch)
    module.apply_decisions(db.url.database, registry)
    with session_scope(db) as s:
        if drift == "team_name":
            s.get(Team, s.get(Match, h.API).home_team_id).name += " review-drift"
        elif drift == "identity_time":
            proof = s.scalar(select(ResultSourceIdentity).where(ResultSourceIdentity.match_id == h.API))
            proof.verified_utc = "2026-11-14T08:00:00.000000Z"
        else:
            anchor = h.clone(s, h.API, "jc:review-new-evidence", result=False)
            when = pd.Timestamp("2099-01-01T00:00:00Z") if drift == "future_dated_link" else h.KNOWN
            record_result_link(s, s.get(Match, h.API), anchor, when.to_pydatetime())
        s.flush()
        assert module.load_decisions(s) == []


@pytest.mark.parametrize("bad", ["future_observation", "receipt_original_tamper"])
def test_future_or_tampered_evidence_does_not_authorize(db, tmp_path, monkeypatch, bad):
    module, registry, document = h.approval(db, tmp_path, monkeypatch)
    if bad == "future_observation":
        document["decisions"][0]["evidence"][0]["observed_utc"] = "2099-01-01T00:00:00Z"
        registry.write_text(json.dumps(document))
        with pytest.raises(ValueError):
            module.apply_decisions(db.url.database, registry)
    else:
        module.apply_decisions(db.url.database, registry)
        path = Path(db.url.database).parent / module.RECEIPT_FILE
        receipt = json.loads(path.read_text())
        receipt["receipts"][0]["evidence_base64"][0] = "dGFtcGVyZWQ="
        path.write_text(json.dumps(receipt))
        with session_scope(db) as s, pytest.raises(ValueError):
            module.load_decisions(s)
