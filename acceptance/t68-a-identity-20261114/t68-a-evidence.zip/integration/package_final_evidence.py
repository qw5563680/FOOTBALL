"""Package fixed, offline T68 A evidence; exclude credentials and test databases."""
import hashlib
import json
import zipfile
from datetime import UTC, datetime
from pathlib import Path
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
BASE = Path('/workspace/work/football-t68/work/t68-a')
OUT = HERE / 'published-a-rest'
ARCHIVE = OUT / 't68-a-evidence.zip'
files = {}


def add(path, relative):
    if path.is_file():
        assert relative not in files, relative
        files[relative] = path


# Deliberately include stage review failures, not just passing logs. Temporary
# DBs and raw/secret-bearing runtime directories are not selected.
allowed = {'.json', '.jsonl', '.csv', '.xml', '.md', '.py', '.txt', '.patch', '.log', '.npz', '.gz'}
for path in sorted(HERE.iterdir()):
    if path.is_file() and path.suffix in allowed and path.name != 'evidence-ref.json':
        add(path, 'integration/' + path.name)
for name in ('task-2-verified-evidence', 'task-2-verified-replay', 'task-2-verified-repeat',
             'task-2-final-replay', 'task-2-repeat-replay', 'task-2-post-review-replay',
             'task-4-fixed-evidence', 'post-head-replay-1', 'post-head-replay-2'):
    root = HERE / name
    if root.is_dir():
        for path in sorted(root.rglob('*')):
            if path.suffix in allowed:
                add(path, 'integration/' + str(path.relative_to(HERE)))
for folder in ('a-rest-roundtrip', 'a-rest-roundtrip-final'):
    add(HERE / folder / 'summary.json', 'integration/' + folder + '/summary.json')
for name in ('fixed-inputs.json', 'fixed-inputs-candidate-supplement.json',
             'model-fixture-inputs.json', 'build_model_fixture.py',
             'model_regression.py', 'model_regression_baseline_script.py',
             'compare_model_regression.py', 'compare_restored_regression.py',
             'model-regression-comparison.json', 'model-regression-restored-comparison.json',
             'model-current.log', 'model-restored.log', 'model-comparison.log', 'model-restored-comparison.log',
             'same-ids-crossday-baseline.json', 'source-audit-baseline.json', 'source-audit-baseline.csv',
             'frozen-git-objects-before.json', 'request-budget-447-baseline.json',
             'a-rest-protected-before.json', 'unbound-raw-inventory.json',
             'unbound-all-inventory.json', 'unbound-earlier-inventory.json',
             'unbound-eight-db-comparison.json', 'unbound-crossday-candidates.json',
             'unbound-crossday-review-enumeration.json', 'crossday-real12-clipped.json'):
    add(BASE / name, 'fixed-baseline/' + name)
for name in ('model-regression-baseline', 'model-regression-current', 'model-regression-restored'):
    assert (BASE / name / 'summary.json').exists(), name
    for path in sorted((BASE / name).iterdir()):
        if path.suffix in allowed:
            add(path, 'fixed-baseline/' + name + '/' + path.name)
for required in ('integration/a-rest-final-validation.json',
                 'integration/a-rest-roundtrip-final/summary.json',
                 'integration/a-rest-immutable-validation.json',
                 'fixed-baseline/model-regression-comparison.json',
                 'fixed-baseline/model-regression-restored-comparison.json'):
    assert required in files, required

OUT.mkdir(exist_ok=False)
manifest = {}
with zipfile.ZipFile(ARCHIVE, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for relative, path in sorted(files.items()):
        content = path.read_bytes()
        manifest[relative] = dict(bytes=len(content), sha256=hashlib.sha256(content).hexdigest())
        archive.writestr(relative, content)
    archive.writestr('FILE-MANIFEST.json', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    archive.writestr('SHA256SUMS', ''.join(f"{item['sha256']}  {name}\n" for name, item in sorted(manifest.items())))
with zipfile.ZipFile(ARCHIVE) as archive:
    assert archive.testzip() is None
    assert all(hashlib.sha256(archive.read(name)).hexdigest() == item['sha256'] for name, item in manifest.items())
sha = hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()
now = datetime.now(UTC)
result = dict(file=ARCHIVE.name, bytes=ARCHIVE.stat().st_size, sha256=sha, evidence_files=len(manifest),
              observed_utc=now.isoformat(), observed_beijing=now.astimezone(ZoneInfo('Asia/Shanghai')).isoformat(),
              verified_every_member=True, production_data_written=False)
(OUT / 'SHA256SUMS').write_text(f'{sha}  {ARCHIVE.name}\n')
(HERE / 'evidence-package.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False))
