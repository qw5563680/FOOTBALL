"""Fresh review3 gate proofs, generated only from checked-in fixtures."""
import json
from copy import deepcopy
from datetime import UTC, date, datetime, timedelta
from hashlib import sha256
from pathlib import Path
from urllib.parse import urlencode

import pytest
import responses

from zucai.identity_daily_gate import assess_league
from zucai.sources.base import RawStore
from zucai.sources.results import API as JC_API

ROOT = Path(__file__).resolve().parents[2]
CUTOFF = "2026-11-14T10:43:21.807840+00:00"


@pytest.fixture(autouse=True)
def offline_only():
    with responses.RequestsMock():
        yield


def save(root, name, value):
    path = root / name
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(value).encode()
    path.write_bytes(raw)
    return dict(path=name, sha256=sha256(raw).hexdigest())


def original(root, provider, raw, url):
    path = RawStore(root).save(provider, "review3", raw, "json", status_code=200, url=url,
                              captured_at=datetime(2026, 11, 14, 9, tzinfo=UTC))
    return dict(path=path.relative_to(root).as_posix(), sha256=sha256(raw).hexdigest())


@pytest.fixture
def complete_bundle(tmp_path):
    facts = json.loads((ROOT / "data/fixtures/t68/daily_gate/facts.json").read_bytes())
    facts["official_leagues"] = {"307": [dict(league_id=77, league_name="测试联赛全名", league_abbr="测试联赛")]}
    facts["matches"].append(dict(facts["matches"][0], match_id="jc:21", counterpart_id="apif:11"))
    facts["apif"].append(dict(facts["apif"][0], match_id="apif:11", kickoff_utc="2026-11-05T12:00:00Z"))
    api_template = json.loads((ROOT / "data/fixtures/t14/apif.json").read_bytes())
    api_refs = []
    for offset in range(31):
        day = date(2026, 10, 14) + timedelta(days=offset)
        doc = deepcopy(api_template)
        doc["parameters"] = {"date": day.isoformat()}
        if day in (date(2026, 10, 20), date(2026, 11, 5)):
            row = doc["response"][0]
            when = datetime.combine(day, datetime.min.time(), UTC) + timedelta(hours=12)
            row["league"].update(id=307, season=2026)
            row["fixture"].update(id=10 if day.month == 10 else 11, date=when.isoformat(), timestamp=int(when.timestamp()))
            row["teams"]["home"]["id"], row["teams"]["away"]["id"] = 10, 11
        else:
            doc.update(results=0, response=[])
        api_refs.append(original(tmp_path, "api-football", json.dumps(doc).encode(),
                                 "https://v3.football.api-sports.io/fixtures?date=" + day.isoformat()))
    jc_template = json.loads((ROOT / "data/fixtures/t61/jc-empty.json").read_bytes())
    jc_row = json.loads((ROOT / "data/fixtures/t65/jc-one-result-real.json").read_bytes())["value"]["matchResult"][0]
    jc_refs = []
    for day_number in range(1, 14):
        day = date(2026, 11, day_number)
        doc = deepcopy(jc_template)
        doc["value"]["leagueList"] = [dict(leagueId=77, leagueAllName="测试联赛全名", leagueAbbName="测试联赛")]
        if day_number == 5:
            row = dict(jc_row, matchDate=day.isoformat(), matchId=21, leagueId=77,
                       leagueName="测试联赛全名", leagueNameAbbr="测试联赛", homeTeamId=501, awayTeamId=502)
            doc["value"].update(matchResult=[row], total=1, pages=1)
        query = dict(matchBeginDate=day.isoformat(), matchEndDate=day.isoformat(), leagueId="",
                     pageSize=30, pageNo=1, isFix=0, matchPage=1, pcOrWap=1)
        jc_refs.append(original(tmp_path, "jc-results", json.dumps(doc).encode(),
                                JC_API + "getUniformMatchResultV1.qry?" + urlencode(query)))
    held_raw = b"raw_sha256,competition_code,league,provider_match_id\n"
    (tmp_path / "held.csv").write_bytes(held_raw)
    current = save(tmp_path, "current.json", dict(processed_files=1, scopes=[dict(
        code="307", season=2026, status="complete", parsed_matches=2, raw={"sha256": "a" * 64},
        held_unbound=0, suspected_duplicates=0, rejected_rows=0)]))
    repeat = save(tmp_path, "repeat.json", dict(inserted=0, status="complete", processed_files=1, scopes=[dict(code="307")]))
    persistence = dict(repeat_report=repeat)
    ledger = b"review3 synthetic frozen ledger\n"
    state = json.dumps(facts["matches"]).encode()
    for folder_name, key in (("before", "before_manifest"), ("after", "after_manifest"), ("restored", "restored_manifest")):
        folder = tmp_path / folder_name
        (folder / "state").mkdir(parents=True)
        (folder / "state/matches.jsonl").write_bytes(state)
        (folder / "ledger.jsonl").write_bytes(ledger)
        persistence[key] = save(tmp_path, folder_name + "/feed_manifest.json", dict(
            counts={"matches": 2}, columns={"matches": list(facts["matches"][0])}, sources={"jc": 2},
            files={"state/matches.jsonl": sha256(state).hexdigest()}))
    facts["manifest"]["sha256"] = persistence["before_manifest"]["sha256"]
    snapshot = dict(coverage={"teams": 2, "matches": 2}, relations=[["jc:20", "apif:10"], ["jc:21", "apif:11"]],
                    quarantine=[], training_selection=[], immutable_sha256={"ledger.jsonl": sha256(ledger).hexdigest()})
    for key in ("before_repeat", "after_repeat", "restored"):
        persistence[key] = save(tmp_path, key + ".json", snapshot)
    replay = save(tmp_path, "replay.json", dict(official_match_ids=["jc:20", "jc:21"], fixture_ids=["apif:10", "apif:11"],
        raw_sha256=[r["sha256"] for r in api_refs], inserted=0, risk_ids=[],
        outcomes=[dict(fixture_id="apif:10", outcome="unchanged"), dict(fixture_id="apif:11", outcome="linked")]))
    evidence = dict(provider_code="307", cutoff_utc=CUTOFF, archive_sha256=facts["manifest"]["sha256"],
        current_season_replay=dict(report=current, held_before=dict(path="held.csv", sha256=sha256(held_raw).hexdigest())),
        recent_replay=dict(originals=api_refs, official_originals=jc_refs, results=replay),
        risk_review=save(tmp_path, "risks.json", []), persistence=persistence)
    return facts, evidence, tmp_path


def assess(bundle):
    facts, evidence, root = bundle
    return assess_league(facts, "307", CUTOFF, evidence=evidence, evidence_root=root)


def test_review3_midmonth_with_new_official_match_is_ready_only_for_review(complete_bundle):
    result = assess(complete_bundle)
    assert result["status"] == "ready_for_review", result
    assert result["daily_changed"] is False
    assert result["online_permission"] == "reviewer_verification_required"
    assert result["official_window"]["end_beijing"] == "2026-10-31"
    assert result["matches"]["total"] == 1
    recent = result["evidence"]["recent_replay"]
    assert recent["official_match_ids"] == ["jc:20", "jc:21"]
    assert len(recent["utc_dates"]) == 31
    assert recent["official_window"]["end_beijing"] == "2026-11-13"


@pytest.mark.parametrize("damage", ["missing_day", "missing_page", "wrong_date", "wrong_official_identity", "omit_official_match", "missing_utc_day", "sidecar_sha"])
def test_review3_midmonth_corrupt_evidence_is_insufficient(complete_bundle, damage):
    facts, evidence, root = complete_bundle
    section = evidence["recent_replay"]
    if damage == "missing_day":
        section["official_originals"].pop(0)
    elif damage == "missing_utc_day":
        section["originals"].pop(0)
    elif damage == "omit_official_match":
        payload = json.loads((root / "replay.json").read_bytes())
        payload["official_match_ids"] = ["jc:20"]
        section["results"] = save(root, "replay.json", payload)
    else:
        reference = section["official_originals"][4]
        path = root / reference["path"]
        doc = json.loads(path.read_bytes())
        if damage == "missing_page":
            template = deepcopy(doc["value"]["matchResult"][0])
            doc["value"].update(total=31, pages=2, matchResult=[dict(template, matchId=100+i) for i in range(30)])
        elif damage == "wrong_date":
            doc["value"]["matchResult"][0]["matchDate"] = "2026-11-06"
        elif damage == "wrong_official_identity":
            doc["value"]["leagueList"][0]["leagueId"] = 78
            doc["value"]["matchResult"][0]["leagueId"] = 78
        else:
            doc["review_tamper"] = True
        path.write_text(json.dumps(doc))
        reference["sha256"] = sha256(path.read_bytes()).hexdigest()
        if damage != "sidecar_sha":
            meta_path = path.with_suffix(path.suffix + ".meta.json")
            meta = json.loads(meta_path.read_bytes())
            meta["sha256"] = reference["sha256"]
            meta_path.write_text(json.dumps(meta))
    result = assess(complete_bundle)
    assert result["status"] == "insufficient_evidence", result
    assert "recent_replay" in result["missing_evidence"]


def test_review3_unresolved_held_explanation_does_not_become_ready(complete_bundle):
    facts, evidence, root = complete_bundle
    audit = "raw_sha256,competition_code,league,provider_match_id\n" + "a"*64 + ",307,测试联赛,999\n"
    (root / "held.csv").write_text(audit)
    evidence["current_season_replay"]["held_before"]["sha256"] = sha256((root / "held.csv").read_bytes()).hexdigest()
    proof = save(root, "held-review.json", dict(reason="fixture disappeared; pending source verification"))
    evidence["current_season_replay"]["held_explanations"] = save(root, "held-explanations.json", [dict(
        fixture_id="apif:999", disposition="still_held", reason="missing original", evidence=proof)])
    result = assess(complete_bundle)
    assert result["status"] == "blocked"
    assert "current_season_held_unresolved" in result["blockers"]
    assert result["evidence"]["current_season_replay"]["held_before_ids"] == ["apif:999"]
    assert result["evidence"]["current_season_replay"]["resolved_ids"] == []
