# Task4 I4：晚班 stats 二次导出修复

本轮按父级明确 GO，在全量未完成的 `a-rest-integration-3-*` 已停止并封存后实施。原 freeze-4、review4 探针/失败日志及此前定向结果均未覆盖。

独立审查 `task-4-review4-initial.md` 和原探针证明：晚班 `apis` 之后的 `stats_batch.collect_batch(daily=True)` 保存四个每日 complete 来源和历史 `apif_backfill.partial`，技术采集本身 complete、pending 为 0，但再次默认 `export_feeds` 后全局状态错误变 partial。

产品只改 `src/zucai/stats_batch.py` 调用方两处：导入现有 `daily_collection`，并在导出时传 `status_collection=daily_collection(collection) if daily else None`。完整 collection 原样归档；每日调用仅过滤已识别历史回填状态，当前 stats 自己的状态仍纳入。非 daily 技术回填传 None，保留原默认汇总语义。`cloud_feeds.py`、日报、模型、身份、gate 均与 freeze-4 一致。

新增 `tests/test_t68_stats_collection.py` 使用既有 T32 fixture、实际 collector/parser/cursor/export/Release mock，覆盖：

- 四每日来源 complete、三历史回填 partial、stats complete、pending 0，最终 complete，所有原来源及历史回填报告保持不变。
- 当前真实 injuries 响应 errors 使 cursor outcome=error、stats partial，最终仍 partial（没有伪造整个 stats 返回值）。
- 新增未解决竞彩拒收记录，stats complete 但 pending_result_count=1、最终 partial。
- 原每日 API 来源真实 partial 保持 partial。
- 非 daily 技术回填的原有全局汇总语义不变。

修前 `task-4-stats-red.log/.xml` 有 3 fail / 3 pass，其中新增测试误要求解析失败必须同时有顶层 errors；真实实现将解析原因记入 cursor，故将断言校正为 outcome=error。校正后、产品修前 `task-4-stats-red2.log/.xml` 为 **2 fail / 4 pass**：自有正常晚班反例与未修改的 reviewer 原反例均失败，三个真实失败/欠缺场景和非 daily 兼容已通过。

修后 `task-4-stats-final.log/.xml`：**270 tests，0 failures/errors/skipped，JUnit 78.083s**，包含 reviewer 整份原 probes（未修改）、stats batch/workflow、原回填隔离、sync/apis、日报和 FD daily。`task-4-stats-ruff.log` / `task-4-stats-format.log` 两文件检查通过，`git diff --check` 通过。freeze-4 原 24 owned 文件逐一 SHA 相同；本阶段新增 owned 为 `stats_batch.py` 与 `test_t68_stats_collection.py`，冻结见 `task-4-owned-freeze-5.json`。

未发真实 HTTP/Release 请求，未用正式 key，未修改正式配置、原件、模型/身份模块或导出器默认行为，未提交推送。父级负责修后独立复查与最终全量。
