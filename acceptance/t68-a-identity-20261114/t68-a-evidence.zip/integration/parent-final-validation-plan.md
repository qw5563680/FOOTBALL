# Parent final validation (offline regression, not accuracy experiment)

Run only after Task3/Task4 implementation and independent reviews freeze product files.
Worktree: `/workspace/work/football-t68-a-rest`; scripts/output base: `/workspace/work/football-t68/work/t68-a`.
No production/sports HTTP/key/manual Actions/merge. PR140 is already owner-merged as main13e968dd.

1. Save final tracked+new src/tests/fixtures/workflow SHA, protected configurations, original fixed inputs and source DB hashes.
2. Current deterministic 26 fits, then baseline comparison (only 12 approved MLS input exclusions expected):
   `PYTHONPATH=/workspace/work/football-t68-a-rest/src /workspace/work/t48-venv/bin/python /workspace/work/football-t68/work/t68-a/model_regression.py current --code /workspace/work/football-t68-a-rest`.
   `/workspace/work/t48-venv/bin/python /workspace/work/football-t68/work/t68-a/compare_model_regression.py`.
3. `PYTHONPATH=src /workspace/work/t48-venv/bin/python work/t68-a/roundtrip_fixed_results.py`.
   This script is prepared/compiled, NOT yet executed. Own new `a-rest-roundtrip` copies only: core logical tables, candidate138, audit CSV and both exports' file hashes must agree. Not a complete production backup claim.
4. Same final-source 26 fits after restore:
   `PYTHONPATH=/workspace/work/football-t68-a-rest/src /workspace/work/t48-venv/bin/python /workspace/work/football-t68/work/t68-a/model_regression.py restored --code /workspace/work/football-t68-a-rest --database /workspace/work/football-t68-a-rest/work/t68-a/a-rest-roundtrip/restored/data/zucai.db`.
   `/workspace/work/t48-venv/bin/python /workspace/work/football-t68/work/t68-a/compare_restored_regression.py`.
   `model_regression_baseline_script.py` preserves old runner before optional `--database` added. Actual old outputs remain unchanged.
5. Fixed audit/447 budget explanation, Task4 daily-gate actual missing evidence, official config hashes, 1142 frozen Git object list and fixed original2305+3 candidates SHA.
6. Full pytest with actual GITHUB_STEP_SUMMARY and `-o tmp_path_retention_policy=failed --junitxml=... --basetemp=...`; Ruff check src tests examples + format --check src tests. Avoid parallel heavy fits/pytest; disk <1GB.
7. Report README+SHA only (<200KB). Large evidence separate immutable data branch as existing A1 publishers, preserve failures and stage SHA boundaries. Final source tests SHA unchanged; docs may finish afterwards.
8. Commit normal, push existing codex/T68-A-identity-and-quarantine, create draft PR title T68: base main. Follow AGENTS template and real test/evidence limits. Do not merge; observe actual automatic CI until green.

Task2 final stage: frozen16files;89Task2/368targeted,internal280;verified-replay+repeat same93/0opposite,116diagnostic,strict0,legacy138,new0;queueSHA274cb4dde21fc2d6463e05c44f5b52ac07c0a27f0bdb3f098e78c146abbf89c1. Final report task-2-report.md; exact final details task-2-verified-evidence/*.json, review task-2-review.md. Task4 may legitimately change apif_ingest counters later; distinguish Task2 stage hashes from final integrated hashes.

Remaining required staging: Task3 active `/root/t68_a3_quarantine`; after code freeze spawn fresh independent Task3 reviewer and fix findings; only then use collaboration.followup_task to GO idle `/root/t68_a4_collection` (read-only prep finished, no files written). Task4 also needs fresh internal review before final checks. Parent owns all docs/reports/commit/push/PR.

2026-11-14 follow-up after context restore:
- Task3 reviewer found Important2; worker fixing complete incoming/outgoing old bridge claims + independent risk retention. Initial 17 reviewer cases5failed/12passed, logs retained.
- Parent caught overbroad missing-endpoint audit: JC->FD/APIF/FDORG virtual source references are legal existing import semantics, not necessarily broken Match references. Worker confirmed newly surfaced535 are481FD+54FDORG, old17JC->APIF also external refs. Final audit must distinguish legal external references from true FD->missingJC etc, preserve per-ID differences; final counts may differ43.
- Task3 review agent is currently idle/completed; use followup_task after revised freeze, then Task4 GO only after internal pass.
- Parent prepared ignored scripts final_source_freeze.py (save/check), package_final_evidence.py and publish_final_evidence_ref.py. Not executed. New evidence branch intended data/t68-a-identity-acceptance-20261114, path acceptance/t68-a-identity-20261114, ZIP t68-a-evidence.zip. Publisher requires finalvalidation statuspassed; cannot overwrite existingref.
- Evidence pack includes selected task logs/review failures/final Task2 replay folders, modelbaseline/current/restored outputs and fixed manifests. Excludes raw runtime secret directories and temporary DBs. Ensure Task4 actual output paths added if different.
- Full suite final logs should be at work/t68-a root; final summary filename a-rest-final-validation.json. No numeric A3/A4 finalclaims before independent recheck.

2026-11-14 ~15:30 UTC staging update:
- Task3 independent second review PASSED: task-3-review.md / task-3-review-rereview.md (initial failure saved task-3-review-initial.md), 27 independent cases green, two Important closed. Final fixed audit-reviewed is26=21+5,6592raw/6571temporary,38821denominator;552 legal JC external source refs17APIF/481FD/54FDORG, old17 per-ID evidence retained. Full-input-review2 on same frozen source26policies passed MLS12 only/other25exact.
- Task4 implemented/frozen, /root/t68_a4_collection idle. Final task-4-owned-freeze-2.json16files, task-4-report.md contract, final3 XML365 tests0fail/error/skip24.31sec. Fresh /root/t68_a4_review running independent read-only review. Parent caught ordinary Actions summary missing held/suspected columns; worker fixed + real offline3day fixturetest.
- Parent source freeze saved a-rest-source-freeze.json (689 src/tests/data/.github files), then full pytest started session36299 with GITHUB_STEP_SUMMARY, a-rest-pytest.log/XML and pytest-final basetemp, failures retention. Ruff check src tests examples and format --check src tests both EXIT0 (392formatted files). No26fits yet; wait Task4review outcome before fits. Preserve this freeze/logs if source fix required; final_source_freeze.py never overwrites.
- Parent independent official denominator: a-rest-jc-denominator-baseline.json/.log (62route1083matches,32zero; top10 per-team counts). all62-final gate workerfile SHA c6203407... independently matched (a-rest-gate-independent-comparison.json; oldcomparisoninitial preserved).
- CAUTION gate worker cutoff12:00UTC differs model baseline10:43:21.807840UTC. Docs currently explicitly call10:43 model cutoff only; after review final integration should run fresh gate CLI all62 at exact model cutoff for统一记录 (newpath, neveroverwrite) and update independent comparison. Same Beijingwindow so denominator expected unchanged. Current all62final allinsufficient and metadata current_season absent; no guessingmaxyear.
- All helper package/publisher scripts prepared but NOT run. Update package to include any final roundtrip additional evidence/newgate outputs as needed. New report A2/A3filled,A4/final stillpending. README/ARCHITECTURE/DATA_SOURCES already have current CLI and statuses; finalcheck againstworkercontract.
- git global email was unexpectedly old personal address on reread; reset per user explicit standing instruction to88015047+qw5563680@users.noreply.github.com. Effective+globalconfirmedcorrect. Do not print private old address.
- Remote ls-remote: main13e968dd; no remote A-rest or evidence branch yet. No remaining-A commit/push/PR. No sportsHTTP/production/manualActions.

2026-11-14 latest supplement:
- PR139 now f963cfe adds backfill/daily collection-key separation; Task4 single writer implementing. Prior full integration2:4321/0fail/error/skip254.007s,689sourceSHAunchanged, archived a-rest-integration-2-* before new product edits. First failed4305 preserved integration1.
- Reviewer actual Actions head archive afdf86dd9adbd5cf9bec0e5d3dee832eba1b208a now available; Task2 read-only post-head second materialization/replay separate from old modelcutoff. A1083+B179 allclockknown, newcore matches/results changed, cannotmix baselines.
- Numerical regression now runs immutable work/t68-a/model-code-final snapshot, 472 src/data files5,256,736bytes. Save actual imported zucai module hashes and require final product hashes plus model data equal; any loaded module drift invalidates/requires rerun. This allows unrelated Task4 reporting/collection amendment to proceed concurrently without moving model code. Do not claim snapshot's entire source tree equals final product if only nonloaded report modules changed. Current run session10936.
- Final roundtrip must rerun after export-code amendment, using roundtrip_fixed_results_final.py/new a-rest-roundtrip-final; neveroverwrite old roundtrip. Original207 identical content files deduplicated with hardlinks only within owned completed test exports; all paths/bytes remain exact, storage record retained.
