"""Independent failure boundaries for the daily statistics export call site."""
import json

import pytest
import responses

from test_stats_batch import NOW, batch as batch, run as run_stats
from zucai.cloud_feeds import archive_info
from zucai.stats_batch import collect_batch
from zucai.stats_schedule import plan


@pytest.fixture(autouse=True)
def offline_only():
    with responses.RequestsMock():
        yield


@pytest.mark.parametrize("case", ["http_failure", "unresolved_result", "unidentified_legacy_partial"])
def test_daily_stats_filters_history_but_retains_genuine_partial(batch, case):
    database, archive, release, client = batch
    path = archive / "feed_manifest.json"
    meta = json.loads(path.read_bytes())
    history = {f"{provider}_backfill": dict(source=provider, operation="catalogue-backfill", status="partial")
               for provider in ("apif", "fdorg", "fd")}
    daily = {provider: dict(status="complete", run_id="daily") for provider in ("jc", "apif", "fdorg", "fd")}
    if case == "unidentified_legacy_partial":
        daily["apif"] = dict(status="partial", source="apif", operation="unknown-old-operation")
    meta.update(collection={**daily, **history}, collection_status="complete")
    path.write_text(json.dumps(meta))
    if case == "unresolved_result":
        (database.parent / "rejected_results.csv").write_text(
            "date,match_id,observed_utc,reason\n2026-11-01,jc:review-unresolved,2026-11-04T00:00:00Z,review rejection\n")
    with responses.RequestsMock() as http:
        if case == "http_failure":
            http.get("https://v3.football.api-sports.io/injuries?league=39&season=2026",
                     status=503, json={"error": "offline server failure"})
            result = collect_batch(database, archive, plan("39", "2026", "injuries", NOW),
                release=release, run_id="review-http-failure", now=NOW, daily=True, client_factory=client)
            assert len(http.calls) >= 1
            assert result["status"] == "partial"
        else:
            result = run_stats(batch, run_id="review-daily-negative", daily=True)
            assert result["status"] == "complete" and not http.calls
    after = archive_info(archive)
    assert not result.get("archive_failed"), result
    assert after["collection_status"] == "partial"
    assert after["pending_result_count"] == int(case == "unresolved_result")
    assert all(after["collection"][key] == value for key, value in {**daily, **history}.items())
