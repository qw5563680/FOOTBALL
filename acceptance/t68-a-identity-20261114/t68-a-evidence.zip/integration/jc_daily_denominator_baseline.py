"""Count official JC IDs from the already verified immutable A1 catalogue selection."""
import hashlib
import json
from collections import defaultdict
from datetime import UTC, datetime
from pathlib import Path

from zucai.jc_catalogue_kickoffs import APPROVED_ROUTE_IDS, GENERIC_IDS

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
BASE = Path('/workspace/work/football-t68/work/t68-a')
plan_file = BASE / 'a1-review2-kickoff-plan-fixed.json'
registry_file = REPO / 'data/league_map.json'
plan = json.loads(plan_file.read_text())
registry = json.loads(registry_file.read_text())
assert hashlib.sha256(registry_file.read_bytes()).hexdigest() == plan['registry_sha256']
rows = [row for row in plan['selected'] if row['league_id'] not in GENERIC_IDS]
assert len({row['match_id'] for row in rows}) == len(rows) == 1083
routes = []
assigned = []
for code in sorted(APPROVED_ROUTE_IDS, key=int):
    league = registry['providers']['apif'][code]['config']['league']
    selected = [row for row in rows if row['league'] == league]
    teams = defaultdict(set)
    for row in selected:
        for side in ('home', 'away'):
            teams[row[side + '_team_id']].add(row[side + '_name'])
    ids = sorted(row['match_id'] for row in selected)
    assigned.extend(ids)
    routes.append(dict(provider_code=code, league=league, official_match_count=len(ids),
                       official_team_count=len(teams), official_match_ids=ids,
                       official_teams=[dict(jc_team_id=key, observed_names=sorted(names)) for key, names in sorted(teams.items())],
                       zero_denominator=(not ids), binding_rate=None,
                       boundary='Counts only; no binding, association, current-season coverage or daily permission claim'))
assert len(routes) == 62 and sorted(assigned) == sorted(row['match_id'] for row in rows)
result = dict(data_commit='e370db1d5cabe1cb33ddbfff3029c6d802bb8992',
              source_plan_sha256=hashlib.sha256(plan_file.read_bytes()).hexdigest(),
              registry_sha256=plan['registry_sha256'], window_beijing=['2025-11-01','2026-10-31'],
              observed_utc=datetime.now(UTC).isoformat(), routes=routes,
              new_route_match_count=1083, generic_matches_excluded=179,
              zero_match_routes=sum(not row['official_match_count'] for row in routes),
              scope='Official twelve-month denominator only; zero matches is not 100% readiness')
(HERE / 'a-rest-jc-denominator-baseline.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print('62 routes, 1083 matches, generic179 excluded; zero-match routes', result['zero_match_routes'])
print([(r['league'],r['official_match_count'],r['official_team_count']) for r in sorted(routes,key=lambda r:-r['official_match_count'])[:10]])
