"""Only discard this invocation's per-test tmp_path after successful teardown.

No collection, assertions, fixtures or outcomes are changed. Failed and shared
factory directories are retained. This bounds disk for the full suite.
"""
import shutil
import pytest

@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    if report.when == 'call' and report.passed:
        item._football_passed_tmp = item.funcargs.get('tmp_path')
    if report.when == 'teardown' and report.passed:
        path = getattr(item, '_football_passed_tmp', None)
        if path is not None:
            base = item.config._tmp_path_factory.getbasetemp().resolve()
            if path.exists() and not path.is_symlink() and path.resolve().parent == base:
                shutil.rmtree(path)
