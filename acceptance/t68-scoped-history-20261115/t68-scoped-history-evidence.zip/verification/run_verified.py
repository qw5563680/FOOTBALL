"""Record an offline verification command, exact code hashes and actual execution times."""
import argparse
import hashlib
import json
import os
import subprocess
import time
from datetime import UTC, datetime
from pathlib import Path
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('label')
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
assert args.command
label = args.label
assert Path(label).name == label
log = HERE / (label + '.log')
record_path = HERE / (label + '.execution.json')
assert not log.exists() and not record_path.exists(), 'Verification artifacts are append-only'

def hashes():
    paths = subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','src','tests','data/model','data/team_aliases','data/identity_categories.json','data/identity_reviews','.github/workflows'],cwd=REPO,text=True).splitlines()
    return {p:hashlib.sha256((REPO/p).read_bytes()).hexdigest() for p in sorted(paths)}

def stamp():
    now = datetime.now(UTC)
    return {'utc':now.isoformat(),'beijing':now.astimezone(ZoneInfo('Asia/Shanghai')).isoformat()}

import ctypes
ctypes.CDLL(None).prctl(36, 1, 0, 0, 0)  # Reap adopted Git helper exits in this verification wrapper.
before = hashes()
started = stamp()
start_clock = time.monotonic()
env = os.environ.copy()
env['PYTHONPATH'] = 'src:' + str(HERE / 'verification_plugins')
for key in ('API_FOOTBALL_KEY','FOOTBALL_DATA_ORG_TOKEN'):env.pop(key,None)
if any('pytest' in part for part in args.command):
    for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):env[key]='1'
for key,value in (('gc.auto','0'),('maintenance.auto','false'),('pack.threads','1')):
    count=int(env.get('GIT_CONFIG_COUNT','0'));env[f'GIT_CONFIG_KEY_{count}']=key;env[f'GIT_CONFIG_VALUE_{count}']=value;env['GIT_CONFIG_COUNT']=str(count+1)
env['GITHUB_STEP_SUMMARY'] = str(HERE / (label + '-step-summary.md'))
with log.open('x') as f:
    completed = subprocess.run(args.command,cwd=REPO,env=env,stdout=f,stderr=subprocess.STDOUT)
while True:
    try:
        if os.waitpid(-1, os.WNOHANG)[0] == 0: break
    except ChildProcessError: break
after = hashes()
record = dict(command=args.command,cwd=str(REPO),code_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),started=started,completed=stamp(),seconds=time.monotonic()-start_clock,exit_code=completed.returncode,code_sha256=before,code_unchanged_during_execution=before==after,resource_environment={k:env[k] for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS') if k in env},git_runtime_options={'gc.auto':'0','maintenance.auto':'false','pack.threads':'1'},production_sports_keys_removed=True,source_changes={p:[before.get(p),after.get(p)] for p in before.keys()|after.keys() if before.get(p)!=after.get(p)},log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),archive_manifest_sha256=hashlib.sha256((HERE.parent/'t68-section7/archive-manifest.json').read_bytes()).hexdigest())
record_path.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ('code_commit','seconds','exit_code','code_unchanged_during_execution')},ensure_ascii=False),flush=True)
assert before == after, 'Code changed during execution; cannot use as frozen verification'
raise SystemExit(completed.returncode)
