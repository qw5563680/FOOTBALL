"""Package reproducible offline evidence only; exclude DBs, caches and credentials."""
import hashlib,json,subprocess,zipfile,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parents[1]
OUT=ROOT/'published';OUT.mkdir(exist_ok=True)
code=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
items={}
def add(path,name):
 assert path.is_file() and not path.is_symlink()
 items[name]=path
for name in ['full-suite-release','release-real-replay','release-gates']:
 rec=json.loads((ROOT/(name+'.execution.json')).read_bytes())
 assert rec['exit_code']==0 and rec['code_unchanged_during_execution']
 for key,digest in rec['code_sha256'].items():
  assert hashlib.sha256((REPO/key).read_bytes()).hexdigest()==digest,key
for p in (ROOT/'release-acceptance').rglob('*'):
 if p.is_file() and p.suffix not in {'.db','.gz'}:
  add(p,'acceptance/'+p.relative_to(ROOT/'release-acceptance').as_posix())
for p in (REPO/'work/t68-section7/auxiliary-fd').iterdir():
 if p.is_file():add(p,'auxiliary-fd/'+p.name)
for p in ROOT.iterdir():
 if p.is_file() and p.suffix in {'.log','.py','.json','.md','.csv'}:
  if p.name in {'package-release.json','evidence-ref.json','publication-receipt.json'}:continue
  add(p,'verification/'+p.name)
add(ROOT/'verification_plugins/cleanup_passed_temps.py','verification_plugins/cleanup_passed_temps.py')
for p in [REPO/'src/zucai/identity_canonical.py',REPO/'src/zucai/sources/apif_scoped_reconcile.py',REPO/'src/zucai/identity_daily_gate.py',REPO/'src/zucai/identity_binding_archive.py']:
 add(p,'tested-source/'+p.relative_to(REPO).as_posix())
for name in ['test_t68_canonical_approval.py','test_t68_scoped_reconcile.py','test_t68_missing_season.py']:
 add(REPO/'tests'/name,'tested-source/tests/'+name)
manifest={name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in sorted(items.items())}
# Positive credential forms only; variable names and synthetic test text are not secrets.
patterns=[rb'gh[pousr]_[A-Za-z0-9]{30,}',rb'github_pat_[A-Za-z0-9_]{40,}',rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----']
for name,p in items.items():
 raw=p.read_bytes()
 assert not any(re.search(pattern,raw) for pattern in patterns),name
zip_path=OUT/'t68-scoped-history-evidence.zip'
assert not zip_path.exists()
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,p in sorted(items.items()):z.write(p,name)
 z.writestr('SHA256SUMS.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
record=dict(file=zip_path.name,sha256=hashlib.sha256(zip_path.read_bytes()).hexdigest(),bytes=zip_path.stat().st_size,members=len(manifest)+1,code_commit=code,credentials_scan='passed',archive='8b900f4cf0f9a1ca1afbafc9298e97b7cc7519f2',scope='offline core/results acceptance; not production deployment or full stats/frozen backup')
(ROOT/'package-release.json').write_text(json.dumps(record,indent=2)+'\n')
(OUT/'SHA256SUMS').write_text(record['sha256']+'  '+zip_path.name+'\n')
# Convenient small files can be inspected without downloading the zip.
for name in ['coverage-comparison.json','coverage-additional-relations.csv','historical-replay-410.csv','remaining-saudi-12.csv','historical-replay-counts.json','replay-summary.json','canonical-creation-queue.csv','canonical-proposals.json']:
 p=ROOT/'release-acceptance'/name
 (OUT/name).write_bytes(p.read_bytes())
(OUT/'README.md').write_text(f'''# T68 四项跟进：离线验收证据\n\n代码：{code}\n\n固定归档：8b900f4cf0f9a1ca1afbafc9298e97b7cc7519f2；实际 UTC/北京时间、命令及源码哈希在 verification/*.execution.json。\n\n压缩包：{zip_path.name}，SHA256 `{record['sha256']}`。{record['members']}项，逐项 SHA256SUMS.json 已校验，不含数据库或访问密钥。\n\n原359条拒收中349恢复正常处理，10仍待核；加原有2条共12。全部仍待核行保留编号、原因。257创建决定仍为proposed，未批准/未创建。原档日职3/52、瑞超0/77；含 auxiliary-fd 资料才有31/52、19/77。\n\n解压后 acceptance/replay-export 与 replay-export2 是可恢复的核心表导出，并非生产全量备份。二者207个文件内容一致；原件另从固定归档取得，FD辅助原件已随包给出。\n\nverification/ 保留失败与成功记录：第一次全量因 ENOSPC 失败；full-suite-release 是最后全量结果。成功临时目录清理插件只在用例及teardown通过后删除该用例的tmp_path，不删失败或共享目录，不改变断言。\n\n没有运行生产任务、发布正式数据、开启每日采集或合并PR。下一步由Claude按PR任务单独立复核，再由所有者决定正式应用。\n''')
print(json.dumps(record))
