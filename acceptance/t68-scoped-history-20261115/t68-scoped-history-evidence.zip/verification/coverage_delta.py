import json,csv,hashlib
from pathlib import Path
ROOT=Path('work/t68-next-20261115')
a={x['provider_code']:x for x in json.loads((ROOT/'gate-archive-only.json').read_bytes())['leagues']}
b={x['provider_code']:x for x in json.loads((ROOT/'gate-with-fd.json').read_bytes())['leagues']}
rows=[];summary={}
for code in ['98','113']:
 old=a[code]['matches'];new=b[code]['matches']
 ids={(r['jc_id'],r['provider_match_id']) for r in old['relations']}
 added=[r for r in new['relations'] if (r['jc_id'],r['provider_match_id']) not in ids]
 summary[code]=dict(league=a[code]['league'],archive_only=old['linked'],with_fd=new['linked'],denominator=new['total'],stored_current_jc=new['stored_current_jc'],pending_extra=len(new['pending_extra']),additional=len(added))
 for r in added:
  for p in r['provenance']:
   source=Path('work/t68-section7/auxiliary-fd')/p['path'];assert hashlib.sha256(source.read_bytes()).hexdigest()==p['sha256']
   rows.append(dict(league=a[code]['league'],jc_id=r['jc_id'],provider_match_id=r['provider_match_id'],source=r['source'],raw_file=p['path'],raw_sha256=p['sha256'],raw_pointer=p['pointer'],fetched_at_utc=p['fetched_at_utc'],source_url=p['url'],stored_match_pointer=r['stored_evidence']['matches_pointer']))
with (ROOT/'coverage-additional-relations.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(ROOT/'coverage-comparison.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False))
