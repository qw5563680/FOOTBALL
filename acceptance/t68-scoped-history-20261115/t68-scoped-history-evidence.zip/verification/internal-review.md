# T68 internal precheck — 2026-11-15

Conclusion: changes required for the Important finding below. This is an internal Codex precheck, not Claude's formal review or owner approval.

Reviewed uncommitted changes on `codex/T68-scoped-history-and-identity-approval`, base `origin/main` / `ef08c66`: full tracked diff, both new production modules, all three new test modules, relevant archive/identity/link/export readers, AGENTS.md, implementation plan, progress ledger, T68 task and latest review/owner records. No production writes, sports requests, source changes, commits, or full-suite execution were performed by this review.

## Findings

### Important I1 — restored creation receipts do not reject another owner of the same numeric marker

- Location: `src/zucai/identity_canonical.py:182` and `:192-220` (`apply_created_identities`).
- The receipt loader verifies that its selected target contains `jc:team:<official>`, but does not check whether *another current Team row* also owns that marker. The later `teams` checks only cover official observations already associated through stored matches; an unobserved duplicate Team is absent from that graph.
- Reproduction: create one identity using the existing approved offline fixture; export its Team/receipt into the authenticated fixture archive; append `Team(id=99, name='Conflicting owner', aliases=['jc:team:<same official ID>'])`; reseal the current snapshot. `load_archive(..., leagues=['48'])` succeeds and returns `existing_numbered` for the receipt target despite two project owners of its supposedly unique numeric identity. No decision or receipt needs to change.
- Independent RED probe: `/tmp/t68-review-probes/test_receipt_conflict.py`, test `test_receipt_rejects_duplicate_numeric_marker_owner`. Command from repository root:
  `PYTHONPATH=tests:src /workspace/work/t48-venv/bin/python -m pytest -q -p no:cacheprovider /tmp/t68-review-probes/test_receipt_conflict.py --basetemp=/tmp/t68-review-probes/pytest`
  Result: **1 failed**, `Failed: DID NOT RAISE ValueError`.
- Impact: a later current snapshot can contain contradictory numeric ownership while the archived approval remains accepted as an unambiguous binding seed. This violates the new receipt's advertised uniqueness/current-inventory protection. The initial apply collision check does not protect future archives.
- Suggested repair: build a normalized ownership index over every current Team name/alias; require the receipt numeric marker to have exactly the receipt target as owner, and reject contradictory official markers on that target. Add a full archive-reader regression (including a duplicate owner outside the selected competition's observations).

### Minor M1 — several promised boundary tests are not exercised by the new tests

- `tests/test_t68_canonical_approval.py:test_creation_rejects_invalid_approval_without_writes`: `alias_collision` adds an extra Team after freezing the archive, so the team-inventory mismatch rejects it before the name/alias collision branch runs. Include the colliding Team in both the frozen archive and restored DB to test the intended branch.
- `tests/test_t68_scoped_reconcile.py:test_scoped_conflicts_not_linked`: the time-scope case excludes every match; it does not prove that one authorized historical row moves while another same-league row outside the interval and its provisional identity remain unchanged.
- `tests/test_t68_missing_season.py`: one missing/invalid route is tested at a time; the planned mixed register containing both an invalid and valid route is not asserted.

No Critical finding.

## Positive checks and evidence limits

- The scoped module projects both opponents before link validation, uses the existing strict reverse/claim/multiple-candidate checks, restricts selected routes and league-local/time-authorized match updates, preserves result fields, and conservatively rejects attached team snapshot references. Legacy reconcile and automatic workflows are unchanged.
- The season preflight returns blocked/null denominators; it does not infer a year or change route permission.
- Creation apply requires approved decisions, owner/review metadata, frozen numeric evidence, approved category, a stable live team/fixture inventory, and exact collision checks; repeated application against the same proposal is covered.
- Independent targeted execution of the three new test files passed (26 cases) with `--basetemp=/tmp/t68-review-probes/existing-tests`, cache disabled. The parent owns the full-suite run; this review makes no claim about its final result.
- Inspected saved evidence, without independently repeating the expensive real-data replay: canonical worklist contains **257 proposed decisions**, none approved; saved gate outputs give JPN **3/52** / SWE **0/77** without auxiliary FD and **31/52** / **19/77** with FD. Replay summary records **2,479** changed historical match identities, protected result/other-competition comparisons unchanged, and **207** equal export/restore file hashes. These are implementation evidence, not an independently rerun formal acceptance.

## Four review questions

1. Frozen predictions/parameters/run logs: no changed code writes those artifacts. The replay's 207-file comparison is explicitly a core/results copy, not a full frozen production backup.
2. Other matches/routing/probabilities: no automatic route or model changes; scoped migration intentionally changes selected match team IDs and unique JC pointers. No other-match mutation found in static inspection. I1 concerns future receipt-based identity interpretation, not a demonstrated change to a real match ID.
3. Information timing: no model input or result-known timestamps are changed. Approval and creation timestamps remain explicit; historical identity correction is not evidence that the identity was known before an old match.
4. Coverage: targeted tests pass; independent duplicate-marker regression fails. Additional coverage gaps are listed in M1.
