import json
from pathlib import Path
from datetime import datetime, UTC
from zucai.identity_daily_gate import build_register
ROOT=Path('work/t68-next-20261115/release-acceptance')
ARCHIVE=Path('work/t68-pr143-review-20261115/archive-with-pending')
for label,codes,fd in [('archive-only',None,None),('with-fd',['98','113'],'work/t68-section7/auxiliary-fd')]:
 d=build_register(ARCHIVE,'2026-11-14T16:30:00Z',codes=codes,fd_raw_dir=fd)
 (ROOT/f'gate-{label}.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))
 print(label,len(d['leagues']),[(x['provider_code'],x['matches']['linked'],x['matches']['total']) for x in d['leagues'] if x['provider_code'] in ['98','113']],flush=True)
 if codes is None:
  missing=[x['provider_code'] for x in d['leagues'] if 'current_season_not_configured' in x['blockers']]
  print('missing seasons',len(missing),missing,flush=True)
(ROOT/'gate-execution.json').write_text(json.dumps(dict(observed_utc=datetime.now(UTC).isoformat(),archive=str(ARCHIVE),cutoff='2026-11-14T16:30:00Z',sports_requests=0),indent=2))

from zucai.identity_canonical import propose
plan=propose(ARCHIVE)
(ROOT/'canonical-proposals.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2))
assert len(plan['decisions']) == 257
assert all(x['status']=='proposed' for x in plan['decisions'])
print('Creation proposals:',len(plan['decisions']),'real creations:0',flush=True)
