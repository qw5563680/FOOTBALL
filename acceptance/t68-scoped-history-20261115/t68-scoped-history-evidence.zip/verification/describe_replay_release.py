import json,csv,sqlite3,collections
from pathlib import Path
ROOT=Path('work/t68-next-20261115/release-acceptance')
a=json.loads((ROOT/'import-before.json').read_bytes());b=json.loads((ROOT/'import-after.json').read_bytes())
aliases=json.loads(Path('data/team_aliases/api_football.json').read_bytes())
rows=[];summaries={}
def all_rows(report):
 return [*report['outcomes'],*(dict(r,outcome='rejected') for r in report['rejected']),*(dict(r,outcome='suspected') for r in report['suspected']),*(dict(r,outcome='held') for r in report['held'])]
for code,data in b.items():
 league='沙职' if code=='307' else '世界杯'
 before={r['provider_match_id']:r for r in all_rows(a[code]['report'])}
 for row in all_rows(data['report']):
  missing=[str(row[s+'_provider_id']) for s in ('home','away') if aliases.get(league,{}).get(str(row[s+'_provider_id']),{}).get('status') not in ('approved','auto_verified')]
  rows.append(dict(competition_code=code,league=league,provider_match_id=row['provider_match_id'],home_provider_id=row['home_provider_id'],home=row['home'],away_provider_id=row['away_provider_id'],away=row['away'],kickoff_utc=row['kickoff_utc'],before=before[row['provider_match_id']]['outcome'],after=row['outcome'],stored_match_id=row.get('match_id'),reason=row.get('reason',''),unapproved_provider_ids=','.join(missing)))
 links=data['report']['links'];assert len({r['jc_id'] for r in links})==len(links)
 summaries[code]=dict(raw_rows=len(all_rows(data['report'])),outcomes=dict(collections.Counter(r['outcome'] for r in all_rows(data['report']))),distinct_jc_links=len(links))
with (ROOT/'historical-replay-410.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
with (ROOT/'remaining-saudi-12.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows([r for r in rows if r['after']=='suspected'])
(ROOT/'historical-replay-counts.json').write_text(json.dumps(summaries,ensure_ascii=False,indent=2))
print(json.dumps(summaries,ensure_ascii=False))
