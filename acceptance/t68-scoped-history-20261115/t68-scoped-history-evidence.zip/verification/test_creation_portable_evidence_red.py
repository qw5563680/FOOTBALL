import pytest
from test_t68_canonical_approval import creation, approved  # noqa
from test_t68_identity_archive_entry import archive as frozen_archive  # noqa
from zucai.identity_canonical import apply_approvals


def test_creation_rejects_missing_portable_originals(creation):
    archive, db = creation
    path, item = approved(archive)
    assert not any((db.parent / p['path']).exists() for row in item['evidence'] for p in row['originals'])
    before = db.read_bytes()
    with pytest.raises(ValueError, match='original'):
        apply_approvals(db, archive, path)
    assert db.read_bytes() == before
