import json,sqlite3,hashlib
from pathlib import Path
from datetime import UTC,datetime,date,timedelta
from zucai.identity_binding_archive import _tables
from zucai.cloud_feeds import TABLES,export_feeds,restore_feeds
from zucai.db import get_engine,init_db,session_scope
from zucai.sources.apif_scoped_reconcile import reconcile_scoped
from zucai.sources.apif_command import ALIASES
from zucai.sources.apif_ingest import import_apif_games
from zucai.sources.api_football import ApiFootball
from zucai.league_registry import provider_config
from zucai.result_source_identity import restore_result_identities
from zucai.result_source_links import restore_result_links
from zucai.fd_stats_archive import restore_fd_links
from unittest.mock import patch
blocked_http=patch('requests.sessions.Session.request', side_effect=AssertionError('Offline replay forbids HTTP')).start()
ROOT=Path('work/t68-next-20261115/final-acceptance');ROOT.mkdir(exist_ok=True);ARCHIVE=Path('work/t68-pr143-review-20261115/archive-with-pending')
DB=ROOT/'replay2/data/feeds.db';DB.parent.mkdir(parents=True,exist_ok=True)
assert not DB.exists()
tables,manifest=_tables(ARCHIVE)
engine=get_engine(DB);init_db(engine);engine.dispose()
with sqlite3.connect(DB) as con:
 for name,columns in TABLES.items():
  if name not in tables: continue
  con.executemany(f'INSERT INTO {name} ({",".join(columns)}) VALUES ({",".join("?" for _ in columns)})',[[json.dumps(r[c]) if isinstance(r[c],(list,dict)) else r[c] for c in columns] for r in tables[name]])
 doc=json.loads((ARCHIVE/'feed_manifest.json').read_bytes())
 restore_result_links(con,ARCHIVE,doc);restore_fd_links(con,ARCHIVE,doc);restore_result_identities(con,ARCHIVE,doc)
print('restored', {k:len(v) for k,v in tables.items()},flush=True)

def snapshot():
 with sqlite3.connect(DB) as con:
  return {table:con.execute('SELECT * FROM '+table+' ORDER BY 1').fetchall() for table in ['teams','matches','results','result_source_links','result_source_identities']}
def digest(v): return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
paths={}
for p in ARCHIVE.glob('state/catalogue/*/backfill/api-football/*/fixtures_*.json'):
 if p.name.endswith('.meta.json'): continue
 d=json.loads(p.read_bytes());params=d.get('parameters',{})
 if params.get('league') in ['1','307'] and params.get('season')=='2026':
  meta=json.loads(p.with_suffix('.json.meta.json').read_bytes())
  if params['league'] not in paths or meta['fetched_at_utc']>paths[params['league']][1]['fetched_at_utc']:paths[params['league']]=(p,meta)
aliases=json.loads(ALIASES.read_bytes());source=ApiFootball(leagues=provider_config('apif'))

def replay(label,rollback=False):
 out={}
 engine=get_engine(DB)
 for code,(p,meta) in paths.items():
  raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==meta['sha256']
  games=source.parse(raw,league_id=int(code),season=2026)
  with session_scope(engine) as session:
   report=import_apif_games(session,games,seen=datetime.fromisoformat(meta['fetched_at_utc'].replace('Z','+00:00')),assume=timedelta(hours=3),aliases=aliases)
   if rollback: session.rollback()
  out[code]=dict(raw_path=p.relative_to(ARCHIVE).as_posix(),raw_sha256=meta['sha256'],report=report)
 (ROOT/f'{label}.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,default=str))
 print(label,{c:{k:v for k,v in x['report'].items() if isinstance(v,int)} for c,x in out.items()},flush=True)
 engine.dispose();return out
before=snapshot();baseline=replay('import-before',True);assert snapshot()==before
report=reconcile_scoped(DB,['307','1'],'t68-scoped-offline')
(ROOT/'reconcile-real.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('reconcile',report['rekeyed_matches'],report['linked'],len(report['pending_links']),flush=True)
after=snapshot()
assert before['results']==after['results']
for table in ['result_source_links','result_source_identities']:assert before[table]==after[table]
# Field positions from SQLite reflect ORM schema, not feed columns.
with sqlite3.connect(DB) as con: cols=[r[1] for r in con.execute('PRAGMA table_info(matches)')]
allowed={cols.index(k) for k in ['home_team_id','away_team_id','counterpart_id']}
assert all(tuple(v for i,v in enumerate(a) if i not in allowed)==tuple(v for i,v in enumerate(b) if i not in allowed) for a,b in zip(before['matches'],after['matches'],strict=True))
league_index=cols.index('league')
assert [r for r in before['matches'] if r[league_index] not in ['沙职','世界杯']]==[r for r in after['matches'] if r[league_index] not in ['沙职','世界杯']]
first=replay('import-after');second=replay('import-repeat')
again=reconcile_scoped(DB,['307','1'],'t68-scoped-repeat')
(ROOT/'reconcile-repeat.json').write_text(json.dumps(again,ensure_ascii=False,indent=2))
print('repeat rekey',again['rekeyed_matches'],flush=True)
exported=export_feeds(DB,ROOT/'replay-export',date(2026,11,15),'t68-scoped-offline')
restored=ROOT/'replay-restored/data/feeds.db';restore_feeds(ROOT/'replay-export',restored)
export2=export_feeds(restored,ROOT/'replay-export2',date(2026,11,15),'t68-scoped-offline-repeat')
assert exported['files']==export2['files']
summary=dict(archive_sha256=manifest['sha256'],observed_utc=datetime.now(UTC).isoformat(),rekeyed=report['rekeyed_matches'],linked=report['linked'],pending=report['pending_links'],results_unchanged_by_reconcile=True,other_competition_matches_unchanged=True,nonidentity_match_fields_unchanged=True,roundtrip_files=len(exported['files']),roundtrip_equal=True,source_core_counts={k:len(v) for k,v in tables.items()},scope='Core/results identity copy; does not claim full production frozen artifact backup',before_hashes={k:digest(v) for k,v in before.items()},after_reconcile_hashes={k:digest(v) for k,v in after.items()})
(ROOT/'replay-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print('roundtrip passed',len(exported['files']),flush=True)

assert not blocked_http.called
