"""Read-only paired M1 checks on saved e370 originals; no sports requests."""
import hashlib
import importlib.util
import json
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch

import requests

from zucai import alias_propagation
from zucai.sources import cup_identity
from zucai.sources.fd_ingest import _canonical

ROOT = Path(__file__).resolve().parents[2]
BASE = Path('/workspace/work/football-t68/work/t68-a')
ARCHIVE = BASE / 'fixed-archive'
DB = BASE / 'model-fixture/data/zucai.db'
ALIASES = ROOT / 'data/team_aliases/api_football.json'
OLD = ROOT / 'work/t68-a/model-code-final/src/zucai'
OUT = Path(__file__).parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def normalized(entries, aliases, league):
    entries = deepcopy(entries)
    digest = hashlib.sha256(json.dumps(aliases, sort_keys=True).encode()).hexdigest()
    for key, entry in entries.items():
        if key in aliases.get(league, {}):
            # Pre-existing formal provenance is immutable, not newly generated.
            assert entry == aliases[league][key]
            continue
        for proof in entry.get('evidence', []):
            if 'source_aliases_sha256' in proof:
                assert proof.pop('source_aliases_sha256') == digest
    return entries


with patch.object(requests.sessions.Session, 'request', side_effect=AssertionError('offline only')):
    before = {str(p): sha(p) for p in [ALIASES, DB]}
    aliases = json.loads(ALIASES.read_bytes())
    old_cup = module('m1_old_cup', OLD / 'sources/cup_identity.py')
    old_propagation = module('m1_old_propagation', OLD / 'alias_propagation.py')
    labels = {'欧罗巴': {}, '欧协联': {}}
    evidence = {}
    for path in sorted((ARCHIVE / 'state/catalogue').glob('*/backfill/api-football/*/fixtures_*.json')):
        if path.name.endswith('.meta.json'):
            continue
        rows = json.loads(path.read_bytes()).get('response', [])
        used = False
        for game in rows:
            league = {3: '欧罗巴', 848: '欧协联'}.get(game['league']['id'])
            if league:
                used = True
                for team in game['teams'].values():
                    labels[league][str(team['id'])] = team['name']
        if used:
            evidence[str(path.relative_to(ARCHIVE))] = sha(path)
    assert evidence and all(labels.values())
    report = {'data_commit': 'e370db1d5cabe1cb33ddbfff3029c6d802bb8992', 'cups': {}}
    for league, names in labels.items():
        old = old_cup._bridge('apif', DB, league, names, aliases)
        current = cup_identity._bridge('apif', DB, league, names, aliases)
        assert old == current
        mixed = deepcopy(aliases)
        appended = []
        for key in sorted(names):
            sources = [ln for ln in aliases if _canonical(aliases, ln, key)]
            if sources:
                origin = sources[0]
                target = f'M1-scoped-example-{key}'
                mixed[target] = {key: {**deepcopy(aliases[origin][key]), 'binding_scope': {
                    'leagues': [target], 'category': 'club/men/senior/first'}}}
                appended.append(key)
        actual = cup_identity._bridge('apif', DB, league, names, mixed)
        assert normalized(current, aliases, league) == normalized(actual, mixed, league)
        report['cups'][league] = dict(raw_team_ids=len(names),
            active_ids=sum(_canonical({league: current}, league, key) is not None for key in names),
            injected_scoped_ids=appended, current_exactly_equal=True,
            mixed_equal_except_truthful_input_digest=True)
    histories = {key: {'M1-target'} for records in aliases.values() for key in records}
    before_plan = old_propagation._plan(aliases, 'apif', histories, sha(ALIASES))
    after_plan = alias_propagation._plan(aliases, 'apif', histories, sha(ALIASES))
    assert before_plan == after_plan
    report['propagation'] = dict(ids=len(histories), generated=len(after_plan[1]), equal=True,
                                target='M1-target (temporary only, not written to aliases)')
    assert before == {str(p): sha(p) for p in [ALIASES, DB]}
    report['inputs_unchanged'] = before
    report['raw_files'] = evidence
    report['loaded_code'] = {str(p): sha(p) for p in [
        OLD / 'sources/cup_identity.py', OLD / 'alias_propagation.py',
        ROOT / 'src/zucai/sources/cup_identity.py', ROOT / 'src/zucai/alias_propagation.py']}
    (OUT / 'real-legacy.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k in ('cups','propagation')}, ensure_ascii=False))
