"""Package M1 checks, including failures; never package secrets or databases."""
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from datetime import UTC, datetime
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
OUT = HERE / 'published'
BRANCH = 'data/t68-m1-acceptance-20261114'
PART = 't68-m1-20261114'


def git(*args, content=None):
    return subprocess.check_output(['git', *args], cwd=ROOT, input=content).decode().strip()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def tests(name):
    return ET.parse(HERE / name).getroot()[0].attrib


final = tests('final-full.xml')
assert all(final[key] == '0' for key in ('errors', 'failures', 'skipped'))
assert int(final['tests']) == 4384
assert (HERE / 'ruff.log').read_text().strip() == 'All checks passed!'
assert not git('diff', '--name-only', '--', 'data', '.github')
real = json.loads((HERE / 'real-legacy.json').read_text())
assert all(sha(Path(p).read_bytes()) == h for p, h in real['inputs_unchanged'].items())
for relative in ('src/zucai/sources/cup_identity.py', 'src/zucai/alias_propagation.py'):
    baseline = subprocess.check_output(['git','show','HEAD:'+relative],cwd=ROOT)
    old_path = str(ROOT / 'work/t68-a/model-code-final' / relative)
    assert sha(baseline) == real['loaded_code'][old_path]
source = [*git('ls-files', 'src', 'tests', 'data/fixtures', '.github').splitlines(),
          'tests/test_t68_scope_coexistence.py']
source = {p: sha((ROOT / p).read_bytes()) for p in sorted(set(source))}
(HERE / 'tested-files.json').write_text(json.dumps(source, indent=2)+'\n')
now = datetime.now(UTC)
summary = dict(status='passed', observed_utc=now.isoformat(),
    observed_beijing=now.astimezone(ZoneInfo('Asia/Shanghai')).isoformat(),
    baseline_commit=git('rev-parse', 'HEAD'), full=final,
    targeted=tests('targeted.xml'), regression_before_fix=tests('red-corrected.xml'),
    interrupted_full=tests('full.xml'), real_cups=real['cups'],
    propagation=real['propagation'], source_files=len(source),
    live_sports_requests=0, formal_alias_changes=0, production_data_writes=0,
    limitations=['Offline regression only; not a production replay or approval.',
                'Section 7 N1/N2/N3 are not implemented in this M1 change.',
                'Real mixed-source checks inject scoped examples only into memory.',
                'Generated source-file digest changes truthfully when input changes; other evidence equal.'])
(HERE / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n')
OUT.mkdir(exist_ok=False)
files = {p.name: p for p in HERE.iterdir() if p.is_file() and p.suffix in {'.json','.log','.xml','.md','.py'}}
files.update({p: ROOT / p for p in ('src/zucai/sources/cup_identity.py',
    'src/zucai/alias_propagation.py','tests/test_t68_scope_coexistence.py')})
manifest = {}
archive = OUT / 't68-m1-evidence.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name,p in sorted(files.items()):
        raw=p.read_bytes();manifest[name]=dict(sha256=sha(raw),bytes=len(raw));z.writestr(name,raw)
    z.writestr('FILE-MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(sha(z.read(n))==v['sha256'] for n,v in manifest.items())
zip_sha=sha(archive.read_bytes())
(OUT/'SHA256SUMS').write_text(f'{zip_sha}  {archive.name}\n')
(OUT/'README.md').write_text(
    '# T68 M1：范围条目与旧授权并存\n\n'
    f'全量 {final["tests"]} passed；定向151 passed；新增28项，修前20失败。\n\n'
    '保留修前失败、定向/全量结果、真实归档逐项比较、测试源码与SHA。\n'
    'full.xml 是修正Ruff未使用变量前主动停止的一轮，1455项通过、退出2，不是完整通过。\n'
    'real-legacy.log 首轮核对脚本错误地把既有正式证据摘要当成本轮生成摘要；修正脚本后结果见 real-legacy.json。\n'
    'red.xml 包含1个不合法状态的测试错误；修正该断言后的修前结果以 red-corrected.xml 为准。\n\n'
    '欧罗巴140队、欧协联86队旧杯赛桥逐项一致。追加带范围的测试项后仍一致，输入文件摘要按真实输入变化。\n'
    '正式别名、原件、冻结预测、账本未改；未执行线上采集；N1/N2/N3另PR。\n')
assert subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/'+BRANCH],cwd=ROOT).returncode==1
entries=[]
for p in sorted(OUT.iterdir()):
    blob=git('hash-object','-w','--stdin',content=p.read_bytes())
    entries.append(f'100644 blob {blob}\t{p.name}\n')
leaf=git('mktree',content=''.join(entries).encode())
middle=git('mktree',content=f'040000 tree {leaf}\t{PART}\n'.encode())
tree=git('mktree',content=f'040000 tree {middle}\tacceptance\n'.encode())
commit=git('commit-tree',tree,content=b'T68: preserve M1 scope coexistence test evidence\n')
git('update-ref','refs/heads/'+BRANCH,commit,'0'*40)
result=dict(branch=BRANCH,commit=commit,path='acceptance/'+PART,zip_sha256=zip_sha,
    zip_bytes=archive.stat().st_size,files=len(manifest))
(HERE/'evidence-ref.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
