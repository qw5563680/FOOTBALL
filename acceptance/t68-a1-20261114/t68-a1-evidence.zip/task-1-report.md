# T68 A Task 1 final implementation report

Current result: **62 approved routes; 1,083 new-route matches + 179 generic matches = 1,262 selected; 146 verified reusable same-JC database clocks; 1,116 pending; zero evidence issues on the fixed snapshot.** No sports requests, keys, Actions, production DB changes, commits or pushes were made. B remains unimplemented.

## Final interfaces and owned files

- New `src/zucai/jc_catalogue_kickoffs.py`:
  - `plan_kickoffs(archive: Path) -> dict`.
  - `collect_kickoffs(database: Path, run_id: str, *, max_requests: int = 5, archive: Path | None = None) -> dict`. Optional `archive` supplies the original hash-checkable source manifest/core tables; output always stays under `database.parent`. Without it, restored owned evidence is sufficient for repeat planning and collection. The collector never opens or modifies the database.
  - `python -m zucai.jc_catalogue_kickoffs plan --archive <source> --out <json>`.
- `src/zucai/cloud_feeds.py`: new `probe --probe-kind jc-kickoffs --max-requests N` route, passes the actual input archive through the optional argument; no legacy `codes` or `seasons` arguments or APIF key validation. Owned archive whitelist and restore extended.
- `.github/workflows/football-feeds.yml`: existing `jc-catalogue` job handles both JC probe kinds only on manual dispatch and `[self-hosted, football-local]`; hosted APIF job excludes both. `options.max_requests` defaults to 5 and is integer 1..7000, accepted only for this new kind. No APIF secrets injected.
- New `tests/test_t68_jc_kickoffs.py`, extended `tests/test_t61_workflow.py`, offline `data/fixtures/t68/heads/`. Fixture README distinguishes the existing head specimen, synthetic invalid mutations and synthetic cropped calculator shape; none claims new online availability evidence.

## Frozen scope, planning and actual denominator

Production defaults require source run `43539673769-1` and Beijing window **2025-11-01 through 2026-10-31**. Missing fixed source or another window fails; there is no latest-pointer fallback. The 62 explicit APIF IDs must each still have verified PR135 approval evidence. Enabling a route's daily switch or adding another route cannot change this set. Exact approved config names map to the official numeric dictionary; only generic official IDs 39/73/76 are additionally selected, without creating generic associations.

Every date, request URL/HTTP/SHA/sidecar, page count, pagination row count, cross-page/day ID uniqueness, dictionary consistency and genuine empty-day shape is checked. Unexpected/missing files fail. The fixed source independently recomputes to **406 pages, 365 dates including 20 legal empty days, 4,966 different official IDs**. Its historical report is `original_status=partial`; current raw verification yields `recomputed_status=complete`. Both remain visible; the old summary never substitutes for checking raw pages.

Final measured plan is `work/t68-a/kickoff-plan-fixed.json`; its summary/hashes are in `work/t68-a/task-1-fixed-plan.log`. It reports **146 reusable / 1,116 pending / 0 issues**. Reusable rows are 143 finished and 3 cancelled, all `source=jc` and `result_provider=jc`. The first pending pilot IDs remain `2034559,2034560,2034561,2034568,2034569`, Beijing 2025-11-01. The former 0 reusable / 1,262 pending output was an implementation gap corrected during review and is not the current conclusion.

## Evidence and durable storage

Verified raw head evidence requires the official requested JC ID, ordered Sporttery numeric team IDs, exact supplied clock, matching Beijing date, official endpoint/query, successful HTTP, capture metadata and correct content/sidecar hashes. `_head_time`, `RawStore` and existing official Referer conventions are reused. Real explicit midnight clocks and pre-kickoff captures remain valid; date-only clocks are not invented into exact times.

Existing calculator originals are checked against `getMatchCalculatorV1.qry`, the exact requested operation, same official ID, ordered numeric teams, exact clock/day, HTTP, SHA and capture metadata. Their normalized evidence contains no market inputs. Original bytes and sidecar remain intact when preserved.

The narrow database basis is `db_same_jc_id_verified`: verify complete matches/teams bytes against the source manifest, exact expected columns/counts, no duplicate match/team IDs, same official JC ID, `source=jc AND result_provider=jc`, exact league and Beijing date, and unique same-side canonical ownership across all existing `Team.name` and aliases using only existing approved JC mappings/normalization. It supplies only the timestamp of that same JC ID, never a new team binding or relationship. Evidence retains original line pointers and manifest/matches/teams/catalogue/aliases hashes. `result_checked_utc` and actual current `verified_utc` are separate; DB rows never pretend to have raw `fetched_at_utc`.

Storage is restricted and included in the manifest whitelist:

- `state/catalogue/<run>/jc-kickoff-plan.json`, `jc-kickoffs.json`.
- New response: `jc-heads/<official-id>.json(.meta.json)`.
- Reused/competing header pair: `jc-heads/conflicts/<official-id>-<pairSHA>.json(.meta.json)`.
- Calculator pair: `jc-schedules/<pairSHA>.json(.meta.json)`.
- `pairSHA = SHA256(rawSHA256 + metadataSHA256)`, using both complete ASCII hex digests. The evidence still retains and verifies both individual hashes.
- Database snapshots: `state/catalogue/<coreSHA>/jc-db-{matches,teams}.jsonl`, `jc-db-aliases.json`, and `jc-db-manifests/<manifestSHA>.json`. The core key binds matches/teams/aliases content hashes plus exact schemas. Changed probe manifests add their small original manifest file; unchanged ~20 MB matches bytes are saved once, not once per batch. Source-file SHA/count/schema/duplicate failures cannot become successful skips.

All competing trusted originals are copied before requests, including pending rows outside the current cap. Replanning after clean restore revalidates actual bytes and reconstructs the conflict. A new matching response cannot discard an old contradiction. HTTP failures, bad SHA, missing/empty responses remain failed/untrusted evidence; they do not create permanent holds against otherwise independently valid evidence.

## Review findings and fixes

1. **P1: legacy conflicting clocks disappeared after export/restore.** Pending rows now retain every competing proof; collector persists original bytes and sidecars with full pair hashes. Exact regression reproduces 23:15/23:30, fetches a new matching 23:15 response, exports/restores, and still sees a conflict. Mixed DB/calculator/head conflicts also remain held.
2. **P1: scope depended on latest and mutable daily flags.** Fixed run/window are mandatory; the explicitly approved 62 IDs are verified independently of daily and newly added routes. Small unit fixtures patch only their fixed run/window constants; production defaults have negative tests for missing/wrong fixed input.
3. **P2: independently verifiable calculator originals were ignored.** Planner now reads and verifies existing calculator originals, preserves them, and reuses them after clean restore. Bad SHA/source fail reuse. Trusted side/date contradictions and inconsistent duplicate official IDs block successful head/database reuse, are preserved under jc-schedules, and remain held after clean restore; contradictory clocks also block success.

Additional final review fixes:

- Valid database/head clocks could previously hide a hash/HTTP/source-verified header returning another official ID, reversed teams or another date, or a calculator original with reversed teams, another date, or inconsistent duplicates of the same official ID. Shared `TrustedJcContradiction` now carries both header and calculator contradictions as typed proofs (`jc_head_raw_contradiction` / `jc_schedule_raw_contradiction`). Both block database/head/schedule success, are preserved in their correct owned raw directories, are revalidated after restore, and prevent expansion. Cross-tests cover sides/date/duplicate calculator contradictions against each of valid database and valid header evidence, followed by a fresh matching header, export and clean restore. Transport/SHA/empty failures stay distinct and retryable for both raw endpoints. Raw sidecars are excluded before head indexing, removing fake `.meta.json.meta.json` errors.
- Combined pair digests shorten preserved header/schedule sidecar paths from 280/266 characters to **215/201 characters** on the actual supplied Windows runner base (216/202 including terminator), below traditional 260. Tests verify the full existing runner path, both individual hashes and complete combined SHA. No runner settings changed.

## Request and resume behavior

Manual self-hosted Actions gate is enforced before collection. Default pilot requests at most the earliest five pending historical IDs. Each request waits at least one second; hidden retries and redirects are disabled so HTTP attempts equal the explicit budget. A failed initial pilot stops immediately. A cap above five requires a previous successful pilot for the same catalogue/registry/aliases fingerprint, whose canonical originals and current identities/clocks revalidate. Contradictions invalidate that authorization. Reports distinguish success, failed, not_requested, verified skips and actual requests; failure is never a success cursor. Verified repeated collection requests zero new originals.

## Final verification and reproducible commands

Final integration: **149 passed in 5.43s**. Final Ruff: **All checks passed; 4 files already formatted**. Logs:

- `work/t68-a/task-1-final-integration-green.log` — final 149 tests, including all final calculator contradiction cases.
- `work/t68-a/task-1-final-ruff.log` — final lint/format checks.
- `work/t68-a/task-1-contradiction-red.log` → `task-1-contradiction-green.log` — explicit trusted contradiction and sidecar reproductions, then 60 tests green before the filename-only change.
- `work/t68-a/task-1-schedule-contradiction-red.log` → `task-1-schedule-contradiction-green.log` — six calculator cross-evidence RED cases; 70 module tests green after the shared contradiction fix, with HTTP/SHA/empty retryable cases.
- `work/t68-a/task-1-windows-path-red.log` — reproduced actual 280-character path; final integration includes its passing regression.
- Earlier independent red evidence remains under `task-1-review-p1-red.log`, `task-1-evidence-red.log`, `task-1-db-schema-red.log`, `task-1-review-red.log`.

```sh
PYTHONPATH=src /workspace/work/t48-venv/bin/python -m pytest -o addopts='' -o tmp_path_retention_policy=failed tests/test_t68_jc_kickoffs.py tests/test_t61_workflow.py tests/test_t61_catalogue_archive.py tests/test_cloud_feeds.py -q
/workspace/work/t48-venv/bin/ruff check src/zucai/jc_catalogue_kickoffs.py src/zucai/cloud_feeds.py tests/test_t68_jc_kickoffs.py tests/test_t61_workflow.py
/workspace/work/t48-venv/bin/ruff format --check src/zucai/jc_catalogue_kickoffs.py src/zucai/cloud_feeds.py tests/test_t68_jc_kickoffs.py tests/test_t61_workflow.py
PYTHONPATH=src /workspace/work/t48-venv/bin/python -m zucai.jc_catalogue_kickoffs plan --archive work/t68-a/fixed-archive --out work/t68-a/kickoff-plan-fixed.json
```

Reviewer-only live entry, not run here:

```sh
python -m zucai.cloud_feeds probe --probe-kind jc-kickoffs --archive ../cloud-data --run-id <new-pilot-run> --max-requests 5
# After reviewer confirms the real successful pilot, use a separate batch:
python -m zucai.cloud_feeds probe --probe-kind jc-kickoffs --archive ../cloud-data --run-id <new-continuation-run> --max-requests 1200
```

Parent owns final whole-suite verification, docs, independent final review and commits. Real historical endpoint availability remains unverified until the authorized reviewer pilot. No B work, daily switch, model parameter/source, identity approval or production publication is included.
