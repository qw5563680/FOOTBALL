通过

**Latest conclusion, 2026-11-14:** the final Task 1 internal code re-review has no unresolved Critical or Important findings. All findings below are retained as historical review/fix records and are closed by the final re-review at the end of this document. Independently verified **135 focused tests passed**, Ruff check/format passed, and fixed input counts remain **146 reusable / 1,116 pending**. This internal review is **not Claude approval**, is not authorization for a production pilot, and does not replace the parent-owned full integration suite, formal repository review, or owner's merge decision.

Read-only independent review of Task 1 against `f240994c`, the Task 1 brief, and protocol §2.2–2.3. This is the **initial review before the requested fixes**, not an approval of subsequent worker edits. Reviewed module SHA256: `50df1c56ae6c76560c77131fda115454f0bc1f4b1c54e7a6df7f321ffafd7873` (438 lines). No production requests, credentials, Actions, commits, pushes, or implementation changes were made. Only this review document is written.

## Must fix

### P1 — Conflicting legacy originals become successful after export/restore

- File: `src/zucai/jc_catalogue_kickoffs.py:232–237`, `:331–340`, `:373–376`.
- Two valid existing raw headers for the same official match ID with different clocks correctly produce `conflicting_jc_kickoff_evidence`. However, the pending row drops both evidence pointers. The collector persists only previously verified originals, and persists its newly returned valid header even when that row is explicitly marked failed because the old conflict requires review. `export_feeds` does not archive arbitrary legacy `raw/` files. After a clean restore, the planner sees only the new header, ignores the prior failed/conflict report, and marks the previously disputed match successful.
- Reproduced using only existing fixtures and `responses`: two `RawStore` headers for `jc:2042404`, official teams `849/508`, Beijing `2026-10-31`, clocks `23:15` and `23:30`; collect a new `23:15` header; export; restore into a clean directory; plan again.
- Observed before: verified `0`, pending `1`, reason `conflicting_jc_kickoff_evidence`. Collector: success `0`, failed `1`, reason `conflicting_jc_kickoff_evidence requires review`. Observed after restore: verified `1`, pending `0`, sole evidence `state/catalogue/conflict/jc-heads/2042404.json`.
- Impact: durable replay silently resolves a source contradiction without approval. This directly violates the required conflict quarantine and resume semantics, even though the original pilot report remains failed.
- Required regression: persist/revalidate all competing evidence, or preserve a durable unresolved conflict that cannot be cleared merely by losing old originals. Test the complete export/clean-restore/replan path. A fresh matching response must not clear the conflict.

### P1 — The supposedly fixed 1,262-match scope depends on latest pointers and mutable daily flags

- File: `src/zucai/jc_catalogue_kickoffs.py:99–119`, `:195–207`.
- If the protocol's fixed `43539673769-1/jc.json` is absent, the planner silently uses the latest JC pointer and accepts any window declared there. A complete one-day replacement catalogue is accepted rather than rejecting the missing fixed source; the current `catalogue()` test helper itself reproduces that behavior. The collector can then request this replacement set.
- Route membership is recomputed from current `status=verified`, `backfill=true`, `daily=false`. Enabling daily collection for an approved new route removes its original matches from the supposedly fixed plan. Adding another matching route can expand it. A new plan fingerprint does not prevent the next default five-request pilot from collecting the changed scope.
- Concrete offline reproduction on the fixed source: change only route `307` (沙职) `daily` to `true` in a temporary registry and point the module's `REGISTRY` at it. Counts change from routes `62`, selected `1262` to routes `61`, selected `1090`; 172 approved matches disappear. Removed IDs start `2034559, 2034607, 2034622, 2034783, 2034784`.
- Required regression: missing fixed source and incorrect fixed window must fail closed. Identify the approved 62 routes from fixed approval evidence/explicit IDs, independently of later daily switches. Tests may explicitly patch source/window constants for small fixtures; production defaults must remain fixed. Parent confirmed there is no authorization for a latest/window fallback.

### P2 — Existing independently verifiable schedule originals are ignored

- File: `src/zucai/jc_catalogue_kickoffs.py:209–217`, `:64–89`.
- The existing-evidence scanner recognizes only header filenames (`match-*.json`) and validates only the header endpoint. Valid `getMatchCalculatorV1.qry` schedule originals saved under the repository's normal `raw/sporttery-calculator/.../calculator_*.json` convention are never examined, even when they contain the same official match ID, ordered numeric team IDs, exact clock, matching Beijing date, valid HTTP status, SHA and capture metadata.
- Offline reproduction: take the actual numeric-ID schedule shape from `data/fixtures/t36_odds/closed_real_trimmed.json`, crop to its first row, adapt it to the test catalogue's `2042404`, league `24`, teams `849/508`, date `2026-10-31`, clock `23:15:00`; save it through `RawStore` with the official calculator endpoint, HTTP 200, and capture `2026-10-31T12:00:00Z`. The planner returns verified `0`, pending `[2042404]`, issues `[]`.
- This is separate from accepting an unproven DB timestamp. Protocol §2.2 explicitly permits an existing schedule original or a sourced database row; the valid independent original is currently ignored and another request is planned.
- Required regression: exact schedule identity/date/SHA verification and clean-restore persistence, including negative cases. Do not copy market fields into this time-only evidence.

## Verification and confirmed strengths

Command independently run:

```sh
PYTHONPATH=src /workspace/work/t48-venv/bin/python -m pytest -o addopts='' tests/test_t68_jc_kickoffs.py tests/test_t61_workflow.py -q
```

Result: **70 passed in 3.82s**. Passing tests currently miss the three cases above. The parent's full integration suite remains necessary after fixes; this reviewer did not repeat it.

Independently reran `plan_kickoffs(Path('work/t68-a/fixed-archive'))`: 406 pages, 4,966 distinct official IDs, window 2025-11-01 through 2026-10-31; 62 routes; 1,083 new-route matches plus 179 generic matches = **1,262**; current implementation verifies 0 and requests 1,262. Pilot IDs exactly `2034559,2034560,2034561,2034568,2034569`. Plan SHA256 `76d6b6a2ddbf0f40681841e596734b138dd92bfc1986d854f80664122e24cbc8`.

Confirmed implementation strengths: real official ID rather than supplier `matchId`; ordered official team checks; real midnight and prematch captures allowed; malformed/date-only clocks rejected; original HTTP/SHA/source/time metadata rechecked; request budget avoids retries and redirects; each actual request waits one second; failed initial pilots stop; default ordinary successful resume makes no requests; owned heads and plan/report files pass manifest roundtrip; self-hosted manual workflow route excludes APIF secrets and hosted collection.

## Independent assessment of the 146 existing JC rows

The fixed snapshot contains 146 selected existing rows: all `source=jc` **and** `result_provider=jc`, 143 finished and 3 cancelled. For all 146, each official catalogue side's short/full name normalizes exactly to that side's existing `Team.name`.

Additional independent checks completed after the initial review: reverified `state/matches.jsonl` and `state/teams.jsonl` bytes against the fixed manifest; looked up each official catalogue row by exact `matchId` in its already verified page; parsed the stored UTC clock and compared its `Asia/Shanghai` calendar date to `matchDate`; compared stored league to official `leagueNameAbbr`; checked distinct ordered home/away IDs; and built normalized/casefolded ownership sets across **all** existing `Team.name` and `Team.aliases` values. For each source short/full name, applied only the existing approved JC mapping, otherwise existing normalization, and unioned exact owners. Each side's union must equal the singleton containing that side's database `Team.id`. **All 146 pass these checks; no provider/date/league/ownership failures.** Three stored clocks are at Beijing midnight; no special midnight rejection was applied. These checks authorize timestamp reuse only, not alias creation.

Therefore the independently supported denominator under the narrowly specified database reuse basis is **146 reusable / 1,116 pending**, before any new head requests. The initial implementation's **0 reusable / 1,262 pending** misses those existing sources. This count is based on the fixed snapshot and existing exact ownership, not on newly acquired sports evidence, and remains subject to preserving conflict precedence if contradictory originals are later supplied.

For the narrow task of reusing the timestamp of the **same official JC ID**, an explicit verified chain can be acceptable: hash-checked fixed manifest/matches/teams, `source=jc` and `result_provider=jc`, same official ID in the verified catalogue, ordered official numeric team IDs, exact same-side canonical ownership without ambiguity or fuzzy matching, same competition, same Beijing date, and a real exact clock. Preserve all original pointers and hashes, the row's `result_checked_utc`, and a separate actual current `verified_utc`. Label the basis as a verified same-ID database row, not as a reverified original head. Existing contradictory raw evidence must still block it.

This interpretation is supported by §2.2's explicit allowance of a sourced database row and §2.3's same-ID/source/team/date checks. It must not become a new alias, cross-source relationship, or identity authorization: §2.1's prohibition on using `Team.name` alone for identity authorization remains intact. `source=jc` alone is insufficient because `results.apply_result` can also retain a JC match ID while updating it from c500; the provider guard matters. Do not label the database's result-check time as an original head's `fetched_at_utc`, nor claim missing raw has been verified. Clarify this limited reuse basis in the protocol if implementing it.

## Fixed four questions

1. **Frozen predictions/parameters/run logs touched?** No implementation changes to frozen outputs are present in this Task 1 diff; the collector does not open or mutate the database. No production actions were taken by this reviewer. Full frozen-object comparison is parent-owned.
2. **Other matches' matching/routing/probabilities affected?** No matching, model or probability code changes. The explicit new probe route affects the approved 1,262 source IDs. Finding 2 shows that the current implementation can change that set: a 沙职 daily flag removes 172 IDs. Finding 1 reproduces a wrong verification state for `jc:2042404`. Generic league IDs 39/73/76 are selected for timestamps only; no B associations are implemented.
3. **Only pre-kickoff information used?** This is a historical evidence collector, not a prediction computation. New headers retain actual capture timestamps and are not backdated. A database reuse implementation must preserve its distinct historical source/check and current verification times. The collector does not consume results/odds for a probability calculation.
4. **Tests cover changed behavior?** Main parser, endpoint, HTTP/SHA, source IDs, date, clock, pilot success/failure, rate, budget, whitelist roundtrip, and workflow routing are covered. Missing regressions are contradictory legacy evidence across clean restore, fixed-source/window and daily-independent scope, and valid schedule reuse. Any new database path additionally needs swapped/ambiguous teams, wrong source/provider/date/league, snapshot-hash failure, and conflict precedence tests.

## Minimal reproduction for finding 1

Run from repository root with `PYTHONPATH=src:tests` and the configured offline Python environment:

```python
import json, os, tempfile
from pathlib import Path
from datetime import UTC, date, datetime
import responses
from test_t68_jc_kickoffs import catalogue, HEADS
from test_cloud_feeds import seed_cloud_archive
import zucai.jc_catalogue_kickoffs as m
from zucai.cloud_feeds import export_feeds, restore_feeds
from zucai.sources.base import RawStore
from zucai.sources.sporttery import API

os.environ.update(GITHUB_ACTIONS='true', GITHUB_EVENT_NAME='workflow_dispatch',
                  RUNNER_ENVIRONMENT='self-hosted')
m.time.sleep = lambda _: None
with tempfile.TemporaryDirectory() as tmp:
    root = Path(tmp)
    archive = seed_cloud_archive(root)
    catalogue(root)
    for clock in ('2026-10-31 23:15', '2026-10-31 23:30'):
        raw = json.loads((HEADS / 'success.json').read_bytes())
        raw['value']['matchDateTime'] = clock
        RawStore(root / 'raw').save(
            'sporttery-head', 'match-2042404', json.dumps(raw).encode(), 'json',
            url=API + 'getMatchHeadV1.qry?source=web&sportteryMatchId=2042404',
            status_code=200, captured_at=datetime(2026, 11, 1, tzinfo=UTC))
    assert m.plan_kickoffs(root)['pending'][0]['reason'] == 'conflicting_jc_kickoff_evidence'
    with responses.RequestsMock() as mock:
        mock.add(responses.GET, API + 'getMatchHeadV1.qry',
                 body=(HEADS / 'success.json').read_bytes())
        report = m.collect_kickoffs(root / 'seed.db', 'conflict')
    assert report['failed_count'] == 1
    export_feeds(root / 'seed.db', archive, date(2026, 11, 1), 'conflict-export')
    restored = root / 'fresh/data/zucai.db'
    restore_feeds(archive, restored)
    after = m.plan_kickoffs(restored.parent)
    print(len(after['verified']), len(after['pending']))  # BUG: 1 0
```

## Re-review, 2026-11-14 — initial fixes checked, one Important issue remains

This is an internal implementation review. It is **not Claude approval**, does not authorize a production pilot, and does not replace the repository's required formal review or owner's merge decision.

Original findings 1–3 have substantive fixes: competing valid clocks are retained in pending evidence and copied into hash-addressed durable files; the fixed source run/window are mandatory; the 62 route IDs are explicit with per-route PR135 approval evidence and no dependency on daily flags; calculator schedule originals and narrowly verified same-ID database snapshots are now supported. Independently recomputed the fixed plan: **62 / 1,262 / 1,083 / 179 / 146 reusable / 1,116 pending**, no issues, unchanged earliest five IDs. At the beginning of this re-review the module SHA256 was `3ce074060ef0b11938f4fd080f50aaca3852791fb42d510438202ff89a7ea97c`; a subsequent field spelling change to `verified_utc` produced `6fc0d4728491fcceb676404fa568d72e69287f1ea67e68bcd83abe8ca112b27d`.

Independently exercised additional recovery paths: database proof collection made zero requests; clean restore retained the reusable timestamp; changing saved matches bytes raised `JC database matches source SHA verification failed`; changing saved manifest bytes raised `JC database snapshot filename/SHA mismatch`; a database 23:15 clock and schedule 23:30 clock remained pending after collection/export/clean restore with all three evidence bases (database, schedule, newly acquired header) present. These checks support the persistence and revalidation fixes.

### Remaining Important/P1 — A valid clock hides a trusted original's contradictory identity/date

- File: `src/zucai/jc_catalogue_kickoffs.py:532–549` (the catch-and-append-to-issues block followed by `len(clocks) == 1`).
- A valid reusable database timestamp plus a saved header with the correct official request URL, HTTP 200, valid SHA and capture metadata, but a contradictory official match ID, ordered team IDs, or Beijing date is still marked `verified` success. The original is rejected into `issues`, while the sole database clock makes the row successful. The collector then makes zero requests and does not preserve the contradictory original, so a clean restore loses this unresolved source problem as well.
- This violates the newly clarified protocol §2.3: existing originals with clock, ID or direction conflicts remain pending. It also affects a valid original paired with a contradictory original, independently of database reuse.
- Offline reproduction, with the same fixture constant patches used by the unit tests:

```python
archive = verified_db_archive(tmp_path)
RawStore(archive / 'raw').save(
    'sporttery-head', 'match-2042404',
    (HEADS / 'wrong-id.json').read_bytes(), 'json',
    url=API + 'getMatchHeadV1.qry?source=web&sportteryMatchId=2042404',
    status_code=200, captured_at=datetime(2026, 11, 1, tzinfo=UTC))
plan = module.plan_kickoffs(archive)
assert len(plan['verified']) == 1  # Actual, incorrect; this must be pending.
assert plan['pending'] == []
```

- Independently repeated with `wrong-id.json`, `reversed.json`, and `wrong-day.json`: all three return verified 1 / pending 0, with the contradictory raw only in issues.
- Fix must distinguish a trustworthy original containing a contradictory source identity/day from retryable HTTP failures, invalid hashes and empty responses. Preserve the contradictory original and quarantine its match across export/restore; a valid database clock must not clear it. Add mixed-evidence regressions, not only the existing negative tests with no valid competing evidence.
- Related minor scanner issue: `rglob('match-*.json')` also matches `.json.meta.json` files and attempts to read `.json.meta.json.meta.json`, creating bogus issues even for a correct legacy header. Exclude sidecars before introducing stricter conflict handling.

The first re-review test run was 117 passed / 1 failed because the duplicate-owner test inserted a team without updating the newly enforced manifest row count. The coordinator reports that fixture was subsequently corrected and the worker's targeted tests are green. That correction is independent of the remaining mixed-evidence issue above; a final passing review requires its fix and focused verification.

### Follow-up on the typed contradiction fix

Reviewed module SHA256 `4af4858b973c6134705fdf6aa310ab2cc45e1737f410bf6d1ef04f557b87caf4`. The header branch now distinguishes trusted source contradictions from failed HTTP/SHA/empty responses, preserves contradiction originals, and excludes metadata sidecars. The remaining issue is the **same mixed-evidence path for schedule originals**: `_schedule` still raises ordinary `ValueError` for a same-ID schedule's reversed numeric team IDs or conflicting Beijing date. With a valid database clock, both are relegated to issues and the match remains successful.

Independently reproduced both cases using `verified_db_archive`, `save_schedule`, then either swapping `homeTeamId/awayTeamId` or changing `matchDate` to `2026-10-30` and correctly recomputing its sidecar SHA. Both return **verified 1 / pending 0**, with `JC schedule official home/away team mismatch` or `JC schedule Beijing date mismatch` in issues. This is the same unresolved Important finding, not a new feature requirement. Extend the trusted contradiction treatment and durable preservation to this supported source before declaring it closed.

## Final re-review, 2026-11-14 — all review findings closed

Final reviewed source SHA256: `cb2711f5cb067e9b5700294d20b57a7b9f7bd7908da7581d1d323ef3ff20324d` (`src/zucai/jc_catalogue_kickoffs.py`). Test SHA256: `a66bc363679f5068898e9e6d5fea1ad31e4330adbe0fcdd3a7f99fb0f9be1baf` (`tests/test_t68_jc_kickoffs.py`). These hashes were identical before and after this final review's checks.

The unified `TrustedJcContradiction` now covers both supported raw sources. It is raised only after request provenance, successful HTTP status, capture metadata, and original SHA verification. A trusted same-ID schedule with reversed numeric teams, a conflicting Beijing date, or inconsistent duplicate rows is retained as `jc_schedule_raw_contradiction`, preserved under `jc-schedules`, and prevents a valid database/header clock from marking the match successful. Head contradictions use the same quarantine logic. Ordinary failed HTTP, damaged hashes, and empty replies remain unsuccessful evidence that does not create a permanent source-conflict hold. Legacy metadata sidecars are excluded from the original-header scan.

Independently reran the earlier schedule reproduction as three cases, using the exact offline helpers and transformations described above: swapped ordered IDs; changed Beijing date; duplicate official match ID with a different clock. For **each** case, before collection the plan has verified 0 / pending 1; after a fresh matching header, export and clean restore, it still has verified 0 / pending 1 and reason `conflicting_jc_kickoff_evidence`. The archived original and sidecar are byte-for-byte equal to the original contradictory schedule. This closes the last Important finding and directly tests the former failure path, not just its implementation shape.

Final independent checks:

```sh
PYTHONPATH=src /workspace/work/t48-venv/bin/python -m pytest -o addopts='' tests/test_t68_jc_kickoffs.py tests/test_t61_workflow.py tests/test_t61_catalogue_archive.py -q
/workspace/work/t48-venv/bin/ruff check src/zucai/jc_catalogue_kickoffs.py src/zucai/cloud_feeds.py tests/test_t68_jc_kickoffs.py tests/test_t61_workflow.py
/workspace/work/t48-venv/bin/ruff format --check src/zucai/jc_catalogue_kickoffs.py src/zucai/cloud_feeds.py tests/test_t68_jc_kickoffs.py tests/test_t61_workflow.py
```

Results: **135 passed in 4.69s**; **All checks passed**; **4 files already formatted**. The focused suite includes both sources' durable conflicts, good database/head support paired with contradictory schedules, HTTP/SHA/empty non-conflict behavior, original conflict recovery, fixed source/window and route scope, source-proof integrity/columns/counts/duplicate IDs, zero-request resume, archive whitelist, self-hosted workflow routing, and shortened evidence paths for the configured Windows runner. No full suite was repeated by this reviewer.

Independently recalculated `plan_kickoffs(work/t68-a/fixed-archive)` once more with production constants: **62 routes; 1,262 selected = 1,083 + 179; 146 reusable; 1,116 pending; 0 issues**. All 146 reuse records carry `db_same_jc_id_verified`; first five remain `2034559,2034560,2034561,2034568,2034569`. Plan SHA256: `e17889ded5ef92344dbbc324827dffbc420db334c07568d3dc5a5c7be07368c4`.

Current fixed-four-question assessment: frozen predictions/parameters/run logs are not modified by Task 1; no new aliases, generic relationships, match-table writes, model routes or probabilities are introduced; captured/checked/current verification times remain distinct without backdating; the changed collector, provenance, conflict and workflow paths have focused regression coverage. Parent owns the final full-suite and frozen-object checks. Historical old-match response availability remains untested by design and requires the separately authorized reviewer Actions pilot.

**Final internal review: pass; no remaining Critical/Important findings in the reviewed Task 1 scope. This is not Claude approval.**
